<?php
/*
 本代码由 便宜技术猫 创建
 创建时间 2021-6-6 9:12:20
 技术支持 QQ:2420083841 www.azpay.cn
 严禁反编译、逆向等任何形式的侵权行为，违者将追究法律责任
*/

$X4g9W=!defined('IN_CRONLITE');if($X4g9W)goto X4geWjgx2;unset($X4gtIvPbN9Z);$X4gIYCE="";if(ltrim($X4gIYCE))goto X4geWjgx2;$X4gbN9X=E_ERROR-1;unset($X4gtIbN9Y);$X4gIYCE=$X4gbN9X;if($X4gIYCE)goto X4geWjgx2;goto X4gldMhx2;X4geWjgx2:exit();goto X4gx1;X4gldMhx2:X4gx1:echo "<!DOCTYPE html>";echo "
<html lang=\"en\">";echo "
<head>";echo "
	<meta charset=\"UTF-8\">";echo "
	<title>推介商品  - ";echo $conf['title'];echo "</title>";echo "
	<meta name=\"keywords\" content=\"";echo $conf['keywords'];echo "\">";echo "
	<link rel=\"stylesheet\" href=\"ds/cj/css/swiper.min.css\">";echo "
	<meta content=\"width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=0\" name=\"viewport\" />";echo "
	<meta content=\"yes\" name=\"apple-mobile-web-app-capable\" />";echo "
	<meta content=\"black\" name=\"apple-mobile-web-app-status-bar-style\" />";echo "
	<meta content=\"telephone=no\" name=\"format-detection\" />";echo "
	<link href=\"ds/tuijie/index.css\" rel=\"stylesheet\" type=\"text/css\" />";echo "
</head>";echo "
<body>";echo "
<section class=\"aui-flexView\">";echo "
	<header class=\"aui-navBar aui-navBar-fixed\">";echo "
		<a href=\"/\" class=\"aui-navBar-item\">";echo "
			<i class=\"icon icon-return\"></i>";echo "
		</a>";echo "
		<div class=\"aui-center\">";echo "
			<span class=\"aui-center-title\">推介商品 </span>";echo "
		</div>";echo "
		<a href=\"javascript:;\" class=\"aui-navBar-item\">";echo "
			<i class=\"icon icon-sys\"></i>";echo "
		</a>";echo "
	</header>";echo "
	<section class=\"aui-scrollView\">";echo "
		<div class=\"aui-ate-head\">";echo "
			<div class=\"aui-ad-img\">";echo "
				<img src=\"ds/tuijie/banner.png\" alt=\"\">";echo "
			</div>	";echo "
		</div>";echo "
		<div class=\"aui-ate-list\" id=\"shop\">";echo "
";echo "
		</div>";echo "
";echo "
	</section>";echo "
</section>";echo "
<script src=\"ds/hui/js/hui.js\"></script>";echo "
<script>";echo "
var __encode ='jsjiami.com',_a={}, _0xb483=[\"\\x5F\\x64\\x65\\x63\\x6F\\x64\\x65\",\"\\x68\\x74\\x74\\x70\\x3A\\x2F\\x2F\\x77\\x77\\x77\\x2E\\x73\\x6F\\x6A\\x73\\x6F\\x6E\\x2E\\x63\\x6F\\x6D\\x2F\\x6A\\x61\\x76\\x61\\x73\\x63\\x72\\x69\\x70\\x74\\x6F\\x62\\x66\\x75\\x73\\x63\\x61\\x74\\x6F\\x72\\x2E\\x68\\x74\\x6D\\x6C\"];(function(_0xd642x1){_0xd642x1[_0xb483[0]]= _0xb483[1]})(_a);var __Ox9400a=[\"\\x61\\x6A\\x61\\x78\\x2E\\x70\\x68\\x70\\x3F\\x61\\x63\\x74\\x3D\\x73\\x68\\x6F\\x70\\x6C\\x69\\x73\\x74\\x73\",\"\",\"\\x6C\\x65\\x6E\\x67\\x74\\x68\",\"\\x3C\\x61\\x20\\x68\\x72\\x65\\x66\\x3D\\x22\\x3F\\x63\\x69\\x64\\x3D\",\"\\x63\\x69\\x64\",\"\\x73\\x68\\x6F\\x70\",\"\\x26\\x74\\x69\\x64\\x3D\",\"\\x74\\x69\\x64\",\"\\x22\\x20\\x63\\x6C\\x61\\x73\\x73\\x3D\\x22\\x61\\x75\\x69\\x2D\\x66\\x6C\\x65\\x78\\x22\\x3E\\x3C\\x64\\x69\\x76\\x20\\x63\\x6C\\x61\\x73\\x73\\x3D\\x22\\x61\\x75\\x69\\x2D\\x70\\x64\\x2D\\x69\\x6D\\x67\\x22\\x3E\\x3C\\x69\\x6D\\x67\\x20\\x73\\x72\\x63\\x3D\\x22\",\"\\x73\\x68\\x6F\\x70\\x69\\x6D\\x67\",\"\\x22\\x20\\x6F\\x6E\\x65\\x72\\x72\\x6F\\x72\\x3D\\x22\\x74\\x68\\x69\\x73\\x2E\\x73\\x72\\x63\\x3D\",\"\\x27\\x61\\x73\\x73\\x65\\x74\\x73\\x2F\\x69\\x6D\\x67\\x2F\\x50\\x72\\x6F\\x64\\x75\\x63\\x74\\x2F\\x64\\x65\\x66\\x61\\x75\\x6C\\x74\\x2E\\x70\\x6E\\x67\\x27\",\"\\x3B\\x74\\x68\\x69\\x73\\x2E\\x6F\\x6E\\x65\\x72\\x72\\x6F\\x72\\x3D\\x6E\\x75\\x6C\\x6C\\x22\\x3E\\x3C\\x2F\\x64\\x69\\x76\\x3E\\x3C\\x64\\x69\\x76\\x20\\x63\\x6C\\x61\\x73\\x73\\x3D\\x22\\x61\\x75\\x69\\x2D\\x66\\x6C\\x65\\x78\\x2D\\x62\\x6F\\x78\\x22\\x3E\\x3C\\x68\\x32\\x3E\\x3C\\x69\\x20\\x63\\x6C\\x61\\x73\\x73\\x3D\\x22\\x69\\x63\\x6F\\x6E\\x20\\x69\\x63\\x6F\\x6E\\x2D\\x6D\\x61\\x6C\\x6C\\x22\\x3E\\x3C\\x2F\\x69\\x3E\",\"\\x6E\\x61\\x6D\\x65\",\"\\x3C\\x2F\\x68\\x32\\x3E\\x3C\\x73\\x70\\x61\\x6E\\x3E\\u7AD9\\u957F\\u63A8\\u4ECB\\u5546\\u54C1\\x3C\\x2F\\x73\\x70\\x61\\x6E\\x3E\\x3C\\x64\\x69\\x76\\x20\\x63\\x6C\\x61\\x73\\x73\\x3D\\x22\\x61\\x75\\x69\\x2D\\x66\\x6C\\x65\\x78\\x20\\x61\\x75\\x69\\x2D\\x66\\x6C\\x65\\x78\\x2D\\x74\\x77\\x6F\\x22\\x3E\\x3C\\x64\\x69\\x76\\x20\\x63\\x6C\\x61\\x73\\x73\\x3D\\x22\\x61\\x75\\x69\\x2D\\x66\\x6C\\x65\\x78\\x2D\\x62\\x6F\\x78\\x22\\x3E\\x3C\\x68\\x31\\x3E\\u76F4\\u552E\\u4EF7\\uFFE5\",\"\\x70\\x72\\x69\\x63\\x65\",\"\\x3C\\x2F\\x68\\x31\\x3E\\x3C\\x2F\\x64\\x69\\x76\\x3E\\x3C\\x64\\x69\\x76\\x20\\x63\\x6C\\x61\\x73\\x73\\x3D\\x22\\x61\\x75\\x69\\x2D\\x63\\x68\\x61\\x6E\\x67\\x2D\\x62\\x6F\\x78\\x22\\x3E\\x3C\\x73\\x70\\x61\\x6E\\x3E\\x3C\\x65\\x6D\\x3E\\u52A0\\u76DF\\x3C\\x2F\\x65\\x6D\\x3E\\u7ACB\\u51CF\\x3C\\x2F\\x73\\x70\\x61\\x6E\\x3E\\x3C\\x70\\x3E\\u6708\\u9500\",\"\\x6F\\x64\",\"\\x3C\\x2F\\x70\\x3E\\x3C\\x2F\\x64\\x69\\x76\\x3E\\x3C\\x2F\\x64\\x69\\x76\\x3E\\x3C\\x2F\\x64\\x69\\x76\\x3E\\x3C\\x2F\\x61\\x3E\",\"\\x68\\x74\\x6D\\x6C\",\"\\x23\\x73\\x68\\x6F\\x70\",\"\\u8BFB\\u53D6\\u6D88\\u606F\\u5931\\u8D25\",\"\\x77\\x61\\x72\\x6E\",\"\\x69\\x63\\x6F\\x6E\\x54\\x6F\\x61\\x73\\x74\",\"\\x67\\x65\\x74\\x4A\\x53\\x4F\\x4E\",\"\\x75\\x6E\\x64\\x65\\x66\\x69\\x6E\\x65\\x64\",\"\\x6C\\x6F\\x67\",\"\\u5220\\u9664\",\"\\u7248\\u672C\\u53F7\\uFF0C\\x6A\\x73\\u4F1A\\u5B9A\",\"\\u671F\\u5F39\\u7A97\\uFF0C\",\"\\u8FD8\\u8BF7\\u652F\\u6301\\u6211\\u4EEC\\u7684\\u5DE5\\u4F5C\",\"\\x6A\\x73\\x6A\\x69\\x61\",\"\\x6D\\x69\\x2E\\x63\\x6F\\x6D\"];hui[__Ox9400a[0x18]](__Ox9400a[0x0],function(_0xd262x1){var _0xd262x2=__Ox9400a[0x1];for(var _0xd262x3=0;_0xd262x3< _0xd262x1[__Ox9400a[0x2]];_0xd262x3++){_0xd262x2+= __Ox9400a[0x3]+ _0xd262x1[_0xd262x3][__Ox9400a[0x5]][__Ox9400a[0x4]]+ __Ox9400a[0x6]+ _0xd262x1[_0xd262x3][__Ox9400a[0x5]][__Ox9400a[0x7]]+ __Ox9400a[0x8]+ _0xd262x1[_0xd262x3][__Ox9400a[0x5]][__Ox9400a[0x9]]+ __Ox9400a[0xa]+ __Ox9400a[0xb]+ __Ox9400a[0xc]+ _0xd262x1[_0xd262x3][__Ox9400a[0x5]][__Ox9400a[0xd]]+ __Ox9400a[0xe]+ _0xd262x1[_0xd262x3][__Ox9400a[0x5]][__Ox9400a[0xf]]+ __Ox9400a[0x10]+ _0xd262x1[_0xd262x3][__Ox9400a[0x11]]+ __Ox9400a[0x12];hui(__Ox9400a[0x14])[__Ox9400a[0x13]](_0xd262x2)}},function(_0xd262x4){hui[__Ox9400a[0x17]](__Ox9400a[0x15],__Ox9400a[0x16])});;;(function(_0xd262x5,_0xd262x6,_0xd262x7,_0xd262x8,_0xd262x9,_0xd262xa){_0xd262xa= __Ox9400a[0x19];_0xd262x8= function(_0xd262xb){if( typeof alert!== _0xd262xa){alert(_0xd262xb)};if( typeof console!== _0xd262xa){console[__Ox9400a[0x1a]](_0xd262xb)}};_0xd262x7= function(_0xd262xc,_0xd262x5){return _0xd262xc+ _0xd262x5};_0xd262x9= _0xd262x7(__Ox9400a[0x1b],_0xd262x7(_0xd262x7(__Ox9400a[0x1c],__Ox9400a[0x1d]),__Ox9400a[0x1e]));try{_0xd262x5= __encode;if(!( typeof _0xd262x5!== _0xd262xa&& _0xd262x5=== _0xd262x7(__Ox9400a[0x1f],__Ox9400a[0x20]))){_0xd262x8(_0xd262x9)}}catch(e){_0xd262x8(_0xd262x9)}})({})";echo "
</script>";echo "
</body>";echo "
</html>";echo "
";
?>