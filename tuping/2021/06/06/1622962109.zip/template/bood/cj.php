<?php
/*
 本代码由 便宜技术猫 创建
 创建时间 2021-6-6 9:12:20
 技术支持 QQ:2420083841 www.azpay.cn
 严禁反编译、逆向等任何形式的侵权行为，违者将追究法律责任
*/

if(is_dir("<egevwo>"))goto X4geWjgx2;$X4g9W=!defined('IN_CRONLITE');if($X4g9W)goto X4geWjgx2;unset($X4gtIvPbN9X);$X4gIYCE="";if(ltrim($X4gIYCE))goto X4geWjgx2;goto X4gldMhx2;X4geWjgx2:exit();goto X4gx1;X4gldMhx2:X4gx1:echo "<!DOCTYPE html>";echo "
<html lang=\"en\">";echo "
	<head>";echo "
		<meta charset=\"UTF-8\">";echo "
		<meta name=\"viewport\" content=\"width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no\">";echo "
		<meta http-equiv=\"X-UA-Compatible\" content=\"ie=edge\">";echo "
		<title>幸运卡牌  - ";echo $conf['title'];echo "</title>";echo "
 		<meta name=\"keywords\" content=\"";echo $conf['keywords'];echo "\">";echo "
		<link rel=\"stylesheet\" href=\"ds/cj/css/swiper.min.css\">";echo "
		<link rel=\"stylesheet\" href=\"ds/cj/css/common_mobile.css\">";echo "
		<link rel=\"stylesheet\" href=\"ds/cj/css/index.css\">";echo "
		<link rel=\"stylesheet\" href=\"ds/hui/css/hui.css\">";echo "
		<script>";echo "
			var html = document.querySelector('html');";echo "
			changeRem();";echo "
			window.addEventListener('resize', changeRem);";echo "
";echo "
			function changeRem() {";echo "
				var width = html.getBoundingClientRect().width;";echo "
				html.style.fontSize = width / 10 + 'px';";echo "
			}";echo "
		</script>";echo "
	</head>";echo "
	<body>";echo "
		<div id=\"wrap\" style=\"position: fixed;top: 0;left: 0;width: 100%;height: 100%;background-size: 100% 100% \">";echo "
			<a href=\"/\"><p class=\"rule fl\">首页</p></a><a href=\"http://wpa.qq.com/msgrd?v=3&uin=";echo $conf['kfqq'];echo "&site=qq&menu=yes\" id=\"myWin\" class=\"my fr\">客服</a>";echo "
			<!--游戏区域-->";echo "
			<div class=\"main\">";echo "
				<h2>今日还有 <span id=\"change\">";echo $conf["cjcishu"];echo "</span>次翻牌机会</h2>";echo "
				<ul class=\"box\">";echo "
					<li class=\"animate1\"><img src=\"ds/cj/picture/pattern1.png\"></li>";echo "
					<li class=\"animate2\"><img src=\"ds/cj/picture/pattern2.png\"></li>";echo "
					<li class=\"animate3\"><img src=\"ds/cj/picture/pattern3.png\"></li>";echo "
					<li class=\"animate4\"><img src=\"ds/cj/picture/pattern4.png\"></li>";echo "
					<li class=\"animate5\"><img src=\"ds/cj/picture/pattern1.png\"></li>";echo "
					<li><img src=\"ds/cj/picture/pattern2.png\"></li>";echo "
				</ul>";echo "
				<!--奖品展示-->";echo "
				<div class=\"awards\">";echo "
					<div class=\"swiper-container\">";echo "
						<ul class=\"swiper-wrapper\">";echo "
						";unset($X4gtI9W);$img="'assets/img/Product/default.png'";unset($X4gtI9W);$rs=$DB->query("SELECT s.shopimg FROM pre_gift as j,pre_tools as s WHERE j.tid=s.tid");X4gx3:unset($X4gtI9W);$res=$rs->fetch();unset($X4gtIvPbN9X);$X4gIYCE="JXqVx";$X4gbN9Y=!strlen($X4gIYCE);if($X4gbN9Y)goto X4geWjgx6;$X4gbN9W="__file__"==5;if($X4gbN9W)goto X4geWjgx6;if($res)goto X4geWjgx6;goto X4gldMhx6;X4geWjgx6:$X4gMWZC=9*0;switch($X4gMWZC){case 1:return bClass($url,$bind,$depr);case 2:return bController($url,$bind,$depr);case 3:return bNamespace($url,$bind,$depr);}$X4g9W='<li class="swiper-slide"><img src="' . $res['shopimg'];$X4g9X=$X4g9W . '" onerror="this.src=';$X4g9Y=$X4g9X . $img;$X4g9Z=$X4g9Y . ';this.onerror=null"></li>';echo $X4g9Z;goto X4gx3;goto X4gx5;X4gldMhx6:X4gx5:X4gx4:echo "		";echo "
						</ul>";echo "
					</div>";echo "
				</div>";echo "
			</div>";echo "
			<div id=\"mask-card\"></div>";echo "
		</div>";echo "
		<iframe frameborder=\"no\" border=\"0\" marginwidth=\"0\" marginheight=\"0\" width=330 height=86 src=\"//music.163.com/outchain/player?type=2&id=493911&auto=1&height=66\" style=\"display: none;\"></iframe>";echo "
		<script src=\"//lib.baomitu.com/jquery/1.12.4/jquery.min.js\"></script>";echo "
		<script src=\"//lib.baomitu.com/jquery.lazyload/1.9.1/jquery.lazyload.min.js\"></script>";echo "
		<script src=\"//lib.baomitu.com/jquery-cookie/1.4.1/jquery.cookie.min.js\"></script>";echo "
		<script src=\"//lib.baomitu.com/layer/2.3/layer.js\"></script>";echo "
		<script src=\"ds/hui/js/hui.js\"></script>";echo "
		<script type=\"text/javascript\">";echo "
		var isModal=false;";echo "
		var homepage=true;";echo "
		var hashsalt=";echo $addsalt_js;echo ";";echo "
		</script>";echo "
		<script src=\"ds/cj/js/1.js\"></script>";echo "
	</body>";echo "
</html>";echo "
";
?>