<?php $this->need('header.php'); ?>

	<h2 align="center" style="margin:200px auto;color:#787878;font-size:30px;">一片空白</h2>

	<?php $this->need('footer.php'); ?>
