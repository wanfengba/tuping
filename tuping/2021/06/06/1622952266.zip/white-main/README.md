## white

typecho 主题 白

下载解压后将文件夹改名为`white`， 放入/usr/themes，进入后台启用。

添加独立页面`bb.html` `archive.html` `links.html` `about.html` 分别对应底部导航栏的 `留言` `归档` `邻居` `关于`


推荐安装插件： Links | CommentToMail


## 更新记录   

|  日期   | 更新内容  |
|  ----  | ----  |
| 2021-05-23  | 增加又拍云联盟开关，开启后底部展示|
| 2021-02-21  | 导航栏位置可选，页角阴影设置，修复代码块样式丢失问题，文章标题自豪差异更明显，调整手机和ipad适配问题|
| 2021-02-18  | 修复部分样式      |
| 2020-12-30  | 单反引号代码块适配 |
| 2020-12-26  | 评论新增状态进度条 |
| 2020-12-22  | 修复评论按钮bug，新增邮件接收开关，优化部分样式 |

## 在线演示

https://psyduck.liujiayang.cn/   


## 截图

![截图](https://www.liujiayang.cn/psyduck/screenshot.png)   

## 感谢  

特别鸣谢 [youranreus](https://github.com/youranreus/G) 的G主题

**本主题由 G主题 魔改**
