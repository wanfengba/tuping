<?php
/**
*OwO
*
* @author      psyduck
*/
?>
<div class="OwO OwO-open" id="qaq">
   <div class="OwO-body" id="OwO-body">
    <ul id="OwO-pp" class="OwO-items OwO-items-emoticon OwO-items-show" style="max-height: 197px;">
      <li class="OwO-item" onclick="Smilies.grin('@(huaji_han)');"><img src="<?php $this->options->themeUrl('IMG/bq/'); ?>huaji_han.png" /></li>
      <li class="OwO-item" onclick="Smilies.grin('@(huaji_mj)');"><img src="<?php $this->options->themeUrl('IMG/bq/'); ?>huaji_mj.png" /></li>
      <li class="OwO-item" onclick="Smilies.grin('@(huaji_djy)');"><img src="<?php $this->options->themeUrl('IMG/bq/'); ?>huaji_djy.png" /></li>
      <li class="OwO-item" onclick="Smilies.grin('@(huaji_pc)');"><img src="<?php $this->options->themeUrl('IMG/bq/'); ?>huaji_pc.png" /></li>
      <li class="OwO-item" onclick="Smilies.grin('@(huaji_shang)');"><img src="<?php $this->options->themeUrl('IMG/bq/'); ?>huaji_shang.png" /></li>
      <li class="OwO-item" onclick="Smilies.grin('@(huaji_xiao)');"><img src="<?php $this->options->themeUrl('IMG/bq/'); ?>huaji_xiao.png" /></li>
      <li class="OwO-item" onclick="Smilies.grin('@(toukan)');"><img src="<?php $this->options->themeUrl('IMG/bq/'); ?>toukan.png" /></li>
      <li class="OwO-item" onclick="Smilies.grin('@(biexiao)');"><img src="<?php $this->options->themeUrl('IMG/bq/'); ?>biexiao.png" /></li>
      <li class="OwO-item" onclick="Smilies.grin('@(hemenjiu)');"><img src="<?php $this->options->themeUrl('IMG/bq/'); ?>hemenjiu.png" /></li>
      <li class="OwO-item" onclick="Smilies.grin('@(chigua2)');"><img src="<?php $this->options->themeUrl('IMG/bq/'); ?>chigua2.png" /></li>
      <li class="OwO-item" onclick="Smilies.grin('@(chaoquan_love)');"><img src="<?php $this->options->themeUrl('IMG/bq/'); ?>chaoquan_love.png" /></li>
      <li class="OwO-item" onclick="Smilies.grin('@(chaiquan_red_1)');"><img src="<?php $this->options->themeUrl('IMG/bq/'); ?>chaiquan_red_1.png" /></li>
      <li class="OwO-item" onclick="Smilies.grin('@(chaiquan_melon)');"><img src="<?php $this->options->themeUrl('IMG/bq/'); ?>chaiquan_melon.png" /></li>
      <li class="OwO-item" onclick="Smilies.grin('@(chaiquan_mask)');"><img src="<?php $this->options->themeUrl('IMG/bq/'); ?>chaiquan_mask.png" /></li>
      <li class="OwO-item" onclick="Smilies.grin('@(chaiquan_hufen)');"><img src="<?php $this->options->themeUrl('IMG/bq/'); ?>chaiquan_hufen.png" /></li>
      <li class="OwO-item" onclick="Smilies.grin('@(chaiquan_han)');"><img src="<?php $this->options->themeUrl('IMG/bq/'); ?>chaiquan_han.png" /></li>
      <li class="OwO-item" onclick="Smilies.grin('@(chaiquan_gh)');"><img src="<?php $this->options->themeUrl('IMG/bq/'); ?>chaiquan_gh.png" /></li>
      <li class="OwO-item" onclick="Smilies.grin('@(chaiquan_3)');"><img src="<?php $this->options->themeUrl('IMG/bq/'); ?>chaiquan_3.png" /></li>
     <li class="OwO-item" onclick="Smilies.grin('@(chaiquan)');"><img src="<?php $this->options->themeUrl('IMG/bq/'); ?>chaiquan.png" /></li>
     <li class="OwO-item" onclick="Smilies.grin('@(chaiquanbugaoxin)');"><img src="<?php $this->options->themeUrl('IMG/bq/'); ?>chaiquanbugaoxin.png" /></li>
     <li class="OwO-item" onclick="Smilies.grin('@(chaiquanzaijian)');"><img src="<?php $this->options->themeUrl('IMG/bq/'); ?>chaiquanzaijian.png" /></li>
     <li class="OwO-item" onclick="Smilies.grin('@(chaiquanku)');"><img src="<?php $this->options->themeUrl('IMG/bq/'); ?>chaiquanku.png" /></li>
     <li class="OwO-item" onclick="Smilies.grin('@(hehe)');"><img src="<?php $this->options->themeUrl('IMG/bq/'); ?>hehe.png" /></li>
     <li class="OwO-item" onclick="Smilies.grin('@(haha)');"><img src="<?php $this->options->themeUrl('IMG/bq/'); ?>haha.png" /></li>
     <li class="OwO-item" onclick="Smilies.grin('@(tushe)');"><img src="<?php $this->options->themeUrl('IMG/bq/'); ?>tushe.png" /></li>
     <li class="OwO-item" onclick="Smilies.grin('@(taikaixin)');"><img src="<?php $this->options->themeUrl('IMG/bq/'); ?>taikaixin.png" /></li>
     <li class="OwO-item" onclick="Smilies.grin('@(xiaoyan)');"><img src="<?php $this->options->themeUrl('IMG/bq/'); ?>xiaoyan.png" /></li>
     <li class="OwO-item" onclick="Smilies.grin('@(huaxin)');"><img src="<?php $this->options->themeUrl('IMG/bq/'); ?>huaxin.png" /></li>
     <li class="OwO-item" onclick="Smilies.grin('@(xiaoguai)');"><img src="<?php $this->options->themeUrl('IMG/bq/'); ?>xiaoguai.png" /></li>
     <li class="OwO-item" onclick="Smilies.grin('@(guai)');"><img src="<?php $this->options->themeUrl('IMG/bq/'); ?>guai.png" /></li>
     <li class="OwO-item" onclick="Smilies.grin('@(wuzuixiao)');"><img src="<?php $this->options->themeUrl('IMG/bq/'); ?>wuzuixiao.png" /></li>
     <li class="OwO-item" onclick="Smilies.grin('@(huaji)');"><img src="<?php $this->options->themeUrl('IMG/bq/'); ?>huaji.png" /></li>
     <li class="OwO-item" onclick="Smilies.grin('@(nidongde)');"><img src="<?php $this->options->themeUrl('IMG/bq/'); ?>nidongde.png" /></li>
     <li class="OwO-item" onclick="Smilies.grin('@(bugaoxin)');"><img src="<?php $this->options->themeUrl('IMG/bq/'); ?>bugaoxin.png" /></li>
     <li class="OwO-item" onclick="Smilies.grin('@(nu)');"><img src="<?php $this->options->themeUrl('IMG/bq/'); ?>nu.png" /></li>
     <li class="OwO-item" onclick="Smilies.grin('@(han)');"><img src="<?php $this->options->themeUrl('IMG/bq/'); ?>han.png" /></li>
     <li class="OwO-item" onclick="Smilies.grin('@(heixian)');"><img src="<?php $this->options->themeUrl('IMG/bq/'); ?>heixian.png" /></li>
     <li class="OwO-item" onclick="Smilies.grin('@(lei)');"><img src="<?php $this->options->themeUrl('IMG/bq/'); ?>lei.png" /></li>
     <li class="OwO-item" onclick="Smilies.grin('@(zhenbang)');"><img src="<?php $this->options->themeUrl('IMG/bq/'); ?>zhenbang.png" /></li>
     <li class="OwO-item" onclick="Smilies.grin('@(pen)');"><img src="<?php $this->options->themeUrl('IMG/bq/'); ?>pen.png" /></li>
     <li class="OwO-item" onclick="Smilies.grin('@(jingku)');"><img src="<?php $this->options->themeUrl('IMG/bq/'); ?>jingku.png" /></li>
     <li class="OwO-item" onclick="Smilies.grin('@(yinxian)');"><img src="<?php $this->options->themeUrl('IMG/bq/'); ?>yinxian.png" /></li>
     <li class="OwO-item" onclick="Smilies.grin('@(bishi)');"><img src="<?php $this->options->themeUrl('IMG/bq/'); ?>bishi.png" /></li>
     <li class="OwO-item" onclick="Smilies.grin('@(ku)');"><img src="<?php $this->options->themeUrl('IMG/bq/'); ?>ku.png" /></li>
     <li class="OwO-item" onclick="Smilies.grin('@(a)');"><img src="<?php $this->options->themeUrl('IMG/bq/'); ?>a.png" /></li>
     <li class="OwO-item" onclick="Smilies.grin('@(kuanghan)');"><img src="<?php $this->options->themeUrl('IMG/bq/'); ?>kuanghan.png" /></li>
     <li class="OwO-item" onclick="Smilies.grin('@(what)');"><img src="<?php $this->options->themeUrl('IMG/bq/'); ?>what.png" /></li>
     <li class="OwO-item" onclick="Smilies.grin('@(yiwen)');"><img src="<?php $this->options->themeUrl('IMG/bq/'); ?>yiwen.png" /></li>
     <li class="OwO-item" onclick="Smilies.grin('@(suanshuang)');"><img src="<?php $this->options->themeUrl('IMG/bq/'); ?>suanshuang.png" /></li>
     <li class="OwO-item" onclick="Smilies.grin('@(yamiedie)');"><img src="<?php $this->options->themeUrl('IMG/bq/'); ?>yamiedie.png" /></li>
     <li class="OwO-item" onclick="Smilies.grin('@(weiqu)');"><img src="<?php $this->options->themeUrl('IMG/bq/'); ?>weiqu.png" /></li>
     <li class="OwO-item" onclick="Smilies.grin('@(jingya)');"><img src="<?php $this->options->themeUrl('IMG/bq/'); ?>jingya.png" /></li>
     <li class="OwO-item" onclick="Smilies.grin('@(shuijiao)');"><img src="<?php $this->options->themeUrl('IMG/bq/'); ?>shuijiao.png" /></li>
     <li class="OwO-item" onclick="Smilies.grin('@(xiaoniao)');"><img src="<?php $this->options->themeUrl('IMG/bq/'); ?>xiaoniao.png" /></li>
     <li class="OwO-item" onclick="Smilies.grin('@(wabi)');"><img src="<?php $this->options->themeUrl('IMG/bq/'); ?>wabi.png" /></li>
     <li class="OwO-item" onclick="Smilies.grin('@(tu)');"><img src="<?php $this->options->themeUrl('IMG/bq/'); ?>tu.png" /></li>
     <li class="OwO-item" onclick="Smilies.grin('@(xili)');"><img src="<?php $this->options->themeUrl('IMG/bq/'); ?>xili.png" /></li>
     <li class="OwO-item" onclick="Smilies.grin('@(xiaohonglian)');"><img src="<?php $this->options->themeUrl('IMG/bq/'); ?>xiaohonglian.png" /></li>
     <li class="OwO-item" onclick="Smilies.grin('@(landeli)');"><img src="<?php $this->options->themeUrl('IMG/bq/'); ?>landeli.png" /></li>
     <li class="OwO-item" onclick="Smilies.grin('@(mianqiang)');"><img src="<?php $this->options->themeUrl('IMG/bq/'); ?>mianqiang.png" /></li>
     <li class="OwO-item" onclick="Smilies.grin('@(aixin)');"><img src="<?php $this->options->themeUrl('IMG/bq/'); ?>aixin.png" /></li>
     <li class="OwO-item" onclick="Smilies.grin('@(xinsui)');"><img src="<?php $this->options->themeUrl('IMG/bq/'); ?>xinsui.png" /></li>
     <li class="OwO-item" onclick="Smilies.grin('@(meigui)');"><img src="<?php $this->options->themeUrl('IMG/bq/'); ?>meigui.png" /></li>
     <li class="OwO-item" onclick="Smilies.grin('@(liwu)');"><img src="<?php $this->options->themeUrl('IMG/bq/'); ?>liwu.png" /></li>
     <li class="OwO-item" onclick="Smilies.grin('@(caihong)');"><img src="<?php $this->options->themeUrl('IMG/bq/'); ?>caihong.png" /></li>
     <li class="OwO-item" onclick="Smilies.grin('@(taiyang)');"><img src="<?php $this->options->themeUrl('IMG/bq/'); ?>taiyang.png" /></li>
     <li class="OwO-item" onclick="Smilies.grin('@(xinxinyueliang)');"><img src="<?php $this->options->themeUrl('IMG/bq/'); ?>xinxinyueliang.png" /></li>
     <li class="OwO-item" onclick="Smilies.grin('@(qianbi)');"><img src="<?php $this->options->themeUrl('IMG/bq/'); ?>qianbi.png" /></li>
     <li class="OwO-item" onclick="Smilies.grin('@(chabei)');"><img src="<?php $this->options->themeUrl('IMG/bq/'); ?>chabei.png" /></li>
     <li class="OwO-item" onclick="Smilies.grin('@(dangao)');"><img src="<?php $this->options->themeUrl('IMG/bq/'); ?>dangao.png" /></li>
     <li class="OwO-item" onclick="Smilies.grin('@(damuzhi)');"><img src="<?php $this->options->themeUrl('IMG/bq/'); ?>damuzhi.png" /></li>
     <li class="OwO-item" onclick="Smilies.grin('@(shengli)');"><img src="<?php $this->options->themeUrl('IMG/bq/'); ?>shengli.png" /></li>
     <li class="OwO-item" onclick="Smilies.grin('@(haha)');"><img src="<?php $this->options->themeUrl('IMG/bq/'); ?>haha.png" /></li>
     <li class="OwO-item" onclick="Smilies.grin('@(OK)');"><img src="<?php $this->options->themeUrl('IMG/bq/'); ?>OK.png" /></li>
     <li class="OwO-item" onclick="Smilies.grin('@(shafa)');"><img src="<?php $this->options->themeUrl('IMG/bq/'); ?>shafa.png" /></li>
     <li class="OwO-item" onclick="Smilies.grin('@(shouzhi)');"><img src="<?php $this->options->themeUrl('IMG/bq/'); ?>shouzhi.png" /></li>
     <li class="OwO-item" onclick="Smilies.grin('@(xiangjiao)');"><img src="<?php $this->options->themeUrl('IMG/bq/'); ?>xiangjiao.png" /></li>
     <li class="OwO-item" onclick="Smilies.grin('@(bianbian)');"><img src="<?php $this->options->themeUrl('IMG/bq/'); ?>bianbian.png" /></li>
     <li class="OwO-item" onclick="Smilies.grin('@(yaowan)');"><img src="<?php $this->options->themeUrl('IMG/bq/'); ?>yaowan.png" /></li>
     <li class="OwO-item" onclick="Smilies.grin('@(hlj)');"><img src="<?php $this->options->themeUrl('IMG/bq/'); ?>hlj.png" /></li>
     <li class="OwO-item" onclick="Smilies.grin('@(lazhu)');"><img src="<?php $this->options->themeUrl('IMG/bq/'); ?>lazhu.png" /></li>
     <li class="OwO-item" onclick="Smilies.grin('@(yingyue)');"><img src="<?php $this->options->themeUrl('IMG/bq/'); ?>yingyue.png" /></li>
     <li class="OwO-item" onclick="Smilies.grin('@(dengpao)');"><img src="<?php $this->options->themeUrl('IMG/bq/'); ?>dengpao.png" /></li>
    </ul>
   </div>
  </div>
