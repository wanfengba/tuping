<a href="<?php Helper::options()->siteUrl()?>">首页</a>
				
<a href="<?php Helper::options()->siteUrl()?>bb.html">留言</a>

<a href="<?php Helper::options()->siteUrl()?>archive.html">归档</a>

<a href="<?php Helper::options()->siteUrl()?>links.html">邻居</a>

<a href="<?php Helper::options()->siteUrl()?>about.html">关于</a>