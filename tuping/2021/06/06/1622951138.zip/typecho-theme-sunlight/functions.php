<?php
if (!defined('__TYPECHO_ROOT_DIR__')) exit;

function themeConfig($form)
{

    $icon = new Typecho_Widget_Helper_Form_Element_Text('favicon_url', NULL, NULL, _t('Favicon地址'), _t('在这里输入Favicon地址'));
    $form->addInput($icon);

    $icp = new Typecho_Widget_Helper_Form_Element_Text('icp', NULL, NULL, _t('ICP备案号'), _t('在这里输入ICP备案号'));
    $form->addInput($icp);

    $police = new Typecho_Widget_Helper_Form_Element_Text('police', NULL, NULL, _t('公安网备案'), _t('在这里输入公安网备案号'));
    $form->addInput($police);

    $police_link = new Typecho_Widget_Helper_Form_Element_Text('police_link', NULL, NULL, _t('公安网备案地址'), _t('在这里输入公安网备案地址'));
    $form->addInput($police_link);

    // $logoUrl = new Typecho_Widget_Helper_Form_Element_Text('logoUrl', NULL, NULL, _t('站点 LOGO 地址'), _t('在这里填入一个图片 URL 地址, 以在网站标题前加上一个 LOGO'));
    // $form->addInput($logoUrl);

    // $sidebarBlock = new Typecho_Widget_Helper_Form_Element_Checkbox('sidebarBlock', 
    // array('ShowRecentPosts' => _t('显示最新文章'),
    // 'ShowRecentComments' => _t('显示最近回复'),
    // 'ShowCategory' => _t('显示分类'),
    // 'ShowArchive' => _t('显示归档'),
    // 'ShowOther' => _t('显示其它杂项')),
    // array('ShowRecentPosts', 'ShowRecentComments', 'ShowCategory', 'ShowArchive', 'ShowOther'), _t('侧边栏显示'));

    // $form->addInput($sidebarBlock->multiMode());
}


/*
function themeFields($layout) {
    $logoUrl = new Typecho_Widget_Helper_Form_Element_Text('logoUrl', NULL, NULL, _t('站点LOGO地址'), _t('在这里填入一个图片URL地址, 以在网站标题前加上一个LOGO'));
    $layout->addItem($logoUrl);
}
*/

