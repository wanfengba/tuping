<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<?php $this->need('header.php'); ?>

<link rel="stylesheet" href="<?php $this->options->themeUrl('/static/css/posts.css') ?>">

<div id="pjax-container" class="container">
    <article class="post-main">
        <div class="post-title">
            <a href="<?php $this->permalink() ?>"><?php $this->title() ?></a>
        </div>
        <div class="post-desc">
            · <?php $this->date(); ?> ·
        </div>
        <div class="post-content">
            <p>
                <?php $this->content(); ?>
            </p>
        </div>
    </article>
</div>

<?php $this->need('footer.php'); ?>