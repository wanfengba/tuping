<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<?php $this->need('header.php'); ?>

<div id="pjax-container" class="container">
    <h2 class="archive-title"><?php $this->archiveTitle(array(
                                    'category'  =>  _t('分类『%s』下的文章'),
                                    'search'    =>  _t('包含关键字『%s』的文章'),
                                    'tag'       =>  _t('标签『%s』下的文章'),
                                    'author'    =>  _t('『%s』发布的文章')
                                ), '', ''); ?></h2>
    <div class="post-main">
        <?php while ($this->next()) : ?>
            <div class="post-card">
                <div class="post-title"><a href="<?php $this->permalink() ?>"><?php $this->title() ?></a></div>
                <div class="post-content">
                    <p><?php $this->excerpt('180', '...');  ?></p>
                </div>
                <div class="post-footer">发布于 · <?php $this->date(); ?> · <?php if (count($this->tags) == 0) : ?>
                        <?php _e('# '); ?>
                        <?php $this->category(' # ', true, 'none'); ?>
                    <?php else : ?>
                        <?php _e('# '); ?>
                        <?php $this->tags(' # ', true, 'none'); ?>
                    <?php endif; ?>
                </div>
            </div>
        <?php endwhile ?>
    </div>

    <div class="post-pagination">
        <?php $this->pageLink('上一页'); ?>
        当前页码：<?php if ($this->_currentPage > 1) echo $this->_currentPage;
                else echo 1; ?>
        总页码：<?php echo ceil($this->getTotal() / $this->parameter->pageSize); ?>
        <?php $this->pageLink('下一页', 'next'); ?>
    </div>

</div>

<?php $this->need('footer.php'); ?>