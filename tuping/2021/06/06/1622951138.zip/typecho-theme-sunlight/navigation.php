<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>

<header>
    <div class="container">
        <div class="site-navbar">
            <a class="site-title" href="<?php $this->options->siteUrl(); ?>"><?php $this->options->title(); ?></a>
            <div class="menu-container">
                <a class="active" href="<?php $this->options->siteUrl(); ?>">首页</a>
                <!-- 输出所有页面 -->
                <?php $this->widget('Widget_Contents_Page_List')
                    ->parse('<a href="{permalink}">{title}</a>'); ?>
                <div class="search-container">
                    <form id="search" method="post" action="<?php $this->options->siteUrl(); ?>" role="search">
                        <input type="search" id="s" name="s" placeholder="<?php _e('输入关键字搜索'); ?>" />
                    </form>
                </div>
            </div>
        </div>
    </div>
</header>