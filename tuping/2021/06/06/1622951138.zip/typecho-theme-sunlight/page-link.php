<?php

/**
 * 友链模板
 * 
 * @package custom
 */
if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<?php $this->need('header.php'); ?>

<div class="container">
    <div class="post-main">
        <div class="post-title">
            <a href="<?php $this->permalink() ?>"><?php $this->title() ?></a>
        </div>
        <div class="post-desc">
            · <?php $this->date(); ?> ·
        </div>
        <div class="post-content">
            <?php $this->content(); ?>
        </div>
    </div>
</div>

<?php $this->need('footer.php'); ?>