<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>

<footer id="footer" role="contentinfo">
    <div class="copyright">Theme by <a href="https://byang.site" target="_blank">Kingsr</a>, Powered by <a href="http://typecho.org/" target="_blank">Typecho</a> | <a href="<?php $this->options->feedUrl(); ?>" target="_blank">RSS</a></div>
    <div class="icp">
        <?php if ($this->options->icp) : ?>
            <a target="_blank" href="https://beian.miit.gov.cn/"><?php $this->options->icp(); ?></a>
        <?php endif; ?>
        <br />
        <?php if ($this->options->police) : ?>
            <a target="_blank" href="<?php $this->options->police_link(); ?>"><?php $this->options->police(); ?></a>
        <?php endif; ?>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.min.js" integrity="sha384-nsg8ua9HAw1y0W1btsyWgBklPnCUAFLuTMS2G72MMONqmOymq585AcH49TLBQObG" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/jquery-pjax@2.0.1/jquery.pjax.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/nprogress@0.2.0/nprogress.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/toastr@2.1.4/toastr.min.js"></script>
<?php if ($this->is('post')) : ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/prism/1.23.0/prism.min.js" integrity="sha512-YBk7HhgDZvBxmtOfUdvX0z8IH2d10Hp3aEygaMNhtF8fSOvBZ16D/1bXZTJV6ndk/L/DlXxYStP8jrF77v2MIg==" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/clipboard@2.0.8/dist/clipboard.min.js"></script>
    <script>
        var cp = new ClipboardJS('#share', {
            text: function() {
                return "<?php $this->title(); ?>\n<?php $this->permalink(); ?>\n（出处：<?php $this->options->title(); ?>）";
            }
        })
        cp.on('success', () => {
            toastr.success("复制成功，请在需要分享的地方粘贴")
        })
        cp.on('error', () => {
            toastr.error("复制失败，请重试")
        })
    </script>
<?php endif ?>
<script src="<?php $this->options->themeUrl("/static/js/app.js"); ?>"></script>
<script>
    $(document).pjax('a[href^="<?php $this->options->siteUrl() ?>"]:not(a[target="_blank"], a[no-pjax])', {
        container: '#pjax-container',
        fragment: '#pjax-container',
        timeout: 3000
    }).on('pjax:send',
        function() {
            NProgress.start(); //加载动画效果开始
        }).on('pjax:complete',
        function() {
            NProgress.done(); //加载动画效果结束
        });
</script>
<?php $this->footer(); ?>

</body>

</html>