<?php

/**
 * 一套简约的Typecho主题，响应式、PJAX、简约大方
 * 
 * @package Sublight Theme
 * @author 北林
 * @version 1.0
 * @link https://byang.site
 */

if (!defined('__TYPECHO_ROOT_DIR__')) exit;
$this->need('header.php');
?>

<link rel="stylesheet" href="<?php $this->options->themeUrl('/static/css/index.css'); ?>">

<div id="pjax-container" class="container">
    <div class="list-main">
        <?php while ($this->next()) : ?>
            <div class="list-card">
                <div class="list-title"><a href="<?php $this->permalink() ?>"><?php $this->title() ?></a></div>
                <div class="list-content">
                    <p><?php $this->excerpt('180', '...');  ?></p>
                </div>
                <div class="list-footer">发布于 · <?php $this->date(); ?> · <?php if (count($this->tags) == 0) : ?>
                        <?php _e('# '); ?>
                        <?php $this->category(' # ', true, 'none'); ?>
                    <?php else : ?>
                        <?php _e('# '); ?>
                        <?php $this->tags(' # ', true, 'none'); ?>
                    <?php endif; ?>
                </div>
            </div>
        <?php endwhile ?>
    </div>

    <div class="list-pagination">
        <?php $this->pageLink('上一页'); ?>
        当前页码：<?php if ($this->_currentPage > 1) echo $this->_currentPage;
                else echo 1; ?>
        总页码：<?php echo ceil($this->getTotal() / $this->parameter->pageSize); ?>
        <?php $this->pageLink('下一页', 'next'); ?>
    </div>

</div>

<?php $this->need('footer.php'); ?>