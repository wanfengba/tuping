<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<?php $this->need('header.php'); ?>

<div id="pjax-container" class="container">
    <article class="post-main">
        <div class="post-title">
            <a href="<?php $this->permalink() ?>"><?php $this->title() ?></a>
        </div>
        <div class="post-desc">
            · <?php $this->date(); ?> · <?php if (count($this->tags) == 0) : ?>
                <?php _e('# '); ?>
                <?php $this->category(' # ', true, 'none'); ?>
            <?php else : ?>
                <?php _e('# '); ?>
                <?php $this->tags(' # ', true, 'none'); ?>
            <?php endif; ?>
        </div>
        <div class="post-content">
            <p>
                <?php $this->content(); ?>
            </p>
        </div>

        <div class="post-footer">
            <div class="left">
                <div class="post-footer-updated">
                    <i class="iconfont icon-history"></i> 最后修改于：
                    <?php echo date('Y-m-d H:i:s', $this->modified); ?>
                </div>
                <div class="post-footer-share">
                    <a title="Share" id="share" href="javascript:;">分享到社交平台 <i class="iconfont icon-appendix"></i></a>
                </div>
            </div>
            <!-- <button id="post-btn-reward" class="btn-reward">赏</button> -->
        </div>
    </article>

    <div class="post-near">
        <div><strong>上一篇: </strong><?php $this->thePrev('%s', '没有了'); ?></div>
        <div><strong>下一篇: </strong><?php $this->theNext('%s', '没有了'); ?></div>
    </div>

    <?php $this->need('comments.php'); ?>

    <div title="返回顶部" id="goto-top" class="goto-top">
        <i class="iconfont icon-top-btn"></i>
    </div>
</div>
<?php $this->need('footer.php'); ?>