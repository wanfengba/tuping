<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<?php function threadedComments($comments, $options)
{
    $commentClass = '';
    if ($comments->authorId) {
        if ($comments->authorId == $comments->ownerId) {
            $commentClass .= ' comment-by-author';  //如果是文章作者的评论添加 .comment-by-author 样式
        } else {
            $commentClass .= ' comment-by-user';  //如果是评论作者的添加 .comment-by-user 样式
        }
    }
    $commentLevelClass = $comments->_levels > 0 ? ' comment-child' : ' comment-parent';  //评论层数大于0为子级，否则是父级
?>
    <div id="list-<?php $comments->theId(); ?>">
        <div class="comment-avatar">
            <?php $comments->gravatar('48', ''); ?>
        </div>
        <div id="<?php $comments->theId(); ?>" class="comment-content">
            <div class="comment-author"><?php $comments->author(); ?></div>
            <div class="comment-text">
                <?php $comments->content(); ?>
            </div>
            <div class="comment-footer">
                <time><?php $comments->date('Y-m-d H:i'); ?></time>
                <a href="javascript:;"><?php $comments->reply("回复"); ?> <i class="iconfont icon-reply"></i></a>
            </div>
            <?php if ($comments->children) { ?>
                <div class="comment-childrens">
                    <?php $comments->threadedComments($options); ?>
                </div>
            <?php } ?>
        </div>
    </div>

<?php } ?>

<?php $this->comments()->to($comments); ?>
<div id="<?php $this->respondId(); ?>" class="comments-container container">
    <?php if ($this->allow('comment')) : ?>
        <div class="comment-form-title"> <i class="iconfont icon-msg-chat"></i> 添加新评论</div>
        <form id="comment-form" action="<?php $this->commentUrl() ?>" method="post" role="form">
            <div class="comment-form-head">
                <?php if ($this->user->hasLogin()) : ?>
                    <input type="hidden" name="isLogin" value="1">
                    <p><?php _e('登录身份: '); ?><a href="<?php $this->options->profileUrl(); ?>"><?php $this->user->screenName(); ?></a>. <a href="<?php $this->options->logoutUrl(); ?>" title="Logout"><?php _e('退出'); ?></a></p>
                <?php else : ?>
                    <div class="input-group">
                        <input value="<?php $this->remember('author'); ?>" placeholder="尊姓大名？（昵称）" class="comment-input" type="text" name="author" id="author" required>
                    </div>
                    <div class="input-group">
                        <input value="<?php $this->remember('mail'); ?>" placeholder="怎么联系？（邮箱）" class="comment-input" type="email" name="mail" id="mail" <?php if ($this->options->commentsRequireMail) : ?> required<?php endif; ?>>
                    </div>
                    <div class="input-group">
                        <input value="<?php $this->remember('url'); ?>" placeholder="来自哪里？（网站）" class="comment-input" type="url" name="url" id="url" <?php if ($this->options->commentsRequireURL) : ?> required<?php endif; ?>>
                    </div>
                <?php endif; ?>
            </div>
            <div class="comment-form-content">
                <textarea placeholder="请输入内容" name="text" id="content" cols="30" rows="5" required><?php $this->remember('text'); ?></textarea>
            </div>
            <div class="cancel-comment-reply">
                <?php $comments->cancelReply(); ?>
            </div>
            <div class="comment-form-menu">
                <button type="submit">提交</button>
            </div>
        </form>
    <?php else : ?>
        <h3><?php _e('评论已关闭'); ?></h3>
    <?php endif; ?>

    <?php if ($comments->have()) : ?>
        <?php $comments->listComments(); ?>
        <?php $comments->pageNav('&laquo; 前一页', '后一页 &raquo;'); ?>
    <?php endif; ?>
</div>