window.onscroll = () => {
    if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
        $("#goto-top").show();
    } else {
        $("#goto-top").hide();
    }
}

$("#goto-top").on('click', () => {
    document.body.scrollTop = 0;
    document.documentElement.scrollTop = 0;
})

$.fn.serializeObject = function () {
    var o = {};
    var a = this.serializeArray();
    $.each(a, function () {
        if (o[this.name]) {
            if (!o[this.name].push) {
                o[this.name] = [o[this.name]];
            }
            o[this.name].push(this.value || '');
        } else {
            o[this.name] = this.value || '';
        }
    });
    return o;
};

function isEmail(strEmail) {
    if (strEmail.search(/^\w+((-\w+)|(\.\w+))*\@[A-Za-z0-9]+((\.|-)[A-Za-z0-9]+)*\.[A-Za-z0-9]+$/) != -1)
        return true;
    else
        return false;
}

// $("#comment-form").submit(function () {
//     const dataArr = $("#comment-form").serializeObject();
//     if (dataArr.isLogin != '1') {
//         if (!isEmail(dataArr.email)) {
//             toastr.error("邮箱格式错误");
//             return false;
//         }
//     } else {
//         if (dataArr.text == null) {
//             toastr.error("评论不能为空~");
//             return false;
//         }
//     }
//     const data = $("#comment-form").serialize();
//     $.post($(this).attr('action'), data, res => {})
//     toastr.success("评论成功");
//     return false;
// })

$("#post-btn-reward").on('click', () => {
    
})