<?php
require_once dirname(__FILE__) . '/config.inc.php';
$sgj = $db->fetchAll($db->select()->from('table.contents')->where('slug = ?',cross));
$sgjid = $sgj['0']['cid'];
$user = $db->fetchAll($db->select()->from('table.users')->limit(1));
$name = $user['0']['screenName'];
$time = $_POST["time"];
$content = $_POST["content"];
$insert = $db->insert('table.comments')->rows(array("cid" => $sgjid,"created" => $time,"author" => $name,"authorId" =>"1","ownerId" => "1", "url"=>"https://www.wenxing.pro", "mail"=>"7395521@qq.com","IP"=>"127.0.0.1", "text"=> $content,"agent"=>"weChat"));
$insertId = $db->query($insert);
?>