﻿<?php
/**
 * 闲言碎语
 * 
 * @package custom
 *
 */
if (!defined('__TYPECHO_ROOT_DIR__')) exit;
 $this->need('header.php'); 
?> 




<meta charset="utf-8">

<!--<style type="text/css">
</style>-->
<article>


<div id="comments" >
    <?php if($this->allow('comment')): ?>
    <div class="comments-inner">
        <h3><?php $this->commentsNum(_t('岁月轻语'), _t('岁月轻语'), _t('岁月轻语')); ?></h3>
            <?php endif; ?>
<?php if($this->allow('comment')): ?>
    <div id="<?php $this->respondId(); ?>" class="respond">
        
        <?php if($this->user->hasLogin()): ?>  
        <div style="padding-left: 40px">
        <form  style="padding-left: 150px" class="form" method="post" action="<?php echo str_replace("http","https",$this->commentUrl()); ?>" id="comment-form">
            <div class="form-group">
               
                <textarea rows="4" name="text" id="textarea" class="form-control" required ><?php $this->remember('text'); ?></textarea>
            </div>
            <?php TeComment_Plugin::showTool();?>
            
          
            <div class="form-group" style="padding-left: 400px">
                <button type="submit" class="btn btn-info"><?php _e('轻语'); ?></button>
                 <a style="padding-left: 10px" href="<?php $this->options->profileUrl(); ?>"><?php $this->user->screenName(); ?></a>. <a href="<?php $this->options->logoutUrl(); ?>" title="Logout"><?php _e('退出'); ?> &raquo;</a>
            </div>
            
        </form>
        </div>
        <?php endif; ?> 
    </div>
    <?php else: ?>
    <h3><?php _e('评论已关闭'); ?></h3>
    <?php endif; ?>
            <?php $this->comments()->to($comments); ?>
            <?php if ($comments->have()): ?>
            <?php $comments->timeComments(); ?>
            <?php $comments->pageNav('&laquo; 前一页', '后一页 &raquo;'); ?>
            <?php endif; ?>
       
    </div>

</div>
</article>

<?php $this->need('footer.php');?>