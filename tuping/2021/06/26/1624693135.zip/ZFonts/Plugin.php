<?php
/**
 * <strong style="color:red;">Typecho字体美化插件 更新时间: </strong><code style="padding: 2px 4px; font-size: 90%; color: #c7254e; background-color: #f9f2f4; border-radius: 4px;">2021-5-25</code>
 *
 * @package ZFonts
 * @author ZhongZN
 * @version 3.5.2
 * @link https://zn.ax/
 */
require_once("Action.php");
require_once("libs/options/FormElements.php");
require_once('libs/options/Checkbox.php');
require_once('libs/options/Text.php');
require_once('libs/options/Radio.php');
require_once('libs/options/Select.php');
require_once('libs/options/Textarea.php');
class ZFonts_Plugin implements Typecho_Plugin_Interface
{
    private static $handle=[];
    private static $instance=null;
    public static function activate()
    {
        ZFonts_Action::start();
    }
    public static function deactivate(){}
    public static function config(Typecho_Widget_Helper_Form $form)
    {
        $db=Typecho_Db::get();
        $znow=$db->fetchRow($db->select()->from('table.options')->where('name = ?','plugin:ZFonts'));
        $zdata=$znow['value'];
        if($_POST['backup']=='rec') 
        {
            if($db->fetchRow($db->select()->from('table.options')->where('name = ?','ZFonts-Backup')))
            {
                $kz=$db->fetchRow($db->select()->from('table.options')->where('name = ?', 'ZFonts-Backup'));
                $kx=$kz['value'];
                $update=$db->update('table.options')->rows(array('value'=>$kx))->where('name = ?', 'plugin:ZFonts');
                $updateRows=$db->query($update);
            }
        }
        if($_POST['backup']=='new') 
        {
            if($db->fetchRow($db->select()->from ('table.options')->where('name = ?','ZFonts-Backup')))
            {
                $update=$db->update('table.options')->rows(array('value'=>$zdata))->where('name = ?','ZFonts-Backup');
                $updateRows=$db->query($update);
            }
            else
            {
                if($zdata)
                {
                    $insert=$db->insert('table.options')
                    ->rows(array('name' => 'ZFonts-Backup','user' => '0','value' => $zdata));
                    $insertId=$db->query($insert);
                }
            }
        }
        if($_POST['backup']=='del') 
        {
            if($db->fetchRow($db->select()->from ('table.options')->where('name = ?','ZFonts-Backup')))
            {
                $delete=$db->delete('table.options')->where('name = ?','ZFonts-Backup');
                $deletedRows=$db->query($delete);
            }
        }
        $StyleUrl=Helper::options()->pluginUrl.'/ZFonts/libs/mdui/mdui.min.css';
        $MduiUrl=Helper::options()->pluginUrl.'/ZFonts/libs/mdui/mdui.min.js';
        $BackUp=Helper::options()->pluginUrl.'/ZFonts/libs/javascript/backup.js';
        echo '<style type="text/css">.typecho-option span{margin-right:100%;}</style><link rel="stylesheet" href="'.$StyleUrl.'"/><script src="'.$MduiUrl.'"></script><script src="'.$BackUp.'"></script><style>@font-face{font-family:pr1;src:url("https://cdn.jsdelivr.net/gh/ZhongZN/Fonts-Preview/s1.ttf");format("truetype");font-display:swap;}@font-face{font-family:pr2;src:url("https://cdn.jsdelivr.net/gh/ZhongZN/Fonts-Preview/s2.ttf");format("truetype");font-display:swap;}@font-face{font-family:pr3;src:url("https://cdn.jsdelivr.net/gh/ZhongZN/Fonts-Preview/s3.ttf");format("truetype");font-display:swap;}@font-face{font-family:pr4;src:url("https://cdn.jsdelivr.net/gh/ZhongZN/Fonts-Preview/s4.ttf");format("truetype");font-display:swap;}@font-face{font-family:pr5;src:url("https://cdn.jsdelivr.net/gh/ZhongZN/Fonts-Preview/s5.ttf");format("truetype");font-display:swap;}@font-face{font-family:pr6;src:url("https://cdn.jsdelivr.net/gh/ZhongZN/Fonts-Preview/s6.ttf");format("truetype");font-display:swap;}@font-face{font-family:pr7;src:url("https://cdn.jsdelivr.net/gh/ZhongZN/Fonts-Preview/s7.ttf");format("truetype");font-display:swap;}@font-face{font-family:pr8;src:url("https://cdn.jsdelivr.net/gh/ZhongZN/Fonts-Preview/s8.ttf");format("truetype");font-display:swap;}@font-face{font-family:pr9;src:url("https://cdn.jsdelivr.net/gh/ZhongZN/Fonts-Preview/s9.ttf");format("truetype");font-display:swap;}@font-face{font-family:pr10;src:url("https://cdn.jsdelivr.net/gh/ZhongZN/Fonts-Preview/s10.ttf");format("truetype");font-display:swap;}@font-face{font-family:pr11;src:url("https://cdn.jsdelivr.net/gh/ZhongZN/Fonts-Preview/s11.ttf");format("truetype");font-display:swap;}@font-face{font-family:pr12;src:url("https://cdn.jsdelivr.net/gh/ZhongZN/Fonts-Preview/s12.ttf");format("truetype");font-display:swap;}@font-face{font-family:pr13;src:url("https://cdn.jsdelivr.net/gh/ZhongZN/Fonts-Preview/s13.ttf");format("truetype");font-display:swap;}@font-face{font-family:pr14;src:url("https://cdn.jsdelivr.net/gh/ZhongZN/Fonts-Preview/s14.ttf");format("truetype");font-display:swap;}@font-face{font-family:pr15;src:url("https://cdn.jsdelivr.net/gh/ZhongZN/Fonts-Preview/s15.ttf");format("truetype");font-display:swap;}@font-face{font-family:pr16;src:url("https://cdn.jsdelivr.net/gh/ZhongZN/Fonts-Preview/s16.ttf");format("truetype");font-display:swap;}@font-face{font-family:pr17;src:url("https://cdn.jsdelivr.net/gh/ZhongZN/Fonts-Preview/s17.ttf");format("truetype");font-display:swap;}@font-face{font-family:pr18;src:url("https://cdn.jsdelivr.net/gh/ZhongZN/Fonts-Preview/s18.ttf");format("truetype");font-display:swap;}@font-face{font-family:pr19;src:url("https://cdn.jsdelivr.net/gh/ZhongZN/Fonts-Preview/s19.ttf");format("truetype");font-display:swap;}@font-face{font-family:pr20;src:url("https://cdn.jsdelivr.net/gh/ZhongZN/Fonts-Preview/s20.ttf");format("truetype");font-display:swap;}</style><p><strong><font color="#FF4000" style="font-size:30px;font-size:30px;">Z</font></strong><strong><font color="#F0310F" style="font-size:30px;">F</font></strong><strong><font color="#E1221E" style="font-size:30px;">o</font></strong><strong><font color="#D2132D" style="font-size:30px;">n</font></strong><strong><font color="#C3043C" style="font-size:30px;">t</font></strong><strong><font color="#B4004B" style="font-size:30px;">s</font></strong><strong><font color="#A5005A"> </font></strong><strong><font color="#960069" style="font-size:30px;">3</font></strong><strong><font color="#870078" style="font-size:30px;">.</font></strong><strong><font color="#780087" style="font-size:30px;">5</font></strong><strong><font color="#690096" style="font-size:30px;">.</font></strong><strong><font color="#5A00A5" style="font-size:30px;">2</font></strong><strong><font color="#4B00B4"> </font></strong><strong><font color="#3C00C3" style="font-size:30px;">设</font></strong><strong><font color="#2D00D2" style="font-size:30px;">置</font></strong><strong><font color="#1E00E1" style="font-size:30px;">面</font></strong><strong><font color="#0F00F0" style="font-size:30px;">板</font></strong></p><a style="background-position: right center;flex:1 1 auto;text-transform:uppercase;transition:0.5s;background-size: 200% auto;border-radius:10px;text-align:center;background-image:linear-gradient(to right, #f6d365 0%, #fda085 51%, #f6d365 100%);text-decoration:none;" class="mdui-btn mdui-ripple" onclick="recqd()">从插件备份恢复数据</a>&nbsp;&nbsp;<a style="background-position: right center;flex:1 1 auto;text-transform:uppercase;transition:0.5s;background-size: 200% auto;border-radius:10px;text-align:center;background-image: linear-gradient(to right, #84fab0 0%, #8fd3f4 51%, #84fab0 100%);text-decoration:none;" class="mdui-btn mdui-ripple" onclick="newqd()">备份插件数据</a>&nbsp;&nbsp;<a style="background-position: right center;flex:1 1 auto;text-transform:uppercase;transition:0.5s;background-size: 200% auto;border-radius:10px;text-align:center;background-image: linear-gradient(to right, #a1c4fd 0%, #c2e9fb 51%, #a1c4fd 100%);text-decoration:none;" class="mdui-btn mdui-ripple" onclick="delqd();">删除现有插件备份</a>';
        $ztitle=new Typecho_Widget_Helper_Layout();
        $ztitle->html(_t('<h4>基础配置</h4><hr>'));
        $form->addItem($ztitle);
        $form->addItem(new ZFonts('<div class="mdui-panel mdui-panel-popout" mdui-panel>'));
        $QTOpen = new Radio_ZFonts(
            'QT',
            array(
                '0' => _t('关闭'),
                '1' => _t('开启'),
            ),
            '1',
            _t('前台字体美化'),
            _t('配置前台字体美化方式，默认开启')
        );
        $form->addInput($QTOpen);
        $QTFS = new Radio_ZFonts(
            'QTFS',
            array(
                '0' => _t('ZFonts字体库'),
                '1' => _t('GoogleFonts'),
                '2' => _t('有字库 [不支持PJAX]'),
                '3' => _t('自定义字体'),
            ),
            '0',
            _t('前台字体解析方式'),
            _t('配置前台字体解析方式，默认为ZFonts字体库')
        );
        $form->addInput($QTFS);
        $HTOpen = new Radio_ZFonts(
            'HT',
            array(
                '0' => _t('关闭'),
                '1' => _t('开启'),
            ),
            '1',
            _t('后台字体美化'),
            _t('配置后台字体美化方式，默认开启')
        );
        $form->addInput($HTOpen);
        $HTFS = new Radio_ZFonts(
            'HTFS',
            array(
                '0' => _t('ZFonts字体库'),
                '1' => _t('GoogleFonts'),
                '2' => _t('有字库 [不支持PJAX]'),
                '3' => _t('自定义字体'),
            ),
            '0',
            _t('后台字体解析方式'),
            _t('配置后台字体解析方式，默认为ZFonts字体库')
        );
        $form->addInput($HTFS);
        $ztitle = new Typecho_Widget_Helper_Layout();
        $ztitle->html(_t('<h4>ZFonts字体库配置</h4><hr>'));
        $form->addItem($ztitle);
        $QTMarket = new Radio_ZFonts(
            'QTMarket',
            array(
                '0' => '随机字体',
                '1' => '<a style="text-decoration:none;color:black;font-family:pr1;">楷体</a>',
                '2' => '<a style="text-decoration:none;color:black;font-family:pr2;">玩艺记趣体</a>',
                '3' => '<a style="text-decoration:none;color:black;font-family:pr3;">字体传奇南安体</a>',
                '4' => '<a style="text-decoration:none;color:black;font-family:pr4;">摄图摩登小方体</a>',
                '5' => '<a style="text-decoration:none;color:black;font-family:pr5;">杨任东竹石体</a>',
                '6' => '<a style="text-decoration:none;color:black;font-family:pr6;">字制区喜脉体</a>',
                '7' => '<a style="text-decoration:none;color:black;font-family:pr7;">江西拙楷</a>',
                '8' => '<a style="text-decoration:none;color:black;font-family:pr8;">悠哉字体</a>',
                '9' => '<a style="text-decoration:none;color:black;font-family:pr9;">沐瑶软笔手写体</a>',
                '10' => '<a style="text-decoration:none;color:black;font-family:pr10;">字体视界法棍体</a>',
                '11' => '<a style="text-decoration:none;color:black;font-family:pr11;">Webmo</a>',
                '12' => '<a style="text-decoration:none;color:black;font-family:pr12;">本墨悦亦</a>',
                '13' => '<a style="text-decoration:none;color:black;font-family:pr13;">汉仪唐美人</a>',
                '14' => '<a style="text-decoration:none;color:black;font-family:pr14;">汉仪魁肃</a>',
                '15' => '<a style="text-decoration:none;color:black;font-family:pr15;">汉仪新蒂棉花糖体</a>',
                '16' => '<a style="text-decoration:none;color:black;font-family:pr16;">走路带风小可爱</a>',
                '17' => '<a style="text-decoration:none;color:black;font-family:pr17;">方正锐正圆</a>',
                '18' => '<a style="text-decoration:none;color:black;font-family:pr18;">站酷快乐体</a>',
                '19' => '<a style="text-decoration:none;color:black;font-family:pr19;">落日飞行体</a>',
                '20' => '<a style="text-decoration:none;color:black;font-family:pr20;">汉仪细中圆</a>',
            ),
            '13',
            _t('前台ZFonts字体库配置'),
            _t('<p style="font-size:14px;color:rgb(153,153,153)">选择喜爱的字体，应用在网站中</p>')
        );
        $form->addInput($QTMarket);
        $HTMarket = new Radio_ZFonts(
            'HTMarket',
            array(
                '0' => '随机字体',
                '1' => '<a style="text-decoration:none;color:black;font-family:pr1;">楷体</a>',
                '2' => '<a style="text-decoration:none;color:black;font-family:pr2;">玩艺记趣体</a>',
                '3' => '<a style="text-decoration:none;color:black;font-family:pr3;">字体传奇南安体</a>',
                '4' => '<a style="text-decoration:none;color:black;font-family:pr4;">摄图摩登小方体</a>',
                '5' => '<a style="text-decoration:none;color:black;font-family:pr5;">杨任东竹石体</a>',
                '6' => '<a style="text-decoration:none;color:black;font-family:pr6;">字制区喜脉体</a>',
                '7' => '<a style="text-decoration:none;color:black;font-family:pr7;">江西拙楷</a>',
                '8' => '<a style="text-decoration:none;color:black;font-family:pr8;">悠哉字体</a>',
                '9' => '<a style="text-decoration:none;color:black;font-family:pr9;">沐瑶软笔手写体</a>',
                '10' => '<a style="text-decoration:none;color:black;font-family:pr10;">字体视界法棍体</a>',
                '11' => '<a style="text-decoration:none;color:black;font-family:pr11;">Webmo</a>',
                '12' => '<a style="text-decoration:none;color:black;font-family:pr12;">本墨悦亦</a>',
                '13' => '<a style="text-decoration:none;color:black;font-family:pr13;">汉仪唐美人</a>',
                '14' => '<a style="text-decoration:none;color:black;font-family:pr14;">汉仪魁肃</a>',
                '15' => '<a style="text-decoration:none;color:black;font-family:pr15;">汉仪新蒂棉花糖体</a>',
                '16' => '<a style="text-decoration:none;color:black;font-family:pr16;">走路带风小可爱</a>',
                '17' => '<a style="text-decoration:none;color:black;font-family:pr17;">方正锐正圆</a>',
                '18' => '<a style="text-decoration:none;color:black;font-family:pr18;">站酷快乐体</a>',
                '19' => '<a style="text-decoration:none;color:black;font-family:pr19;">落日飞行体</a>',
                '20' => '<a style="text-decoration:none;color:black;font-family:pr20;">汉仪细中圆</a>',
            ),
            '13',
            _t('后台ZFonts字体库配置'),
            _t('<p style="font-size:14px;color:rgb(153,153,153)">选择喜爱的字体，应用在网站中</p>')
        );
        $form->addInput($HTMarket);
        $ztitle = new Typecho_Widget_Helper_Layout();
        $ztitle->html(_t('<h4>GoogleFonts配置</h4><hr>'));
        $form->addItem($ztitle);
        $QTGI = new Text_ZFonts(
            'QTGI',
            null, null,
            '前台"嵌入字体"代码',
            '<p style="font-size:14px;color:rgb(153,153,153)">将GoogleFonts中的"嵌入字体"代码粘贴于此&nbsp;<a href="https://docs.zfonts.cn/#/config?id=googlefonts%e9%85%8d%e7%bd%ae">配置文档</a></p>');
        $form->addInput($QTGI);
        $QTGC = new Text_ZFonts(
            'QTGC',
            null, null,
            '前台"在CSS中指定字体"代码',
            '<p style="font-size:14px;color:rgb(153,153,153)">将GoogleFonts中的"在CSS中指定字体"代码粘贴于此&nbsp;<a href="https://docs.zfonts.cn/#/config?id=googlefonts%e9%85%8d%e7%bd%ae">配置文档</a></p>');
        $form->addInput($QTGC);
        $HTGI = new Text_ZFonts(
            'HTGI',
            null, null,
            '后台"嵌入字体"代码',
            '<p style="font-size:14px;color:rgb(153,153,153)">将GoogleFonts中的"嵌入字体"代码粘贴于此&nbsp;<a href="https://docs.zfonts.cn/#/config?id=googlefonts%e9%85%8d%e7%bd%ae">配置文档</a></p>');
        $form->addInput($HTGI);
        $HTGC = new Text_ZFonts(
            'HTGC',
            null, null,
            '后台"在CSS中指定字体"代码',
            '<p style="font-size:14px;color:rgb(153,153,153)">将GoogleFonts中的"在CSS中指定字体"代码粘贴于此&nbsp;<a href="https://docs.zfonts.cn/#/config?id=googlefonts%e9%85%8d%e7%bd%ae">配置文档</a></p>');
        $form->addInput($HTGC);
        $ztitle = new Typecho_Widget_Helper_Layout();
        $ztitle->html(_t('<h4>有字库配置</h4><hr>'));
        $form->addItem($ztitle);
        $QTYZK = new Text_ZFonts(
            'QTYZK',
            null, null,
            '前台有字库AccessKey',
            '<p style="font-size:14px;color:rgb(153,153,153)">在此填写有字库AccessKey&nbsp;<a href="https://docs.zfonts.cn/#/config?id=%e6%9c%89%e5%ad%97%e5%ba%93%e9%85%8d%e7%bd%ae">配置文档</a></p>');
        $form->addInput($QTYZK);
        $HTYZK = new Text_ZFonts(
            'HTYZK',
            null, null,
            '后台有字库AccessKey',
            '<p style="font-size:14px;color:rgb(153,153,153)">在此填写有字库AccessKey&nbsp;<a href="https://docs.zfonts.cn/#/config?id=%e6%9c%89%e5%ad%97%e5%ba%93%e9%85%8d%e7%bd%ae">配置文档</a></p>');
        $form->addInput($HTYZK);
        $ztitle = new Typecho_Widget_Helper_Layout();
        $ztitle->html(_t('<h4>自定义配置</h4><hr>'));
        $form->addItem($ztitle);
        $QTFontStyle = new Text_ZFonts(
            'QTFontStyle',
            null, null,
            '前台自定义字体',
            '<p style="font-size:14px;color:rgb(153,153,153)">请将字体存在网站根目录，仅支持ttf,woff,woff2三种字体格式，其他格式均无效&nbsp;<a href="https://docs.zfonts.cn/#/config?id=%e8%87%aa%e5%ae%9a%e4%b9%89%e5%ad%97%e4%bd%93%e9%85%8d%e7%bd%ae">配置文档</a></p>');
        $form->addInput($QTFontStyle);
        $HTFontStyle = new Text_ZFonts(
            'HTFontStyle',
            null, null,
            '后台自定义字体',
            '<p style="font-size:14px;color:rgb(153,153,153)">请将字体存在网站根目录，仅支持ttf,woff,woff2三种字体格式，其他格式均无效&nbsp;<a href="https://docs.zfonts.cn/#/config?id=%e8%87%aa%e5%ae%9a%e4%b9%89%e5%ad%97%e4%bd%93%e9%85%8d%e7%bd%ae">配置文档</a></p>');
        $form->addInput($HTFontStyle);
    }
    public static function personalConfig(Typecho_Widget_Helper_Form $form){}
    public static function frontdesk()
    {
        $open=Typecho_Widget::widget('Widget_Options')->plugin('ZFonts')->QT;
        $fs=Typecho_Widget::widget('Widget_Options')->plugin('ZFonts')->QTFS;
        $yzkey=Typecho_Widget::widget('Widget_Options')->plugin('ZFonts')->QTYZK;
        $type=Typecho_Widget::widget('Widget_Options')->plugin('ZFonts')->QTFontStyle;
        $gooi=Typecho_Widget::widget('Widget_Options')->plugin('ZFonts')->QTGI;
        $goot=Typecho_Widget::widget('Widget_Options')->plugin('ZFonts')->QTGC;
        $pubf=Typecho_Widget::widget('Widget_Options')->plugin('ZFonts')->QTMarket;
        ZFonts_Action::fro($type,$fs,$pubf,$open,$yzkey,$gooi,$goot);
    }
    public static function backstage()
    {
        $fs=Typecho_Widget::widget('Widget_Options')->plugin('ZFonts')->HTFS;
        $yzkey=Typecho_Widget::widget('Widget_Options')->plugin('ZFonts')->HTYZK;
        $type=Typecho_Widget::widget('Widget_Options')->plugin('ZFonts')->HTFontStyle;
        $gooi=Typecho_Widget::widget('Widget_Options')->plugin('ZFonts')->HTGI;
        $goot=Typecho_Widget::widget('Widget_Options')->plugin('ZFonts')->HTGC;
        $pubf=Typecho_Widget::widget('Widget_Options')->plugin('ZFonts')->HTMarket;
        $open=Typecho_Widget::widget('Widget_Options')->plugin('ZFonts')->HT;
        ZFonts_Action::bac($type,$fs,$pubf,$open,$yzkey,$gooi,$goot);
    }
    public static function set($names,$callbacks,$overried=false)
    {
        if(!is_array($names)) $names=[$names];
        if(!is_array($callbacks)) $callbacks=[$callbacks];
        $i=count($callbacks)-1;
        foreach($names as $j=>$name)
        {
            $k=$j;
            if($i<$j)$k=$i;
            $callback=$callbacks[$k];
            if(!array_key_exists($name,self::$handle)||$overried)
            self::$handle[$name]=$callback;
        }
        return self::instance();
    }
    public static function handle($content,$obj=null)
    {
        $pattern=[];
        $RegExp='((?:"[^"]*"|'."'[^']*'|[^'".'"\]])*)';
        foreach(array_keys(self::$handle) as $name)
            array_push($pattern,
                "#\\\\\[|\[($name)$RegExp\]([\s\S]*?)\[/$name\]#i",
                "#\\\\\[|\[($name)$RegExp\]()#i"
            );
        return preg_replace_callback($pattern,function($a) use ($obj)
        {
            if(count($a)==1)return $a[0];
            $name=strtolower($a[1]);
            $handle=self::$handle;
            $callback=$handle[$name];
            if(array_key_exists($name,$handle)&&is_callable($callback))
            {
                $attrs_arr=array();
                foreach(explode(' ',trim($a[2])) as $data)
                {
                    $arr=explode('=',$data);
                    $attrs_arr[$arr[0]]=trim($arr[1],'"');
                }
                if($obj->isMarkdown)
                return '!!!
                    '.call_user_func($callback, $name, $attrs_arr, $a[3], $a[0], $obj).'
                    !!!';
                else return call_user_func($callback, $name, $attrs_arr, $a[3], $a[0], $obj);
            }
            else return $a[0];
        },$content);
    }
    private static function instance()
    {
        return self::$instance?self::$instance:new ZFonts_Plugin();
    }
    public static function handleInit($obj, $select)
    {
        ZFonts_Action::CodesInit(self::instance());
    }
    public static function content($content,$archive,$last)
    {
        global $typecho_archive;
        $typecho_archive=$archive;
        if($last) $content=$last;
        $content=self::handle($content, $archive);
        if(Typecho_Plugin::export()['handles']['Widget_Abstract_Contents:content'] === [[__Class__,__Function__]])
        return $archive->isMarkdown?$archive->markdown($content):$archive->autoP($content);
        return $content;
    }
    public static function button()
    {?>
        <script src="<?php Helper::options()->pluginUrl() ?>/ZFonts/libs/javascript/sc.min.js"></script>
        <style>
    	.wmd-button-row {height: auto;} .wmdp-span{background-image:none !important;background:
    	none;font-size: large;text-align: center;color: #999999;font-family: serif;width:
    	auto !important;}
        </style>
        <script>
        var _0xodh='jsjiami.com.v6',_0x3cbc=[_0xodh,'wrTCuMKibcKv','w5Q5OsO5BQ==','R8OXbCMR','wrnDnSZZw4Fow5nDkWzDqsKAw5PDgcKyw6U=','MAvDk8KZOA==','w7E+w5jDncKEwq0NScOWT11vYsOH','TcKOw4wlw6nClsK+woHCt8KKC8OfD1w=','I0scwpFoHsKSw77CscKuL8K0','w59hwqBZIHs=','w5JmEgLChA==','woPChcKoScKM','w7wKEsOIDQ==','wpzDrsODVXM=','wqp9wrVdYcO9wpwZQg==','HMKlH8Ocwow=','wqRgfQzDqsK3w4bCmMO6','NRrDk8KFKQ==','BsKhHcOOwp1u','wotSw4dGwrHCoHDDox0BwqMLw4TCmg==','KsOIFhV4','wro1OMKGw44=','EMOUFzc=','wppdfsOxwofCu8OTEA==','woQaPMKmw4XCrcKJw6bDrFPCjEAtRQ==','wpfCmyt0wqQ=','ZMKvAMO8wo0=','w4nClVQywqM=','VMOOwrTDisK4','SsOEGsOITQ==','wqBVd1HClw==','wrMtw643Pw==','wqjDp31LwoU=','QcOOwq4=','IDkLwpTDnw==','w5sRw4TDncKA','w70fw4vDqsOJ','w6fDtmNOwrM=','NmttXsKB','HMOeEDZ9','bMKZIMObwpo=','SUXCoMOSRg==','wrp6wrJPYcOqwqcWS8Omag==','wphSw4t3','wozDoMOMVWU=','wonDvcOKQWI7w696HMKCw7s=','wobCmcKIaQ==','wrVKeE3CkA==','wr3CtDd0wqDDqSRXVcKnTU9aKw==','w7MewoTDkng=','wqRwcxrDvcKxw4bCmcOzKsONw6fDr8Oo','V8Kjw4wMw7s=','w7ULwp7Do2c=','wqBAd13CgGtdwo46w7ZDwrHClFg=','E17Ch0rDlsOUw44kw5DDmDDCpw==','FMO/PcOzXVfCl8K7w65Sby7Cl8Kn','wqF0cwrDuw==','w6EIw5LDjsKq','YcKHSsOAw5Q=','RMOawqDDksK2wpBzZcOn','NHt4ecK1','w7pCBA0EJQ==','J2sCw6vCuA==','Z8KaO8OWwqE=','TcKOw4wlw6nClsK+woHCt8KcEcOa','wrrDkcK3Whk=','LBbDhsKpHw==','w5Efw5/DkMKD','M3/CgEfDkQ==','wpIpVFnDnw==','w6vCl0YRwpPDj8KNw4hE','CMOICTVGw5o=','wrdfwptCQQ==','FickwonDnA==','e8KDSMOSw4VA','WUvCr8OSUA==','SVlXwpgpTMKmwqNjwqlHUAnCkw==','ccKJRcOAw4I=','wpjDv8O4Z0Y=','w4JoHQLCkg==','Z8O9f8Obw70=','AsOZw7HCvsKj','w7/CgVUawog=','w5HCi8KdecOOZUfDgS3DnMK1DcKAaMKe','w7TCh0oFwpPDlQ==','wrpkwr5Nfg==','YsOjM8OHTg==','O3s+w63ChQ==','TXfDocO/w7rDrw==','wo99b8OWwp4=','L8KoIMO4wpk=','wofCmAvDo8OZ','LcOZJsOmaw==','wp1WaA/Diw==','IsOgwqPCt2Y=','PnYJw7fCsg==','wrtSw4RNwpk=','w4LCmcKJw6Z0','w5vCvcO+wrtg','wqTChk0Uw4fDlMKAwpsBAcOLwqTClmfCoMK9wrck','w67DuGJswoY=','FiQewp3DmQ==','wrQKCcKiw60=','UMKcTcOgw4Y=','QMOAWRcP','XEvDlRPDhsOFw4suw53DqX7CqsOyCsOow5PCrw0FwrBjLhzDvnjDoSHDmGIvw7vCpRZPFhvDn0DCkOanpuS8uMKnADd+PMOOEy3CnMO1wptdw5ZFw5jDmCrDqWptwpnCkcKawpfDtMO3w4rnjZfoiKToroTotY7kvKJ1WMOgwrF+wrFvDGEmTCd0LDfCh8K9w6vDncO9w4XChX9Pw79VMeWsl+S/meS+l+WlgeWNmeWsk+S8jXoJGcKjRQLDizILCAY3w6TCjS8yVBMCw4xhwplqwpljDMO55pOG5Zqz5pKU55iP5bOf5per5L2awqtLw58Bw7/DsXrDm8KywoDCoiDDssOBwonDuyjDpD9Gw4fDo8OuAyzDuMKD5p+95Lu25LmH56qX55y15L+xQiXDqMOqL0N6EMKFTsOHwqvCgTLCvHHCgMKKwqnCt8KSw5nDk8OkwqPDkBzlra3lir/ljq3ll63ohYrkv6DCoU0vSsKnw5JLK8Obw7TCvMOlZnAZwrXCkgxawoRpESIpwqUsduaxouins+aLnOani8OEQcOewqoRwo/CgEdRf8KoYRzDr8OvwpUGw4TDj8KZw7HCpRrDngRpwqTmg6Plk5vlrITkvofCj8OVwowuw6vCoRobw6HCicKfIcK4wowOw4vCiQjDqUvCtsKCHcO/aicM5rC255Ki6L+v566S5ouW5Yew5Lysw7Mkw5/CmQjDqTLCisKrfsOWw5g+w5Ydw5bCusKoMcOLZMOlQClbw4EkwqTlr7/kv5vopb/nlpnmsofmo4bkvLR4w7jClFMia8K3K0zDhMKLFy7DiD1ZLsKccMOJw6wTwp99CizCksOMw4Alw7rCg8KlJzooAsOfL8KXS8OpHmbCk8Kaw6RJXcOXXcKnwoFUTMKKaVoALgbmnJ3loJHmgp7kuLjCk2DCuz3CnsKdHG0Ow40cw7rDphZhK8OtBsOtwosIGBROwqnDs8K3w6/mspjkuqvllr7nvanku7rCosKGwprCqsO2w6p4EcKcI3LDtn0VwovCiibDlj51YAjCnsOFTw3DocKd5rCI5Lq66a2P6IK9cxo2SsOCw6t1TcOwGSDCkcKGJ8KZeWrCuhIOwpbCosKFwqLDh8O+wrBz5rK95Lug5ped6JGd5qCv6ImK57OK5L28Ay0CwoHClAXCs2gvWQtKccO1wrDCowQnwrQDNRLCsD9XwrRZwovotaXotbrlu4jpopzls5Hlj5fniIIiTsKbM8ORwqLCozFGGMOkwqsDw6JSHDTDiWfCv8KUNQ1Mw5/CsMK7X+aWpOautumWluavvOWfqkh6w50bBzMrPjXDrDFYwr5/w6ROeTLCoyzDvh1TVhsBw59a56qt6YaY5b+b5LuP5L+Tw4PCpcKcw7BEw5DClzcmfMK/wrXCvWjDrHvCsgnDsCEQw4LCqMOCwr9uw4zCpuiToOaWvumjj+ihteS9hMO+YD3Cn8KXwqXChzbCusKhVsOBw6LCsA3CrsKYwoHCskrDh8KWw7s3bT84Zuaxj+S7l+e4geS4t+WckMK0NjbCicOkVSMgfGPCp8KlMMO4woB/IHc=','wqTDjUALwpHCgw==','wpHDpMKzeQM=','w4I0O8OvEA==','WcOIRcOiw68=','w44ewpnDsFHClQ==','w71vwqhcNQ==','QsKBYsOsw50=','c0gfwpp/NcKYw7DCscKIJMK8','RsKzw7I2w5I=','TMO3w5vDq8K8','WcO7wrTDmcKT','PcKxMsOowq0=','w4oJIcOJFQ==','w6tlIei/rOWHu+aVguWvuOWFs+WspEXClsO2wqM=','fmoqMMKkw5/DjMKZMltAIV7CoGvCulZBwrzCj3rDh8KBTkglwrvCjg4OGQbDvBHCrTbCp8OWe8Oxw67CrsO6ZMKHckIKwpbCjz0rPsKiNMO2wonCozlGwoXDpMKMwr7DomHDk8Otw6LCilZVJ8OZQRg=','w55zEh8h','w70sw4jDpMOu','QMOQeCAd','w6knw4TDncOV','AlTCj1Y=','XMO9w7PDnMK7cA==','wokOXGPDlg==','w79wwqhXGw==','NAQOwozDhw==','NBfDpsKYHQ==','V8OCIMKXYg==','wqB5RhfDjw==','w7NCAsOoIg==','wotVw5Rhwp8=','YWUkw4vDi2vCisKoPBfCt1UGw5fChm9Zw5I=','wpVNw5FNwq8=','wohww6Bmwqw=','YXFzwoHCmGfCgsOwfSXDuGwDwoTDgUUUwoJuw7XDncK+XsKsR8OIwq4EaUBPwr7DscK0XcOIw50Nwqbmp4vkvK07XV/CvcOPDcOBZsOqNRI9MsOsJApGHMKBbld5bnt4NETnjYPoiazorKPotYzkvYpFScKTwo9pNMOvN8KbWsOswp09woLCrCI0KA3Dm8OSw4U7LsKHw7TCl+WvrOS8huS/m+Wli+WOk+WshuS9v8KbwoZxTcOReQUMMsOCC8Onw6VSRR4GIcO9w4wyNDgHwpZkw6HmkbPlmovmkK/nmLXlsqDml4jkv5YlwpvDo8ODw7wHMsOmw6tww6t8w7wxwqfCinMUw5XCicKFE14mbyrDqeaftuS7v+S7v+erkOefhOS+q1Njw73DsMO/w605wq7CnyNqHjDCsMKXw6/Dl8ORw7nDpcOPVE0ewqPDhnnlrIzlirjljqfllJLohKfkvpfChjzDssK3b8KveAALwq4ZPlDCt8KTYjNVZlzDrTPDsQDDusOVTOayguilh+aJt+amnsKFw6PDtMKQwpvCoBB/wrLCj8O0w4zDpcKCViNVQ1XCrVzDvnXCulvDhhfmgIHlkJflrb3kvq3DsC7CnTHClgzDuETDocKOSsO+bsOrw7pCOcKWdE1Vw5wAfMOhFCXmsYDnkInovLPnr6vmiZHlhYXkvrZOfsKoYBw1UxZ9ScK5wpZGw4ggw6EDw5F7w7/DmcOTU8K3B8OuwqLDtuWssuS8meilgOeVtOawt+ajkuS+q0bChFY0wobCuTsFw6zDt8KxQsOAacKHwojDjkwEX8OAwqrClnovUsOXw7XCuGnDhizDisK5FV7Dhxgqw4VZw4HDtHXDrXxOwoDDn8O2wovDqMKowrxzOyTDs8K+WiXmnqrlopPmgrzkuqTDhsKTJsOGw6tSM8KMZCZ3SsOmaU/Ds8OWKMOIwrvCiBPCiEXDgGkDw4LmsKzkuY3llqXnvobkuprCoMOaw4nCnsOhwosKw5Qjw50Tw4VQKg/Cq3LDgMOARMOVasOzAVYoVnLmsa3kupLpr7HogqM2wrpbXMKtwq0ow7s+dAcdw4DClsOcw4DClcOhw4YFw6DDgMK3wqFbMwJi5rCU5LuI5pSb6JOQ5qKE6Iur57GQ5L+qw4LCrn3CvcKKBsOKwrkgw7HCksOLw7EmwpHDlsKyw7MywqjCrsKIw7PCvcKkwp55dOi1rei3tuW4m+mjtOWwkeWPuOeLhMO1w7XCoRTDkjzCvcKcw7xvw7szaMOLfFhFOMOaw6zDi8KgZ8KNw4Nzw6PCguaXtOauhumXueaut+Wem3jCgQTCj1bCsn0lIwwxd8Kbw6g9woXCkFEMRyMeRsKpw5zDlsO7w5Lnqp3phZzlvZLkubTkvLFIwoc5TwPCk8KAwoR2w7DDhsOXwprClw9sK1F+AcKqaMKtw73DtsK1wpI66JC15pWX6aOf6KKt5L23wpkYwqPChsKUc8Obwo0OwptxN3zCjwJ6wpbCuQNUw6/DrkvCu8KSwrFIceawoOS4q+e5s+S7p+WescKSDMKxBMKFw6hqwoIewrFuw6drCgHDu8KWwr8=','KsOIJRZ9','w5Jac8OxwpLCpsOYUX/DucKKw6DDpcKFw6kzw5nCoMKwQ1gCwonDtsOxwphUdcOkw44+wpjCvcOZOwbCjQHCnsOtMcKqwqjDqHLDojEBw7fCvFnCqMKrw5Vrw4vCpcKJw5Quw7Tno73lrJDDuMKvEcOCwqplNWxL','w4jCk10Jwqo=','w6sDw5LDgMKG','w5vCmcK8w6x/','w5AYw5dqwqvDuw==','w4PCrcKbw6Z2','w6nDpXtxwpA=','CxUEwoDDq0Q=','ACg6wpPDkA==','woEKLcKkw48=','FcO/PMO5SEY=','W8Oiw6DDjMKm','F31QVcK8','Umh+wpUN','I14cwp1/','NEMqwqdo','wrdNw5VswrPCsW7CphUawo8GwrDDnA==','eHHDtcOrw7M=','c8K+w4w0w40=','SMO6w67Cr8OPGRcaP2TCrgsmwpTCvh9SwqTDpzrDhMKMNcKEFF7CmcO9McKhPcKow6HCq8K9w7vDqMK9bQ==','WUvCrw==','woXCvDFewq0=','PcOHwpHCqE8=','wqbDgsKsVRw=','WElewros','MH91aMKp','DUAOwoFyRMO/wrA8w4pPAgfDlcOwwq91woLDlDsaPQ==','ScOow7vDjQ==','w799GBjCj2HCtnxDbyzCqXtL','w5DCjmhDwp56wprDngc=','RMOcPsOGX03Cm8K4','wqXDln9Bw5xkwpzDgjfDpsOFwoLClsKnwrHDnMOfwrjDrcKXbiDCkcOucsOSwobCsMO8JH7DsMOAFsO+wr/DiWcV','YlJIwog6FsOMw63DpsKXcsKsTkXCuivDgMO8w7FSA3A=','BMO5KcOcUQ==','BsOiwoXCtA==','w7keU3zCpw==','wr4rworovKvlhoLmlZ7lrLPlhqPlrIEgBn4u','w5bDv8KRHGI7w4VvE8KXw7vCg28eLsOUwoxWCxt1DAoQw7zCv8KoB8KBP0cTwpZ6wrvDtCAkwqBbecKvwpMBa0ojw7rDlXI1w6Irw6Rkw4p1M8OMwoF6D8O5V8OAw5LChANRw4pLwrcwwrzCpiY=','woELw4vCqV7CgMObQ8OQ6YG05om05ayI5L+Yw7g/wqguZMKsE8OwKwgo','w6jDqcKDah5KwqQ0woHDj2rCsMOew43DilQKAAXChcO3dg5CWjtfCmXCnsKLwq0cwr0wAcOSwptnw6HDqAcfwrPCicOfwonDhcKSw5rCnWHDrgBHw6/Cl8ONe8ObIOegu+WthcKyBMKaw7URAhgdRw==','wrDDt8OvwppWM8Ow','w7lVXmPDr8Oi','w6sNV27CtMKswoAcwo9Nblg9w6Ezwp/CmkHCsAl4wqBpwqs=','w7BSdlzDjnpQwoggw4RFwrXChwwyw5vDpMOMwr5JwqPCtg==','VcORVS4Cw47DmQ57','wrVhBQQE','PcO/NMKDQFIMw6TCq8KLcsK2FMOwwp4RNMOowqp9woBSJnZEwqLCh8KbUcOLw61tw5Vvw7VgbUgEwq3CrFrDq8O2w7YIwrbDi2w6b8OiGeaWl+WsuOWtoeS9isO9w4/CkTt8w6YKwoNXUMOECD8CLMOuw77DnHPCuFQ+wqsjM1RnwpNAwqN+w4VhYMKgI2N+wrbDr8KLcMOXw583ISQQw5JNQBfCucKYTVzCtg/Du8O9b2TCqwctw7Zqwp7Dt8O1wphFEcKyw7tkw6Y7Bg9ww7JKScO5GcO9PcONw7xNaMKuw5LCncKVwpfDhMOheMKaw6fDncKLwrTDgDIvw6kLw7pkwpzDvwI5w5Y/acK8wqpewqfDuljCmhXDtsKFwplQbCUGAMK5w61uw7HDrDTDnMKmwrkaw6sjwoEXWD3DlWzCqVZdwp0+w4rDoiPDuMOOwroVNcO+w7TDnsOhQwPDg17CtEgbw6vDux51NDFMw6kbGMOGYFcGwoLChxY+A0wvaMOrQ8KIIhTDlQrDrDVRw75pWsKxbsKXDsKYw6owfFNZM2LCucKcBWUNRjQLDCM6wqU4wr/Du8Kxw4nCiMO6wpbCiwjDtcKWw7vChsKtTljCisKGfiB+wq3DvMOheyMOwqvCgnnDgQ8awqvDtMK4w6vDhcKWHRXDmcO8w65GwrLDuMKvw6daC8OLE8O1TcKYAXDDtcOLw6UBLsKyEsK8wp3DpcKkbcO1w6lYDHXCu8K7woLCvsOQw48ow4LCokLCsDxnw63Dj8Kdb3hbw4Yrw6N9w4nCjMOiw7gZdcO/UXBjHMKRwp3DkcOZw6UHwo3Cs8KIAGArw7B+w7DDoD/Dg8OiwpzDpknCg0IaccKww5LDtQplw68YWsKyf8KgwqHCq1FpBjRjwrLClhrDjAA4Azwkw6MSKng0asKMUEFUZcKaGcKrw6LDpXHCgsOxUsK1UAzDpiXDtmbCqcOvVW0AME3CjsKQw60kGcO3NcKdZiAOw4HCrcK/KxfDgz09w4xAbTNYw6ZkwqpRY2fDnsOEw6Bpw5TCl8KoM8ORwq3CncKtC15zbDB3H8KEw7YIw4VdATzCl3nDlsO2SFA/w4UVwpXCmsKxwqXDu8KpwplAw4vCiFTDmg5Ww5rDtsOiw5bDt1tuw7XDg3PCggLCosK0wrkfPRrDshZZwqTDgRd9wqPDosKvwrpawo7CnE/Cm2ENYcOuUXBeHMKTwq50RcKYTDXDgQDCuMO2IB3Ck0fCosKFesKOw6fCmS9xAcKlw5oew456wrxQcTFPcBAjwozCtcKTNMKUawfCh2xJw45+w7JTw4YNbB9WwrDDmyUew5wwRcOnwpRAwoXCj8K/woENa3vCjifDk2kcw65rO8KWw7UrYRjDjwfDtcKQEMOLw6HDsi3CvcONwpdMIVpxwpfDlF7CpyRQwpHCh2EcdGjCtcOFPsOEw5zCh3sJw5TCn2NTc3Eiw4YwGWbCjFTCgsKOw68Kw7TCucOwIGwIwrovbMKCwrPCqMOxOsOSw6DDlC1gdMOJw49mwpPCujBiw57CiyzDg3dxNsKPQcKWHhXDkcO9w4Mtw4cCw5oBwrDDnELCl8KfdFfDslbCvcOuQsO7RWt0woRtScKSwoNRwoXDgcKRaWhOwocBIRFPBgMrw51YWcKZdMOWwpfCmzrCmxLCjcKEPSRfw6rCtMKUwrPCqTXCgMKMw6Qvw6xJb2NpDQdSPk3Dq8KQwoPDp8OqLFXCoMO3MQ7DuDAHw5t4csOBw5Yrw7/CksOlw7wYwoPCqBjDrcKVwoQlO2paw4rDl8Otwrd2eT7CiCMswqTDscO7w68Qw49ZegEeJMKbLmLCmsK4w6LDujUUIMOldzEBw4jDin3DkcOtwqlEBnh0','w54XwpzDtlk=','YB3DkMKeOMKBw77Cow==','RMOmwpDDucKj','wp4MwpjDsR/CksOJR8KNGMOvaw==','B8Orw7fCrsKQ','w6dQCcOjFA==','wrjCsDdkwqY=','woAIw4gHCQ==','wpPCqMKJXMKF','BFcbwqBs','V8Kfw5MVw4k=','CU/CmHrDtg==','wp9Cw5FwwqnCt3TDqBQ=','wphfaMO+AsOf','ZsKuA8O4wo8=','w7QRw5bDjsKf','w6fDhHxCwoV8','WcKOw5QFw6bCh8K6wovCt8KtPcOHNEw=','wo8aJsKEw53CoA==','csOmP8OQV0wEw7nCvw==','wr1/WFDCoA==','jZBhsZjiQuugKZIMaQmti.HcTom.v6=='];(function(_0x45658b,_0xa6ed42,_0x51c273){var _0x5a2c04=function(_0x12512e,_0x2e9f6a,_0x369b63,_0x3f254c,_0x54c60e){_0x2e9f6a=_0x2e9f6a>>0x8,_0x54c60e='po';var _0x4339f9='shift',_0x17dab4='push';if(_0x2e9f6a<_0x12512e){while(--_0x12512e){_0x3f254c=_0x45658b[_0x4339f9]();if(_0x2e9f6a===_0x12512e){_0x2e9f6a=_0x3f254c;_0x369b63=_0x45658b[_0x54c60e+'p']();}else if(_0x2e9f6a&&_0x369b63['replace'](/[ZBhZQuugKZIMQtHT=]/g,'')===_0x2e9f6a){_0x45658b[_0x17dab4](_0x3f254c);}}_0x45658b[_0x17dab4](_0x45658b[_0x4339f9]());}return 0x8cff6;};return _0x5a2c04(++_0xa6ed42,_0x51c273)>>_0xa6ed42^_0x51c273;}(_0x3cbc,0x173,0x17300));var _0x5d16=function(_0x444588,_0x4dcb4f){_0x444588=~~'0x'['concat'](_0x444588);var _0x23d512=_0x3cbc[_0x444588];if(_0x5d16['eQPxfx']===undefined){(function(){var _0x2f2307=typeof window!=='undefined'?window:typeof process==='object'&&typeof require==='function'&&typeof global==='object'?global:this;var _0x1fd019='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=';_0x2f2307['atob']||(_0x2f2307['atob']=function(_0x33fd03){var _0x2ec4e5=String(_0x33fd03)['replace'](/=+$/,'');for(var _0x17691a=0x0,_0x1a9300,_0x350319,_0x16c76e=0x0,_0x28aec6='';_0x350319=_0x2ec4e5['charAt'](_0x16c76e++);~_0x350319&&(_0x1a9300=_0x17691a%0x4?_0x1a9300*0x40+_0x350319:_0x350319,_0x17691a++%0x4)?_0x28aec6+=String['fromCharCode'](0xff&_0x1a9300>>(-0x2*_0x17691a&0x6)):0x0){_0x350319=_0x1fd019['indexOf'](_0x350319);}return _0x28aec6;});}());var _0xc5d90c=function(_0x396feb,_0x4dcb4f){var _0x4f08bf=[],_0x1b5876=0x0,_0xe318a5,_0xbffb6b='',_0xa05c26='';_0x396feb=atob(_0x396feb);for(var _0x1aa352=0x0,_0x381ed9=_0x396feb['length'];_0x1aa352<_0x381ed9;_0x1aa352++){_0xa05c26+='%'+('00'+_0x396feb['charCodeAt'](_0x1aa352)['toString'](0x10))['slice'](-0x2);}_0x396feb=decodeURIComponent(_0xa05c26);for(var _0x5005d2=0x0;_0x5005d2<0x100;_0x5005d2++){_0x4f08bf[_0x5005d2]=_0x5005d2;}for(_0x5005d2=0x0;_0x5005d2<0x100;_0x5005d2++){_0x1b5876=(_0x1b5876+_0x4f08bf[_0x5005d2]+_0x4dcb4f['charCodeAt'](_0x5005d2%_0x4dcb4f['length']))%0x100;_0xe318a5=_0x4f08bf[_0x5005d2];_0x4f08bf[_0x5005d2]=_0x4f08bf[_0x1b5876];_0x4f08bf[_0x1b5876]=_0xe318a5;}_0x5005d2=0x0;_0x1b5876=0x0;for(var _0x4eedc1=0x0;_0x4eedc1<_0x396feb['length'];_0x4eedc1++){_0x5005d2=(_0x5005d2+0x1)%0x100;_0x1b5876=(_0x1b5876+_0x4f08bf[_0x5005d2])%0x100;_0xe318a5=_0x4f08bf[_0x5005d2];_0x4f08bf[_0x5005d2]=_0x4f08bf[_0x1b5876];_0x4f08bf[_0x1b5876]=_0xe318a5;_0xbffb6b+=String['fromCharCode'](_0x396feb['charCodeAt'](_0x4eedc1)^_0x4f08bf[(_0x4f08bf[_0x5005d2]+_0x4f08bf[_0x1b5876])%0x100]);}return _0xbffb6b;};_0x5d16['iXuyox']=_0xc5d90c;_0x5d16['aPjaxq']={};_0x5d16['eQPxfx']=!![];}var _0x4d2b39=_0x5d16['aPjaxq'][_0x444588];if(_0x4d2b39===undefined){if(_0x5d16['BPsnrY']===undefined){_0x5d16['BPsnrY']=!![];}_0x23d512=_0x5d16['iXuyox'](_0x23d512,_0x4dcb4f);_0x5d16['aPjaxq'][_0x444588]=_0x23d512;}else{_0x23d512=_0x4d2b39;}return _0x23d512;};$(document)[_0x5d16('0','rU%t')](function(){var _0x401a96={'RCLGY':_0x5d16('1','RsnH'),'aTyAf':function(_0x1acff8,_0x31dd43){return _0x1acff8+_0x31dd43;},'TykTg':function(_0x5d79ed,_0x3599d4){return _0x5d79ed+_0x3599d4;},'itsUC':function(_0x15f8bd,_0x2950f6){return _0x15f8bd+_0x2950f6;},'rDTGZ':function(_0x3a3e52,_0x63d70c){return _0x3a3e52+_0x63d70c;},'vJbvx':function(_0x455b7b,_0x56f808){return _0x455b7b+_0x56f808;},'YJpeg':_0x5d16('2',')3PI'),'qyXTo':function(_0x4d6609,_0x1c5c88){return _0x4d6609+_0x1c5c88;},'KWGkn':'4|0|1|2|3','EDJES':function(_0x25e14f,_0x38eca9){return _0x25e14f(_0x38eca9);},'XIcqW':function(_0x5d4fed,_0x4c89f3){return _0x5d4fed+_0x4c89f3;},'QAFSr':_0x5d16('3','X852'),'Tvdqg':_0x5d16('4','^1QG'),'bueGf':_0x5d16('5','2ild'),'lWqkB':_0x5d16('6','^1QG'),'nZChC':_0x5d16('7','*0e9'),'FDRpL':function(_0x4d3d1c,_0x18de5e){return _0x4d3d1c+_0x18de5e;},'cSfvM':function(_0x5053a7,_0x599baa){return _0x5053a7+_0x599baa;},'aLNiB':'NTSew','NeqGJ':function(_0x2579e9,_0x201559){return _0x2579e9==_0x201559;},'pEWCX':function(_0x831277,_0x13b7e1){return _0x831277!==_0x13b7e1;},'QwpPD':'rdvhb','cavkz':_0x5d16('8','2ild'),'tqyRQ':function(_0x5af7c2,_0x1bc11f){return _0x5af7c2===_0x1bc11f;},'xswdO':'JsjKk','EYbOH':'GXKet','iHlLq':'hcXcO','HpkvU':'0|2|6|7|5|1|4|3','aEiSx':function(_0x2c31a7,_0x2cf400){return _0x2c31a7+_0x2cf400;},'rpWGP':'hCOgB','XUoAV':function(_0x58dd6e,_0x3ac878){return _0x58dd6e(_0x3ac878);},'fzsPn':_0x5d16('9','#kwa'),'ElSQp':function(_0x533b00,_0x3ac241){return _0x533b00+_0x3ac241;},'JCwpU':function(_0x359d30,_0x132818){return _0x359d30+_0x132818;},'FmBzN':function(_0x23f0f7,_0x3850fa){return _0x23f0f7+_0x3850fa;},'cwDJY':function(_0x226064,_0x550d7c){return _0x226064+_0x550d7c;},'WewND':function(_0x2d14c0,_0xbc774b){return _0x2d14c0+_0xbc774b;},'eYpIw':'<div\x20class=\x22wmd-prompt-background\x22\x20style=\x22position:\x20fixed;\x20top:\x200px;\x20z-index:\x201000;\x20opacity:\x200.5;\x20height:\x20100%;\x20left:\x200px;\x20width:\x20100%;\x22></div>','nTvxQ':'<div\x20class=\x22wmd-prompt-dialog\x22>','WuAAD':_0x5d16('a','W^rb'),'GzkUw':'<p><b>插入指定字体文字</b></p>','LbzRv':_0x5d16('b','5l@d'),'dDSBS':_0x5d16('c','P(Ki'),'HTxuQ':_0x5d16('d','9u4g'),'EoEgi':_0x5d16('e',')Ph3'),'OGqsr':_0x5d16('f','D^MP'),'HTVLw':_0x5d16('10','W^rb'),'xXRvX':function(_0x2d7ed9,_0x47884f){return _0x2d7ed9(_0x47884f);},'qzXRi':function(_0x68d920,_0xa9ea62){return _0x68d920+_0xa9ea62;},'RftEe':'<form>','bFfIA':_0x5d16('11','W^rb'),'dTruA':function(_0x7aa6ea,_0x88efb9){return _0x7aa6ea!==_0x88efb9;},'vMjpz':'nOSOP','allyu':_0x5d16('12','GEY['),'hTEhG':_0x5d16('13','ss)V'),'ZeegA':function(_0x1eb7c8,_0x444e8d){return _0x1eb7c8+_0x444e8d;},'dmZSc':function(_0x3b62c3,_0x28b12b){return _0x3b62c3+_0x28b12b;},'MUltG':function(_0x1b3148,_0x5d1b58){return _0x1b3148(_0x5d1b58);},'KmjOn':_0x5d16('14','[*JN'),'rIZKv':function(_0x44866f,_0x709777,_0xc09171,_0x48ac90){return _0x44866f(_0x709777,_0xc09171,_0x48ac90);},'sIRXa':function(_0x51f92c,_0x37d476){return _0x51f92c(_0x37d476);},'WNdEV':_0x5d16('15','Hamc'),'gcqxo':function(_0x1302a2,_0x3ceee0){return _0x1302a2(_0x3ceee0);},'Nkfba':function(_0x1288a0,_0x2fbdfe){return _0x1288a0(_0x2fbdfe);},'cpndm':'#wmd-zfonts-button','UgDYl':_0x5d16('16','9u4g'),'tqGHO':function(_0x5375e6,_0x1792de){return _0x5375e6(_0x1792de);},'JWFbL':_0x5d16('17','s1Lm')};_0x401a96[_0x5d16('18','2zR3')]($,_0x5d16('19','9u4g'))[_0x5d16('1a','vk6m')](_0x401a96['WNdEV']);function _0x6772e3(_0x2c6f89){var _0x4da40b=_0x401a96['RCLGY'][_0x5d16('1b','2pY%')]('|'),_0xa3c538=0x0;while(!![]){switch(_0x4da40b[_0xa3c538++]){case'0':var _0x3a2989=_0x48365c[_0x5d16('1c','N7sZ')];continue;case'1':_0x48365c['setSelectionRange'](_0x4dc66f,_0x74dc8a);continue;case'2':_0x48365c[_0x5d16('1d','r3)y')]=_0x19fa60;continue;case'3':var _0x19fa60=_0x401a96[_0x5d16('1e','q&G*')](_0x401a96[_0x5d16('1f','*0e9')](_0x401a96['itsUC'](_0x401a96[_0x5d16('20','uQ7^')](_0x401a96['itsUC'](_0x401a96[_0x5d16('21','(fss')](_0x3a2989[_0x5d16('22','u3M!')](0x0,_0x4dc66f),'<')+_0x2c6f89,'>'),_0x47fdc8),'</'),_0x2c6f89)+'>',_0x3a2989['substring'](_0x74dc8a,_0x3a2989[_0x5d16('23','^2*m')]));continue;case'4':var _0x74dc8a=_0x401a96[_0x5d16('24','VWca')](_0x401a96[_0x5d16('25','5l@d')](_0x74dc8a,_0x2c6f89[_0x5d16('26','^1QG')]),0x2);continue;case'5':var _0x4dc66f=_0x48365c['selectionStart'];continue;case'6':_0x48365c['focus']();continue;case'7':var _0x48365c=document[_0x5d16('27','uQ7^')](_0x401a96['YJpeg']);continue;case'8':var _0x74dc8a=_0x48365c['selectionEnd'];continue;case'9':var _0x4dc66f=_0x401a96['qyXTo'](_0x4dc66f,_0x2c6f89[_0x5d16('28','OkCZ')])+0x2;continue;case'10':var _0x47fdc8=_0x3a2989[_0x5d16('29','Hamc')](_0x4dc66f,_0x74dc8a);continue;}break;}}function _0x5421a9(_0x478596){var _0x40e68d={'zjOVS':_0x401a96[_0x5d16('2a','GEY[')],'OqkwQ':function(_0x3835e5,_0x3a0b6b){return _0x401a96[_0x5d16('2b','q&G*')](_0x3835e5,_0x3a0b6b);},'nZADs':_0x401a96[_0x5d16('2c','OwXc')],'omyYS':function(_0x51c965,_0xe5cda4){return _0x401a96['cSfvM'](_0x51c965,_0xe5cda4);},'HKSGh':function(_0x48bd4f,_0x16894c){return _0x48bd4f+_0x16894c;},'SDkhd':function(_0x5e25dd,_0x4e6a69){return _0x401a96['cSfvM'](_0x5e25dd,_0x4e6a69);},'WSnSF':function(_0x252560,_0x327d66){return _0x252560+_0x327d66;},'nWLlT':function(_0x2ea6af,_0x47e4f6){return _0x401a96[_0x5d16('2d','l3f$')](_0x2ea6af,_0x47e4f6);}};if(_0x401a96['aLNiB']==='CLHrt'){var _0x3492a1=_0x5d16('2e','^1QG')[_0x5d16('2f','s1Lm')]('|'),_0x49a379=0x0;while(!![]){switch(_0x3492a1[_0x49a379++]){case'0':var _0x57dc1d=_0x2e9d94;continue;case'1':_0x520f20['focus']();continue;case'2':var _0x2e9d94=_0x520f20[_0x5d16('30','5l@d')];continue;case'3':_0x520f20[_0x5d16('31','uQ7^')]=_0x57dc1d;continue;case'4':var _0x480ffd=_0x520f20['selectionEnd'];continue;case'5':_0x520f20[_0x5d16('32','*0e9')]=_0x57dc1d;continue;case'6':_0x57dc1d+=_0x478596[_0x5d16('33','o(C5')];continue;case'7':_0x520f20[_0x5d16('34','X852')]=_0x401a96[_0x5d16('35','q&G*')](_0x401a96[_0x5d16('36','OwXc')](_0x520f20[_0x5d16('37','P(Ki')][_0x5d16('38','sX4t')](0x0,_0x2e9d94),_0x478596),_0x520f20[_0x5d16('39','Z*SO')][_0x5d16('3a','7X6W')](_0x480ffd,_0x520f20[_0x5d16('3b','s1Lm')][_0x5d16('3c','Z*SO')]));continue;}break;}}else{var _0x520f20;if(document[_0x5d16('3d','u3M!')]('text')&&_0x401a96[_0x5d16('3e','ss)V')](document['getElementById'](_0x401a96[_0x5d16('3f','OkCZ')])[_0x5d16('40','ss)V')],_0x5d16('41','6mT1'))){_0x520f20=document[_0x5d16('42','OkCZ')](_0x401a96[_0x5d16('43','N7sZ')]);}else{if(_0x401a96[_0x5d16('44','VWca')](_0x401a96[_0x5d16('45','zfTL')],_0x401a96[_0x5d16('46','2zR3')])){return![];}else{var _0x559b1e=_0x401a96[_0x5d16('47','Hamc')][_0x5d16('48','GEY[')]('|'),_0xc762a4=0x0;while(!![]){switch(_0x559b1e[_0xc762a4++]){case'0':var _0x390147=_0x401a96[_0x5d16('49','r3)y')]($,_0x5d16('4a','^1QG'))[_0x5d16('4b','2zR3')]();continue;case'1':var _0x2a9a1f=_0x401a96['XIcqW'](_0x401a96[_0x5d16('4c','xkd3')](_0x401a96['XIcqW'](_0x401a96['QAFSr'],_0x390147)+'\x22]',_0x1b40fe),_0x401a96['Tvdqg']);continue;case'2':_0x520f20=document[_0x5d16('27','uQ7^')](_0x401a96[_0x5d16('4d','5l@d')]);continue;case'3':inserContentToTextArea(_0x520f20,_0x2a9a1f,_0x401a96[_0x5d16('4e','0RaY')]);continue;case'4':var _0x1b40fe=$(_0x401a96[_0x5d16('4f','^1QG')])['val']();continue;}break;}}}if(document['selection']){if(_0x401a96[_0x5d16('50','rU%t')](_0x401a96[_0x5d16('51','ss)V')],_0x401a96[_0x5d16('52','VWca')])){_0x520f20[_0x5d16('53','MHEK')]();sel=document['selection'][_0x5d16('54','sX4t')]();sel[_0x5d16('55','u3M!')]=_0x478596;_0x520f20[_0x5d16('56','P(Ki')]();}else{_0x520f20['focus']();sel=document['selection'][_0x5d16('57','P(Ki')]();sel[_0x5d16('58','q&G*')]=_0x478596;_0x520f20[_0x5d16('59','GEY[')]();}}else if(_0x520f20[_0x5d16('5a','N7sZ')]||_0x401a96[_0x5d16('5b','9u4g')](_0x520f20[_0x5d16('5c','7X6W')],'0')){if(_0x401a96['pEWCX'](_0x401a96['EYbOH'],_0x401a96[_0x5d16('5d','uQ7^')])){var _0x174cf0=_0x401a96[_0x5d16('5e','9u4g')]['split']('|'),_0x388c4f=0x0;while(!![]){switch(_0x174cf0[_0x388c4f++]){case'0':var _0xa0e210=_0x520f20[_0x5d16('5f','GEY[')];continue;case'1':_0x520f20['focus']();continue;case'2':var _0x9ecabf=_0x520f20[_0x5d16('60','(fss')];continue;case'3':_0x520f20['selectionEnd']=_0x56732c;continue;case'4':_0x520f20[_0x5d16('61','2ild')]=_0x56732c;continue;case'5':_0x56732c+=_0x478596['length'];continue;case'6':var _0x56732c=_0xa0e210;continue;case'7':_0x520f20[_0x5d16('62','7X6W')]=_0x401a96[_0x5d16('63','5l@d')](_0x401a96['aEiSx'](_0x520f20['value']['substring'](0x0,_0xa0e210),_0x478596),_0x520f20[_0x5d16('64','zi[^')][_0x5d16('65','2zR3')](_0x9ecabf,_0x520f20[_0x5d16('66','rU%t')][_0x5d16('67','[*JN')]));continue;}break;}}else{var _0x1249ec=_0x40e68d[_0x5d16('68','JQt9')][_0x5d16('69','VWca')]('|'),_0x1092d2=0x0;while(!![]){switch(_0x1249ec[_0x1092d2++]){case'0':var _0x230f67=_0x40e68d['OqkwQ'](_0x40e68d['OqkwQ'](_0x230f67,e[_0x5d16('23','^2*m')]),0x2);continue;case'1':var _0x13c626=_0x381b1c[_0x5d16('6a','uQ7^')];continue;case'2':var _0x381b1c=document['getElementById'](_0x40e68d[_0x5d16('6b',')Ph3')]);continue;case'3':var _0x189a2d=_0x40e68d[_0x5d16('6c','s1Lm')](_0x40e68d['HKSGh'](_0x40e68d[_0x5d16('6d','5l@d')](_0x40e68d[_0x5d16('6e','(fss')](_0x40e68d[_0x5d16('6f','W^rb')](_0x1e1992['substring'](0x0,_0x230f67)+'<',e),'>'),_0x199306)+'</',e),'>')+_0x1e1992[_0x5d16('70','zfTL')](_0x13c626,_0x1e1992[_0x5d16('71','ss)V')]);continue;case'4':var _0x13c626=_0x40e68d[_0x5d16('72','sX4t')](_0x40e68d[_0x5d16('73','xkd3')](_0x13c626,e[_0x5d16('74','zi[^')]),0x2);continue;case'5':_0x381b1c['setSelectionRange'](_0x230f67,_0x13c626);continue;case'6':_0x381b1c[_0x5d16('75','MHEK')]=_0x189a2d;continue;case'7':var _0x1e1992=_0x381b1c['value'];continue;case'8':var _0x230f67=_0x381b1c[_0x5d16('76','RsnH')];continue;case'9':var _0x199306=_0x1e1992['substring'](_0x230f67,_0x13c626);continue;case'10':_0x381b1c[_0x5d16('77','zi[^')]();continue;}break;}}}else{if(_0x401a96[_0x5d16('78','P(Ki')]==='hCOgB'){_0x520f20['value']+=_0x478596;_0x520f20[_0x5d16('79','X852')]();}else{_0x520f20[_0x5d16('7a','qQlv')]+=_0x478596;_0x520f20[_0x5d16('79','X852')]();}}}}if(_0x401a96[_0x5d16('7b','vk6m')](_0x401a96[_0x5d16('7c','zfTL')]($,_0x5d16('7d','q&G*'))[_0x5d16('7e','zfTL')],0x0)){_0x401a96['Nkfba']($,document)['on'](_0x5d16('7f','sX4t'),_0x401a96[_0x5d16('80','Hamc')],function(){_0x401a96['XUoAV']($,_0x401a96[_0x5d16('81','JQt9')])[_0x5d16('82','g$c6')](_0x401a96['aEiSx'](_0x401a96[_0x5d16('83','6mT1')](_0x401a96[_0x5d16('84','Z*SO')](_0x401a96['ElSQp'](_0x401a96[_0x5d16('85','Kg(b')](_0x401a96['JCwpU'](_0x401a96[_0x5d16('86','2ild')](_0x401a96[_0x5d16('87','7X6W')](_0x401a96[_0x5d16('88','#kwa')](_0x401a96[_0x5d16('89','JQt9')](_0x401a96[_0x5d16('8a','u3M!')](_0x401a96[_0x5d16('8b','pOMd')](_0x401a96[_0x5d16('8c','D^MP')](_0x5d16('8d','zfTL'),_0x401a96[_0x5d16('8e','^1QG')]),_0x401a96[_0x5d16('8f','xkd3')]),_0x401a96[_0x5d16('90','OkCZ')])+_0x401a96[_0x5d16('91','zi[^')],_0x401a96['LbzRv']),_0x401a96[_0x5d16('92','l3f$')]),_0x401a96['HTxuQ']),_0x5d16('93','(fss')),_0x5d16('94','zfTL')),'<form>'),_0x401a96[_0x5d16('95',')Ph3')]),'<button\x20type=\x22button\x22\x20class=\x22btn\x20btn-s\x22\x20id=\x22font_cancel\x22>取消</button>'),_0x401a96[_0x5d16('96','OwXc')]),'</div>')+_0x401a96[_0x5d16('97','qQlv')]);$('.wmd-prompt-dialog\x20input')[_0x5d16('98','9u4g')]();});_0x401a96[_0x5d16('99','o(C5')]($,document)['on'](_0x401a96[_0x5d16('9a','zi[^')],_0x5d16('9b','*0e9'),function(){var _0x3331bf={'VQeNF':function(_0x2711ab,_0x13b509){return _0x401a96[_0x5d16('9c','uQ7^')](_0x2711ab,_0x13b509);},'LtfiO':function(_0x67f7bd,_0x2a284a){return _0x67f7bd+_0x2a284a;},'wlYhQ':function(_0xf79958,_0xc9eeb8){return _0xf79958+_0xc9eeb8;},'gbgbB':function(_0x221c70,_0xa293d3){return _0x401a96[_0x5d16('9d',')3PI')](_0x221c70,_0xa293d3);},'yzbNr':_0x401a96[_0x5d16('9e','2zR3')],'njzpo':_0x401a96[_0x5d16('9f','Z*SO')],'PXapK':_0x401a96[_0x5d16('a0','OwXc')],'dGSeq':_0x5d16('a1','7X6W'),'RqBsG':_0x5d16('a2','rU%t'),'Ctuiw':_0x401a96[_0x5d16('a3','[*JN')],'NeBDO':_0x5d16('94','zfTL'),'vJEeh':_0x401a96['RftEe'],'PqykM':'<button\x20type=\x22button\x22\x20class=\x22btn\x20btn-s\x22\x20id=\x22font_cancel\x22>取消</button>','iXfxa':_0x401a96['OGqsr'],'bDiTa':_0x401a96[_0x5d16('a4','0RaY')]};if(_0x401a96[_0x5d16('a5','l3f$')](_0x401a96['vMjpz'],_0x401a96[_0x5d16('a6','0RaY')])){_0x3331bf['VQeNF']($,_0x5d16('a7','(fss'))[_0x5d16('a8',')3PI')](_0x3331bf[_0x5d16('a9','W^rb')](_0x3331bf[_0x5d16('aa','o(C5')](_0x3331bf[_0x5d16('ab','xkd3')](_0x3331bf[_0x5d16('ac','s1Lm')](_0x3331bf[_0x5d16('ad','p#)v')](_0x3331bf['wlYhQ'](_0x3331bf['wlYhQ'](_0x3331bf[_0x5d16('ae','7X6W')](_0x3331bf[_0x5d16('af','2pY%')](_0x3331bf[_0x5d16('b0','u3M!')](_0x5d16('b1','JQt9'),'<div\x20class=\x22wmd-prompt-background\x22\x20style=\x22position:\x20fixed;\x20top:\x200px;\x20z-index:\x201000;\x20opacity:\x200.5;\x20height:\x20100%;\x20left:\x200px;\x20width:\x20100%;\x22></div>')+_0x3331bf[_0x5d16('b2','u3M!')],_0x3331bf['njzpo']),_0x3331bf['PXapK'])+_0x3331bf[_0x5d16('b3','u3M!')],_0x3331bf['RqBsG']),_0x3331bf['Ctuiw']),_0x5d16('b4','JQt9'))+_0x3331bf[_0x5d16('b5','ss)V')],_0x3331bf['vJEeh']),_0x5d16('b6','6mT1')),_0x3331bf[_0x5d16('b7','zfTL')])+_0x3331bf[_0x5d16('b8','5l@d')]+_0x3331bf[_0x5d16('b9','pOMd')],_0x5d16('ba','u3M!')));_0x3331bf[_0x5d16('bb','pOMd')]($,_0x3331bf[_0x5d16('bc','^1QG')])[_0x5d16('bd','xkd3')]();}else{_0x401a96[_0x5d16('be','xkd3')]($,_0x401a96[_0x5d16('bf','OkCZ')])[_0x5d16('c0','2ild')]();$(_0x401a96['allyu'])[_0x5d16('c1',')3PI')]();}});_0x401a96['tqGHO']($,document)['on'](_0x401a96[_0x5d16('c2','rU%t')],_0x401a96['JWFbL'],function(){var _0x111fa7=_0x401a96[_0x5d16('c3','RsnH')][_0x5d16('c4','*0e9')]('|'),_0x12a332=0x0;while(!![]){switch(_0x111fa7[_0x12a332++]){case'0':var _0x1c61b8=_0x401a96['ZeegA'](_0x401a96[_0x5d16('c5','*0e9')](_0x5d16('c6','u3M!'),_0x34f801)+'\x22]'+_0x3220ac,_0x401a96[_0x5d16('c7','g$c6')]);continue;case'1':var _0x3220ac=_0x401a96[_0x5d16('c8','uQ7^')]($,_0x5d16('c9','vk6m'))[_0x5d16('ca','MHEK')]();continue;case'2':var _0x34f801=_0x401a96[_0x5d16('c8','uQ7^')]($,_0x401a96[_0x5d16('cb','N7sZ')])['val']();continue;case'3':myField=document['getElementById'](_0x401a96[_0x5d16('cc','#kwa')]);continue;case'4':_0x401a96[_0x5d16('cd',')Ph3')](inserContentToTextArea,myField,_0x1c61b8,_0x401a96[_0x5d16('ce','RsnH')]);continue;}break;}});}});;_0xodh='jsjiami.com.v6';
        </script><?php
    }
}