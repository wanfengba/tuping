<?php
/**
 * vkkPay For Typecho付费阅读插件_95CodePay</a>
 * @package vkkPay(95CodePay专属版) For Typecho
 * @author 神话-云星日记
 * @version 1.5.0
 * @link https://www.sunjianjian.com/archives/504/
 * @date 2021-01-24
 */
require_once("Action.php");
class vkkPay_Plugin implements Typecho_Plugin_Interface{
    // 激活插件
    public static function activate(){
        vkkPay_Action::active();
        Typecho_Plugin::factory('Widget_Archive')->footer = array('vkkPay_Plugin', 'footer');
		Typecho_Plugin::factory('admin/write-post.php')->option = array(__CLASS__, 'setFeeContent');
		Typecho_Plugin::factory('Widget_Contents_Post_Edit')->finishPublish = array(__CLASS__, "updateFeeContent");
		Typecho_Plugin::factory('Widget_Archive')->select = array(__CLASS__, 'selectHandle');
    }

	
    // 禁用插件
    public static function deactivate(){
		$index = Helper::removeMenu('文章付费');		
		Helper::removeAction('vkkpay-post-free');
		Helper::removePanel($index, 'vkkPay/manage/posts.php');
		Helper::removePanel($index, 'vkkPay/manage/paylist.php');
        return _t('插件已被禁用');
    }
	/**
	 * 把付费内容设置装入文章编辑页
	 *
	 * @access public
	 * @return void
	 */
	public static function setFeeContent($post) {
		$db = Typecho_Db::get();
		$row = $db->fetchRow($db->select('vkkpay_content,vkkpay_price,vkkpay_isFee')->from('table.contents')->where('cid = ?', $post->cid));
		$vkkpay_content = isset($row['vkkpay_content']) ? $row['vkkpay_content'] : '';	
		$vkkpay_price = isset($row['vkkpay_price']) ? $row['vkkpay_price'] : '';	
		$vkkpay_isFee = isset($row['vkkpay_isFee']) ? $row['vkkpay_isFee'] : '';	
		if($vkkpay_isFee == "y"){
		$html = '<section class="typecho-post-option"><label for="vkkpay_price" class="typecho-label">是否付费</label>
				<p><span><input name="vkkpay_isFee" type="radio" value="n" id="vkkpay_isFee-n">
				<label for="vkkpay_isFee-n">
				免费的</label>
				</span><span>
				<input name="vkkpay_isFee" type="radio" value="y" id="vkkpay_isFee-y" checked="true">
				<label for="vkkpay_isFee-y">
				需付费</label>
				</span></p></section>
				<section class="typecho-post-option"><label for="vkkpay_price" class="typecho-label">付费价格（元）</label><p><input id="vkkpay_price" name="vkkpay_price" type="text" value="'.$vkkpay_price.'" class="w-100 text"></p></section>
				<section class="typecho-post-option"><label for="vkkpay_content" class="typecho-label">付费可见内容</label><p><textarea id="vkkpay_content" name="vkkpay_content" type="text" value="" class="w-100 text">'.$vkkpay_content.'</textarea></p></section>';
			
		}else{			
		$html = '<section class="typecho-post-option"><label for="vkkpay_price" class="typecho-label">是否付费</label>
				<p><span><input name="vkkpay_isFee" type="radio" value="n" id="vkkpay_isFee-n" checked="true">
				<label for="vkkpay_isFee-n">
				不显示付费</label>
				</span><span>
				<input name="vkkpay_isFee" type="radio" value="y" id="vkkpay_isFee-y">
				<label for="vkkpay_isFee-y">
				需付费</label>
				</span></p></section>
				<section class="typecho-post-option"><label for="vkkpay_price" class="typecho-label">付费价格（元）</label><p><input id="vkkpay_price" name="vkkpay_price" type="text" value="'.$vkkpay_price.'" class="w-100 text"></p></section>
				<section class="typecho-post-option"><label for="vkkpay_content" class="typecho-label">付费可见内容</label><p><textarea id="vkkpay_content" name="vkkpay_content" type="text" value="" class="w-100 text">'.$vkkpay_content.'</textarea></p></section>';
		}
		_e($html);
	}
	/**
	 * 发布文章同时更新文章类型
	 *
	 * @access public
	 * @return void
	 */
	public static function updateFeeContent($contents, $post){
		$vkkpay_isFee = $post->request->get('vkkpay_isFee', NULL);
		$vkkpay_price = $post->request->get('vkkpay_price', NULL);
		$vkkpay_content = $post->request->get('vkkpay_content', NULL);
		$db = Typecho_Db::get();
		$sql = $db->update('table.contents')->rows(array('vkkpay_isFee' => $vkkpay_isFee,'vkkpay_price' => $vkkpay_price,'vkkpay_content' => $vkkpay_content))->where('cid = ?', $post->cid);
		$db->query($sql);
	}
    /**
     * 把增加的字段添加到查询中，以便在模版中直接调用
     *
     * @access public
     * @return void
     */
	public static function selectHandle($archive){
		$user = Typecho_Widget::widget('Widget_User');
		if ('post' == $archive->parameter->type || 'page' == $archive->parameter->type) {
			if ($user->hasLogin()) {
				$select = $archive->select()->where('table.contents.status = ? OR table.contents.status = ? OR
						(table.contents.status = ? AND table.contents.authorId = ?)',
						'publish', 'hidden', 'private', $user->uid);
			} else {
				$select = $archive->select()->where('table.contents.status = ? OR table.contents.status = ?',
						'publish', 'hidden');
			}
		} else {
			if ($user->hasLogin()) {
				$select = $archive->select()->where('table.contents.status = ? OR
						(table.contents.status = ? AND table.contents.authorId = ?)', 'publish', 'private', $user->uid);
			} else {
				$select = $archive->select()->where('table.contents.status = ?', 'publish');
			}
		}
		$select->where('table.contents.created < ?', Typecho_Date::gmtTime());
		$select->cleanAttribute('fields');
		return $select;
	}
	
	
	/**
     * 在主题中直接调用
     *
     * @access public
     * @return int
     * @throws
     */
    public static function getvkkpay(){
        echo '
        <style>
        .feetype input[type="radio"] {
        display: none;
        }
        .feetype label img {
        width: 60px;

        margin: 0 !important;
        box-shadow: none !important;
        }
       .feetype label span {
        line-height: 50px;

        }
        .tepass_price {
         padding: 4px 18px;
         background-color: #ffffff;
         color: #f0ad4e;
         line-height: 1;
         border-radius: 20px;
         font-size: 13px;
         border: 1px solid #f0ad4e;
         }
         .tepass_price_for_vip {
         font-size: 14px !important;
         line-height: 20px !important;
         color: #ffa400;
         }

</style>';
		$db = Typecho_Db::get();
		$options = Typecho_Widget::widget('Widget_Options');
		$option=$options->plugin('vkkPay');
        $cid = Typecho_Widget::widget('Widget_Archive')->cid;
		$query= $db->select()->from('table.contents')->where('cid = ?', $cid ); 
		$row = $db->fetchRow($query);
		if($row['vkkpay_isFee']=='y'){
			if($row['authorId']!=Typecho_Cookie::get('__typecho_uid')){
				$cookietime=$option->vkkpay_cookietime==""?1:$option->vkkpay_cookietime;
				if(!isset($_COOKIE["vkkpayCookie"])){
					$randomCode = md5(uniqid(microtime(true),true));
					setcookie("vkkpayCookie",$randomCode, time()+3600*24*$cookietime,'/');
				}
				$queryItem= $db->select()->from('table.vkkpay_fees')->where('feecookie = ?', $_COOKIE["vkkpayCookie"])->where('feestatus = ?', 1)->where('feecid = ?', $row['cid']); 
				$rowItem = $db->fetchRow($queryItem);
				$rowUserItemNum = 0;
				if(Typecho_Cookie::get('__typecho_uid')){
					$queryUserItem= $db->select()->from('table.vkkpay_fees')->where('feeuid = ?', Typecho_Cookie::get('__typecho_uid'))->where('feestatus = ?', 1)->where('feecid = ?', $row['cid']); 
					$rowUserItem = $db->fetchRow($queryUserItem);
					if(!empty($rowUserItem)){
						$rowUserItemNum = 1;
					}
				}
				if(count($rowItem) != 0 || $rowUserItemNum){ ?>			
				<div style="background:#f8f8f8;padding:30px 20px;border:1px dashed #ccc;position: relative;z-index:999;margin:15px 0">
					<span><?php echo $row['vkkpay_content'] ?></span>
					<span style="position: absolute;top:5px;left:15px;font-size:90%;color:#90949c;">订单号：<?php echo $rowItem['feeid'] ?></span>
					<span style="position: absolute;top:5px;right:15px;"><img style="width:22px;" src="/usr/plugins/vkkPay/pay5.png" alt=""></span>
				</div>
				<?php }else{ ?>
					<div class="feetype" style="background:#f8f8f8;padding:35px 15px 10px;border:1px dashed #ccc;position: relative;text-align:center;margin:15px 0;">
						<form id="vkkayPayPost" onsubmit="return false" action="##" method="post" style="margin:10px 0;">
							<?php if($option->show_Alipay_Wxpay == "all"){ ?>
    <label  for="feetype1" onmousedown="choose_pay(1)">
    <img id="labe1" src="/usr/plugins/vkkPay/static/img/alipay2.png" nogallery="nogallery" no-zoom="true">
    <span>支付宝支付</span>
    </label>
    <input type="radio" id="feetype1" name="feetype" value="alipay" checked="checked">
    <label  for="feetype2" onmousedown="choose_pay(2)">
        <img id="labe2" src="/usr/plugins/vkkPay/static/img/wechat1.png" nogallery="nogallery" no-zoom="true">
        <span>微信支付</span></label>
    <input type="radio" id="feetype2" name="feetype" value="wxpay">
							<?php }else{
								if($option->show_Alipay_Wxpay == "alipay"){?>					
    <label  for="feetype1">
    <img id="labe1" src="/usr/plugins/vkkPay/static/img/alipay2.png" nogallery="nogallery" no-zoom="true">
    <span>支付宝支付</span>
    </label>
    <input type="radio" id="feetype1" name="feetype" value="alipay" checked="checked">
    <input type="radio" id="feetype2" name="feetype" value="wxpay">
								<?php }else{?>
								<input type="radio" id="feetype1" name="feetype" value="alipay">
    <label  for="feetype2">
        <img id="labe2" src="/usr/plugins/vkkPay/static/img/wechat2.png" nogallery="nogallery" no-zoom="true">
        <span>微信支付</span></label>
    <input type="radio" id="feetype2" name="feetype" value="wxpay" checked="checked">
								<?php }
							}?>
							<div style="clear:left;"></div>				
							<div style="height:34px;line-height:34px;border:none;-moz-border-radius: 0px;-webkit-border-radius: 0px;border-radius:0px;">
							<span class="tepass_price tepass_price_for_vip">价格： <?php echo $row['vkkpay_price'] ?> ￥</span>
							</div>
							
							<input id="verifybtn" style="border-radius: 4px; border-style: none; width: 80px; height: 34px; line-height: 34px; padding: 0 5px; background-color: #F60; text-align: center; color: #FFF; font-size: 14px;cursor: pointer;-webkit-appearance : none ;" onclick="vkkpayPayPost();" οnkeydοwn="enter_down(this.form, event);" type="button" value="付款"/>
							<input type="hidden" name="action" value="paysubmit" />
							<input type="hidden" id="feecid" name="feecid" value="<?php echo $row['cid'] ?>" />
							<input type="hidden" id="feeuid" name="feeuid" value="<?php echo Typecho_Cookie::get('__typecho_uid') ?>" />
						</form>
						<div style="clear:left;"></div>
						<span>温馨提示：付款后<?php echo $cookietime;?>天内可重复阅读，请及时查看。</span><br/>
						<span style="position: absolute;top:5px;left:15px;font-size:90%;color:#90949c;">内容需付费可见</span>
						<span style="position: absolute;top:5px;right:15px;"><img style="width:22px;" src="/usr/plugins/vkkPay/pay5.png" alt=""></span>
					</div>
				<?php } 
			}else{ ?>			
			<div style="background:#f8f8f8;padding:35px 15px 10px;border:1px dashed #ccc;position: relative;z-index:999;margin:15px 0">
				<span><?php echo $row['vkkpay_content'] ?></span>
				<span style="position: absolute;top:5px;left:15px;font-size:90%;color:#90949c;">已授权作者本人可读</span>
				<span style="position: absolute;top:5px;right:15px;"><img style="width:22px;" src="/usr/plugins/vkkPay/pay5.png" alt=""></span>
			</div>
		<?php } 
		}
    }
	
    // 插件配置面板
    public static function config(Typecho_Widget_Helper_Form $form){
		$db = Typecho_Db::get();
		$prefix = $db->getPrefix();
		$options = Typecho_Widget::widget('Widget_Options');
		$plug_url = $options->pluginUrl;
		$div=new Typecho_Widget_Helper_Layout();
		$div->html('<small>		
			<h1>基础功能</h1>
							<span><p>第一步：配置下方各项参数；</p></span>
			<span>
				<p>
					第二步：在主题post.php文件相应位置添加：
					<p><font color="blue">&lt;?php echo vkkPay_Plugin::getvkkPay(); ?></font> 教程请看：<font color="green">https://www.sunjianjian.com/archives/504/</font>
					</p>
			</span>
			第三步：填写<font color="red">配套</font>95CodePay商户账号+秘钥</p>
			</span>
			<span><p>第四步：等待其他用户或游客购买对应付费文章；</p></span>
			温馨提示：一切问题以及插件建议请联系<a target="_blank" href="https://wpa.qq.com/msgrd?v=3&uin=2297119837&site=qq&menu=yes"><img border="0" src="https://wpa.qq.com/pa?p=2:2297119837:51" alt="点击这里给我发消息" title="点击这里给我发消息"/></a></p>
		</small>');
		$div->render();
		
		//配置信息
		$vkkpay_cookietime = new Typecho_Widget_Helper_Form_Element_Text('vkkpay_cookietime', array('value'), "", _t('免登录时长'), _t('免登录可查看的时间'));
        $form->addInput($vkkpay_cookietime);
		//95CodePay配置
        $vkkpay_sitename = new Typecho_Widget_Helper_Form_Element_Text('vkkpay_sitename', array('value'), "", _t('商户名'), _t('随便填写一个商户名'));
        $form->addInput($vkkpay_sitename);
        $vkkpay_epayurl = new Typecho_Widget_Helper_Form_Element_Text('vkkpay_epayurl', array('value'), "", _t('95CodePay-API地址'), _t('请在结尾添加submit.php(直接填写https://pay.95.rs/submit.php)'));
        $form->addInput($vkkpay_epayurl);
		$vkkpay_pid = new Typecho_Widget_Helper_Form_Element_Text('vkkpay_pid', array('value'), "", _t('95CodePay商户号'), _t('在95CodePay册的商户号。'));
        $form->addInput($vkkpay_pid);
		$vkkpay_key = new Typecho_Widget_Helper_Form_Element_Text('vkkpay_key', array('value'), "", _t('95CodePay平台KEY.'), _t('在95CodePay的对接KEY。'));
        $form->addInput($vkkpay_key);
		//设置显示微信，支付宝，还是全部都显示
		$show_Alipay_Wxpay= new Typecho_Widget_Helper_Form_Element_Radio('show_Alipay_Wxpay',array('all' => _t('全部显示'),'alipay' => _t('仅支付宝'),'wxpay' => _t('仅微信支付')),'wxpay',_t('支付方式'),_t("根据实际情况选择"));
		$form->addInput($show_Alipay_Wxpay);
    }

    // 个人用户配置面板
    public static function personalConfig(Typecho_Widget_Helper_Form $form){
    }

    // 获得插件配置信息
    public static function getConfig(){
        return Typecho_Widget::widget('Widget_Options')->plugin('vkkpay');
    }
	
	public static function footer(){
		echo '
		<script src="/usr/plugins/vkkPay/static/main.js"></script>
		<script src="https://cdn.jsdelivr.net/gh/ylwind/layer@master/dist/layer.js"></script>
		<script src="https://cdn.jsdelivr.net/npm/jquery@2.2.4/dist/jquery.min.js"></script>';
		
	}


	/*修改数据表字段*/
	public static function alterColumn($db,$table,$column,$define){
		$prefix = $db->getPrefix();
		$query= "select * from information_schema.columns WHERE table_name = '".$table."' AND column_name = '".$column."'";
		$row = $db->fetchRow($query);
		if(count($row)==0){
			$db->query('ALTER TABLE `'.$table.'` ADD COLUMN `'.$column.'` '.$define.';');
		}
	}

  	/*创建支付订单数据表*/
	public static function createTablevkkpayFee($db){
		$prefix = $db->getPrefix();
		$db->query('CREATE TABLE IF NOT EXISTS `'.$prefix.'vkkpay_fees` (
		  `feeid` varchar(64) COLLATE utf8_general_ci NOT NULL,
		  `feecid` bigint(20) DEFAULT NULL,
		  `feeuid` bigint(20) DEFAULT NULL,
		  `feeprice` double(10,2) DEFAULT NULL,
		  `feetype` enum("alipay","wxpay") COLLATE utf8_general_ci DEFAULT "alipay",
		  `feestatus` smallint(2) DEFAULT "0" COMMENT "订单状态：0、未付款；1、付款成功；2、付款失败",
		  `feeinstime` datetime DEFAULT NULL,
		  `feecookie` varchar(255) COLLATE utf8_general_ci DEFAULT NULL,
          `url` text DEFAULT NULL,
		  PRIMARY KEY (`feeid`)
		) DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;');
	}
	
	public static function form($action = NULL)
	{
		/** 构建表格 */
		$options = Typecho_Widget::widget('Widget_Options');
		$form = new Typecho_Widget_Helper_Form(Typecho_Common::url('/action/vkkpay-post-free', $options->index),
		Typecho_Widget_Helper_Form::POST_METHOD);
		
		/** 标题 */
		$title = new Typecho_Widget_Helper_Form_Element_Text('title', NULL, NULL, _t('标题*'));
		$form->addInput($title);
		
		/** 是否付费 */
		$vkkpay_isFee = new Typecho_Widget_Helper_Form_Element_Radio('vkkpay_isFee', 
						array('n' => _t('免费的'), 'y' => _t('要付费')),
						'n', _t('是否需付费*'));		
		$form->addInput($vkkpay_isFee);
		
		/** 付费价格 */
		$vkkpay_price = new Typecho_Widget_Helper_Form_Element_Text('vkkpay_price', NULL, NULL, _t('付费价格（元）*'));
		$form->addInput($vkkpay_price);
		
		/** 付费可见内容 */
		$vkkpay_content = new Typecho_Widget_Helper_Form_Element_Textarea('vkkpay_content', NULL, NULL, _t('付费可见内容*'));
		$form->addInput($vkkpay_content);
			
		/** 链接动作 */
		$do = new Typecho_Widget_Helper_Form_Element_Hidden('do');
		$form->addInput($do);
		
		/** 链接主键 */
		$cid = new Typecho_Widget_Helper_Form_Element_Hidden('cid');
		$form->addInput($cid);
		
		/** 提交按钮 */
		$submit = new Typecho_Widget_Helper_Form_Element_Submit();
		$submit->input->setAttribute('class', 'btn primary');
		$form->addItem($submit);
		$request = Typecho_Request::getInstance();

        if (isset($request->cid) && 'insert' != $action) {
            /** 更新模式 */
			$db = Typecho_Db::get();
			$prefix = $db->getPrefix();
            $post = $db->fetchRow($db->select()->from($prefix.'contents')->where('cid = ?', $request->cid));
            if (!$post) {
                throw new Typecho_Widget_Exception(_t('文章不存在'), 404);
            }
            
            $title->value($post['title']);
            $vkkpay_isFee->value($post['vkkpay_isFee']);
            $vkkpay_price->value($post['vkkpay_price']);
            $vkkpay_content->value($post['vkkpay_content']);
            $do->value('update');
            $cid->value($post['cid']);
            $submit->value(_t('确认付费'));
            $_action = 'update';
        } else {
            $submit->value(_t('确认付费'));
        }
        
        if (empty($action)) {
            $action = $_action;
        }
      
        return $form;
	}
}
