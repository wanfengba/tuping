<?php
class epay{
    private $url = '';//易支付接口地址
    private $key = '';// 填写通信密钥
    private $pid = '';// 特写商户号
    public function __construct($data=null,$pid="",$key,$url) {
        $this->data = $data;
        $this->pid = $pid;
        $this->key = $key;
        $this->url = $url;
    }
    public function pay(){
        $data = $this->data;
        $data['pid'] = $this->pid;
	    $data['return_url'] = $data['notify_url'];
        $data['sign'] = $this->sign($data);
        $data['sign_type']='MD5';
        return $this->url.'?'.http_build_query($data);
    }
    public function post($data, $url) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        $rst = curl_exec($ch);
        curl_close($ch);
        return $rst;
    }
    public function sign($params)
    {
        ksort($params);

        $keyStr = '';
        foreach ($params as $key => $val) {
			if($key == "sign" || $key == "sign_type" || $val == "")continue;
            $keyStr .= "$key=$val&";
        }
		$keyStr = trim($keyStr,'&');

        $sign = md5($keyStr . $this->key);

        return $sign;
    }
}
?>