<?php 
//重定向浏览器 
header("Location: https://cashier.ylwind.cn/user/order.php"); 
//确保重定向后，后续代码不会被执行 
exit;
?>  
