<?php
 $yzm =  array (
  'danmuon' => 'on',
  'color' => '#00a1d6',
  'logo' => '',
  'trytime' => '3',
  'waittime' => '10',
  'sendtime' => '1',
  'dmrule' => '../dmku/dm_rule.html',
  'pbgjz' => '草,操,妈,逼,滚,网址,网站,支付宝,企,关注,wx,微信,qq,QQ',
  'ads' => 
  array (
    'state' => 'on',
    'set' => 
    array (
      'state' => '1',
      'group' => 'null',
      'pic' => 
      array (
        'time' => '3',
        'img' => 'https://cdn.jsdelivr.net/gh/Fog-Forest/Picture-Bed/IMG/20200519205744.jpg',
        'link' => '#',
      ),
      'vod' => 
      array (
        'url' => '/ad.mp4',
        'link' => '',
      ),
    ),
    'pause' => 
    array (
      'pic' => 'https://cdn.jsdelivr.net/gh/Fog-Forest/Picture-Bed/IMG/20200519210705.jpg',
      'link' => '#',
    ),
  ),
);
