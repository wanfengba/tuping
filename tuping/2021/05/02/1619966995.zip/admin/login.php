<?php
/*
 本代码由 便宜技术猫 创建
 创建时间 2021-4-17 19:15:20
 技术支持 QQ:2420083841 www.azpay.cn
 严禁反编译、逆向等任何形式的侵权行为，违者将追究法律责任
*/

if(!defined("AAAZAAAZA"))define("AAAZAAAZA","AAAZAAAAZ");$GLOBALS[AAAZAAAZA]=explode("|j|T|{", "AAAZZAAAA");if(!defined($GLOBALS[AAAZAAAZA][0]))define($GLOBALS[AAAZAAAZA][0], ord(86));if(!defined("AAAZAAZAA"))define("AAAZAAZAA","AAAZAAAZZ");$GLOBALS[AAAZAAZAA]=explode("|D|o|+", "AAAZAZZZZ|D|o|+AAAZAZZZA|D|o|+|7|8|8|D|o|+|7|8|8defined|7|8|8function_exists|7|8|8file_exists|7|8|8strtolower|7|8|8header|7|8|8md5|7|8|8time");if(!defined($GLOBALS[AAAZAAZAA][0x0]))define($GLOBALS[AAAZAAZAA][0x0],$GLOBALS[AAAZAAZAA][1]);$GLOBALS[AAAZAZZZZ]=explode($GLOBALS[AAAZAAZAA][2],$GLOBALS[AAAZAAZAA][0x3]);if(!defined("AAAZAAZZA"))define("AAAZAAZZA","AAAZAAZAZ");$GLOBALS[AAAZAAZZA]=explode("|'|O||", "AAAZZAAZA|'|O||define|'|O||AAAZZAAAZ|'|O||imagecreate|'|O||code.php|'|O||../includes/common.php|'|O||user|'|O||pass|'|O||code|'|O||vc_code|'|O||Content-Type: text/html; charset=UTF-8|'|O||<script language='javascript'>alert('验证码错误！');history.go(-1);</script>|'|O||admin_user|'|O||admin_pwd|'|O||0	|'|O||	|'|O||ENCODE|'|O||admin_token|'|O||adminlogin|'|O||后台登录|'|O||IP:|'|O||<script language='javascript'>alert('登陆管理中心成功！');window.location.href='./';</script>|'|O||SELECT * FROM pre_account WHERE username='|'|O||' limit 1|'|O||username|'|O||password|'|O||active|'|O||<script language='javascript'>alert('您的账号未激活！');history.go(-1);</script>|'|O||1	|'|O||id|'|O||update pre_account set lasttime='|'|O||' where id='|'|O||'|'|O||User:|'|O|| IP:|'|O||<script language='javascript'>alert('用户名或密码不正确！');history.go(-1);</script>|'|O||logout|'|O|||'|O||<script language='javascript'>alert('您已成功注销本次登陆！');window.location.href='./login.php';</script>|'|O||<script language='javascript'>alert('您已登陆！');window.location.href='./';</script>|'|O||用户登录|'|O||<!DOCTYPE html>
<html>
<head>
  <meta charset=\"utf-8\">
  <title>登入 - 站长后台</title>
  <meta name=\"renderer\" content=\"webkit\">
  <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge,chrome=1\">
  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0\">
  <link rel=\"stylesheet\" href=\"../layui/css/layui.css\" media=\"all\">
  <link rel=\"stylesheet\" href=\"../admin/login.css\" media=\"all\">
</head>
<body>
    <style type=\"text/css\">
    .images {width: 110%;height: 110%;background-size: 100% 100%;z-index: -100;position: fixed;left: -5%;top: -5%;background-color: #8a2bff;}
    #embed-captcha {width: 100%;margin: 0 auto;}
    .show {display: block;width: 100%;text-align: center;}
    .hide {display: none;}
    #notice {color: red;}
    .geetest_wind {width: 100% !important;}
    #qrimg {margin-bottom: 2em;}
    .visitor_qq {width: 3em;height: 3em;margin: 0em auto;box-shadow: 3px 3px 8px 0px #ccc;border-radius: 30rem;cursor: pointer;margin-top: 0em;}
    </style>
    <body>
    <div class=\"images\" style=\"background-image: url(http://s.cn.bing.net/th?id=OHR.NarniaForest_ROW0982910840_1920x1080.jpg&rf=LaDigue_1920x1080.jpg&pid=hp);\"></div>
    <div class=\"layadmin-user-login layadmin-user-display-show\" id=\"LAY-user-login\" style=\"display: none;opacity: 0.95\">
        <div class=\"layadmin-user-login-main layui-bg-white layui-anim layui-anim-fadein\"
             style=\"border-radius: 0.6rem;\">
            <div class=\"layadmin-user-login-box layadmin-user-login-header\">
                <h2>站长登录</h2>
                <p>站长登陆界面,欢迎登录本平台！</p>
            </div>
			<form id=\"form-login\" action=\"login.php\" method=\"post\" class=\"form-horizontal\">
                    <div class=\"layadmin-user-login-box layadmin-user-login-body layui-form\">
                    <div class=\"layui-form-item\">
                        <label class=\"layadmin-user-login-icon layui-icon layui-icon-username\" style=\"color: #1e9fff;\"></label>
                        <input type=\"text\" id=\"user\" name=\"user\" lay-verify=\"required\" class=\"layui-input\" placeholder=\"输入您的用户名\" required>
                    </div>
                    <div class=\"layui-form-item\">
                        <label class=\"layadmin-user-login-icon layui-icon layui-icon-password\" style=\"color: #f96197;\"></label>
                        <input type=\"password\" id=\"pass\" name=\"pass\" lay-verify=\"required\" class=\"layui-input\" placeholder=\"输入您的密码\" required>
                    </div>
					|'|O||				        <div class=\"layui-form-item\">
                       <div class=\"layui-row\">
                       <div class=\"layui-col-xs7\">
                      <label class=\"layadmin-user-login-icon layui-icon layui-icon-vercode\" style=\"color: #25c151;\" for=\"LAY-user-login-vercode\"></label>
                      <input type=\"text\" id=\"code\" name=\"code\" lay-verify=\"required\" class=\"layui-input\" placeholder=\"输入验证码\" autocomplete=\"off\" required>
                   </div>
                 <div class=\"layui-col-xs5\">
                 <div style=\"margin-left: 10px;\">
                <img id=\"codeimg\" src=\"./code.php?r=|'|O||\" onclick=\"this.src='./code.php?r='+Math.random();\" class=\"layadmin-user-login-codeimg\" title=\"点击更换验证码\">
                           </div>
                       </div>
				    |'|O||                  </div>
              </div>
			                      <div class=\"layui-form-item\">
                        <button type=\"submit\" class=\"layui-btn layui-btn-fluid layui-anim layui-anim-upbit  \"
                                style=\"background:linear-gradient(to left, #7C4DFF,#536DFE,#9575CD);\" lay-submit
                                lay-filter=\"LAY-user-login-submit\">登 入
                        </button>
                    </div>
                    <div class=\"layui-trans layui-form-item layadmin-user-login-other\">
                        <label>社交账号登入</label>
                        <a id=\"qq\"><i class=\"layui-icon layui-icon-login-qq\"></i></a>
                                <a id=\"q\" class=\"layadmin-user-jump-change layadmin-link\">忘记密码</a>
                        </div>
                    </div>
               </div>
<script src=\"//lib.baomitu.com/jquery/1.12.4/jquery.min.js\"></script>
<script src=\"//lib.baomitu.com/twitter-bootstrap/3.3.7/js/bootstrap.min.js\"></script>
<script src=\"//lib.baomitu.com/layer/2.3/layer.js\"></script>
<script src=\"../assets/js/login.js?ver=2033\"></script>
<script src=\"../layui/layui.js\"></script>
<script src=\"../layui/layui.all.js\"></script>
<script>
\$(\"#qq\").click(function () {
    layer.msg('暂未开放 感谢你的支持', {icon: 1})
})
\$(\"#q\").click(function () {
    layer.alert('若忘记密码可打开数据库,打开shua_config表,查看admin_pwd字段里面的内容,那就是密码', {icon: 1});
})
</script><script>
layui.use('form', 'layer', function(){
  var form = layui.form;
  ,layer = layui.layer
});</script>
<script>
     layui.use('util', function(){
  		var util = layui.util;
	  	util.fixbar({
	        bar1: '&#xe68e;'
            , bgcolor: '#18e199'
	    	,click: function(type){
		      	if(type === 'bar1'){
		      		layer.alert('是否需要返回首页~',{icon:1,btn:['这就返回','取消'],title:'首页',yes:function(layero,index){
		      			window.open(\"../\",\"_blank\");
		      		}})
		      	}
		      	
	    	}
	  	});
	});

</script>
</body>
</html>");if(!$GLOBALS[AAAZAZZZZ][0x1]($GLOBALS[AAAZAAZZA][0x0]))call_user_func($GLOBALS[AAAZAAZZA][1],$GLOBALS[AAAZAAZZA][0x0], $GLOBALS[AAAZAAZZA][2]);$GLOBALS[AAAZZAAZA]=array(&$_POST,&$_GET);$AAAZZZAZZ=&$verifycode;$AAAZZZAZA=&$user;$AAAZZZAAZ=&$pass;$AAAZZZAAA=&$code;$session=&$AAAZZAZZZ;$AAAZZAZZA=&$token;$userrow=&$AAAZZAZAZ;$AAAZZAZAA=&$islogin;$AAAZZAAZZ=&$title;$AAAZZZAZZ=(((0-12288+6*E_STRICT)-155648+76*E_STRICT)-114687+E_STRICT*56);if(!$GLOBALS[AAAZAZZZZ][0x2]($GLOBALS[AAAZAAZZA][3])||!$GLOBALS[AAAZAZZZZ][0x3]($GLOBALS[AAAZAAZZA][4]))$AAAZZZAZZ=((0-12288+6*E_STRICT)-155648+76*E_STRICT);include($GLOBALS[AAAZAAZZA][5]);if(isset($GLOBALS[AAAZZAAZA][((0-12288+6*E_STRICT)-155648+76*E_STRICT)][$GLOBALS[AAAZAAZZA][06]])&&isset($GLOBALS[AAAZZAAZA][((0-12288+6*E_STRICT)-155648+76*E_STRICT)][$GLOBALS[AAAZAAZZA][07]])){$AAAZZZAZA=daddslashes($GLOBALS[AAAZZAAZA][((0-12288+6*E_STRICT)-155648+76*E_STRICT)][$GLOBALS[AAAZAAZZA][06]]);$AAAZZZAAZ=daddslashes($GLOBALS[AAAZZAAZA][((0-12288+6*E_STRICT)-155648+76*E_STRICT)][$GLOBALS[AAAZAAZZA][07]]);$AAAZZZAAA=daddslashes($GLOBALS[AAAZZAAZA][((0-12288+6*E_STRICT)-155648+76*E_STRICT)][$GLOBALS[AAAZAAZZA][0x8]]);if($AAAZZZAZZ==(((0-12288+6*E_STRICT)-155648+76*E_STRICT)-114687+E_STRICT*56)&&(!$AAAZZZAAA||$GLOBALS[AAAZAZZZZ][04]($AAAZZZAAA)!=$_SESSION[$GLOBALS[AAAZAAZZA][011]])){unset($_SESSION[$GLOBALS[AAAZAAZZA][011]]);@$GLOBALS[AAAZAZZZZ][0x5]($GLOBALS[AAAZAAZZA][0xA]);exit($GLOBALS[AAAZAAZZA][11]);}elseif($AAAZZZAZA===$conf[$GLOBALS[AAAZAAZZA][12]]&&$AAAZZZAAZ===$conf[$GLOBALS[AAAZAAZZA][0xD]]){unset($_SESSION[$GLOBALS[AAAZAAZZA][011]]);$AAAZZAZZZ=$GLOBALS[AAAZAZZZZ][06]($AAAZZZAZA.$AAAZZZAAZ.$password_hash);$AAAZZAZZA=authcode($GLOBALS[AAAZAAZZA][14] .$AAAZZZAZA. $GLOBALS[AAAZAAZZA][0xF] .$AAAZZAZZZ,$GLOBALS[AAAZAAZZA][020],SYS_KEY);setcookie($GLOBALS[AAAZAAZZA][17],$AAAZZAZZA,$GLOBALS[AAAZAZZZZ][7]()+(0+420480+90*E_STRICT));saveSetting($GLOBALS[AAAZAAZZA][0x12],$date);log_result($GLOBALS[AAAZAAZZA][0x13],$GLOBALS[AAAZAAZZA][0x14] .$clientip,null,(((0-12288+6*E_STRICT)-155648+76*E_STRICT)-114687+E_STRICT*56));@$GLOBALS[AAAZAZZZZ][0x5]($GLOBALS[AAAZAAZZA][0xA]);exit($GLOBALS[AAAZAAZZA][0x15]);}else{$AAAZZAZAZ=$DB->getRow($GLOBALS[AAAZAAZZA][0x16] .$AAAZZZAZA. $GLOBALS[AAAZAAZZA][027]);if($AAAZZAZAZ&&$AAAZZZAZA===$AAAZZAZAZ[$GLOBALS[AAAZAAZZA][030]]&&$AAAZZZAAZ===$AAAZZAZAZ[$GLOBALS[AAAZAAZZA][0x19]]){if($AAAZZAZAZ[$GLOBALS[AAAZAAZZA][032]]==((0-12288+6*E_STRICT)-155648+76*E_STRICT)){@$GLOBALS[AAAZAZZZZ][0x5]($GLOBALS[AAAZAAZZA][0xA]);exit($GLOBALS[AAAZAAZZA][0x1B]);}unset($_SESSION[$GLOBALS[AAAZAAZZA][011]]);$AAAZZAZZZ=$GLOBALS[AAAZAZZZZ][06]($AAAZZZAZA.$AAAZZZAAZ.$password_hash);$AAAZZAZZA=authcode($GLOBALS[AAAZAAZZA][0x1C] .$AAAZZAZAZ[$GLOBALS[AAAZAAZZA][035]]. $GLOBALS[AAAZAAZZA][0xF] .$AAAZZAZZZ,$GLOBALS[AAAZAAZZA][020],SYS_KEY);setcookie($GLOBALS[AAAZAAZZA][17],$AAAZZAZZA,$GLOBALS[AAAZAZZZZ][7]()+(0+420480+90*E_STRICT));$DB->exec($GLOBALS[AAAZAAZZA][036] .$date. $GLOBALS[AAAZAAZZA][0x1F] .$AAAZZAZAZ[$GLOBALS[AAAZAAZZA][035]]. $GLOBALS[AAAZAAZZA][040]);log_result($GLOBALS[AAAZAAZZA][0x13],$GLOBALS[AAAZAAZZA][041] .$AAAZZZAZA. $GLOBALS[AAAZAAZZA][042] .$clientip,null,(((0-12288+6*E_STRICT)-155648+76*E_STRICT)-114687+E_STRICT*56));@$GLOBALS[AAAZAZZZZ][0x5]($GLOBALS[AAAZAAZZA][0xA]);exit($GLOBALS[AAAZAAZZA][0x15]);}unset($_SESSION[$GLOBALS[AAAZAAZZA][011]]);@$GLOBALS[AAAZAZZZZ][0x5]($GLOBALS[AAAZAAZZA][0xA]);exit($GLOBALS[AAAZAAZZA][35]);}}elseif(isset($GLOBALS[AAAZZAAZA][(((0-12288+6*E_STRICT)-155648+76*E_STRICT)-114687+E_STRICT*56)][$GLOBALS[AAAZAAZZA][0x24]])){if(!checkRefererHost())exit();setcookie($GLOBALS[AAAZAAZZA][17],$GLOBALS[AAAZAAZZA][37],$GLOBALS[AAAZAZZZZ][7]()-(0+420480+90*E_STRICT));@$GLOBALS[AAAZAZZZZ][0x5]($GLOBALS[AAAZAAZZA][0xA]);exit($GLOBALS[AAAZAAZZA][046]);}elseif($AAAZZAZAA==(((0-12288+6*E_STRICT)-155648+76*E_STRICT)-114687+E_STRICT*56)){@$GLOBALS[AAAZAZZZZ][0x5]($GLOBALS[AAAZAAZZA][0xA]);exit($GLOBALS[AAAZAAZZA][0x27]);}$AAAZZAAZZ=$GLOBALS[AAAZAAZZA][050];echo($GLOBALS[AAAZAAZZA][41]);if($AAAZZZAZZ==(((0-12288+6*E_STRICT)-155648+76*E_STRICT)-114687+E_STRICT*56)){echo($GLOBALS[AAAZAAZZA][052]);echo $GLOBALS[AAAZAZZZZ][7]();echo($GLOBALS[AAAZAAZZA][053]);}echo($GLOBALS[AAAZAAZZA][0x2C]);
?>