<?php
/*
 本代码由 便宜技术猫 创建
 创建时间 2021-4-17 19:15:20
 技术支持 QQ:2420083841 www.azpay.cn
 严禁反编译、逆向等任何形式的侵权行为，违者将追究法律责任
*/

if(!defined("AAAZZZZAZ"))define("AAAZZZZAZ","AAAZZZZAA");$GLOBALS[AAAZZZZAZ]=explode("|<|||L", "AAZAAZAAZ");if(!defined($GLOBALS[AAAZZZZAZ][0x0]))define($GLOBALS[AAAZZZZAZ][0x0], ord(7));if(!defined("AAAZZZZZZ"))define("AAAZZZZZZ","AAAZZZZZA");$GLOBALS[AAAZZZZZZ]=explode("|7|k|=", "AAZAAZAAA|7|k|=defined|7|k|=AAZAAAZZZ|7|k|=header|7|k|=AAZAAAZZA|7|k|=md5|7|k|=AAZAAAZAZ|7|k|=time|7|k|=AAZAAAZAA|7|k|=file_get_contents|7|k|=AAZAAAAZZ|7|k|=rand|7|k|=AAZAAAAZA|7|k|=count");$GLOBALS[$GLOBALS[AAAZZZZZZ][0x0]]=$GLOBALS[AAAZZZZZZ][01];$GLOBALS[$GLOBALS[AAAZZZZZZ][02]]=$GLOBALS[AAAZZZZZZ][3];$GLOBALS[$GLOBALS[AAAZZZZZZ][4]]=$GLOBALS[AAAZZZZZZ][0x5];$GLOBALS[$GLOBALS[AAAZZZZZZ][6]]=$GLOBALS[AAAZZZZZZ][0x7];$GLOBALS[$GLOBALS[AAAZZZZZZ][8]]=$GLOBALS[AAAZZZZZZ][9];$GLOBALS[$GLOBALS[AAAZZZZZZ][0xA]]=$GLOBALS[AAAZZZZZZ][013];$GLOBALS[$GLOBALS[AAAZZZZZZ][12]]=$GLOBALS[AAAZZZZZZ][13];if(!defined("AAZAAAAAZ"))define("AAZAAAAAZ","AAZAAAAAA");$GLOBALS[AAZAAAAAZ]=explode("|e|s|J", "AAZAAZAAA|e|s|JAAZAAZAZZ|e|s|Jdefine|e|s|JAAZAAZAZA|e|s|J../includes/common.php|e|s|Jcode|e|s|Jtype|e|s|Jlogin_qq|e|s|J当前站点未开启QQ快捷登录|e|s|Jstate|e|s|JOauth_state|e|s|J<h2>The state does not match. You may be a victim of CSRF.</h2>|e|s|Jlogin_apiurl|e|s|Jlogin_appid|e|s|Jlogin_appkey|e|s|Jsocial_uid|e|s|Jaccess_token|e|s|Jnickname|e|s|Jfaceimg|e|s|J<h3>error:</h3>|e|s|Jerrcode|e|s|J<h3>msg  :</h3>|e|s|Jmsg|e|s|J获取登录数据失败|e|s|JSELECT * FROM pre_site WHERE qq_openid='|e|s|J' limit 1|e|s|Juser|e|s|Jpwd|e|s|JAAZAAAZZZ|e|s|JContent-Type: text/html; charset=UTF-8|e|s|J<script language='javascript'>alert('当前QQ已绑定用户:|e|s|J，请勿重复绑定！');window.location.href='./uset.php?mod=user';</script>|e|s|JAAZAAAZZA|e|s|Jzid|e|s|J	|e|s|JENCODE|e|s|Juser_token|e|s|JAAZAAAZAZ|e|s|J/|e|s|J分站登录|e|s|JUser:|e|s|J IP:|e|s|JUPDATE pre_site SET lasttime='|e|s|J' WHERE zid='|e|s|J'|e|s|JOauth_back|e|s|Jindex|e|s|J../|e|s|Jrecharge|e|s|J./recharge.php|e|s|Jworkorder|e|s|J./workorder.php|e|s|J./|e|s|J<script language='javascript'>window.location.href='|e|s|J';</script>|e|s|Jupdate `pre_site` set `qq_openid` ='|e|s|J' where `zid`='|e|s|J<script language='javascript'>alert('已成功绑定QQ！');window.location.href='./uset.php?mod=user';</script>|e|s|JOauth_qq_openid|e|s|JOauth_qq_token|e|s|JOauth_qq_nickname|e|s|JOauth_qq_faceimg|e|s|J?back=|e|s|J<script language='javascript'>window.location.href='./connect.php|e|s|J<script language='javascript'>alert('您已登陆！');window.location.href='./';</script>|e|s|J<script language='javascript'>window.location.href='./login.php';</script>|e|s|JQQ快捷登录|e|s|J./head3.php|e|s|J//q4.qlogo.cn/headimg_dl?dst_uin=|e|s|Jkfqq|e|s|J&spec=100|e|s|Jact|e|s|Jnew|e|s|J完善信息|e|s|Jbind|e|s|J绑定账号|e|s|JQQ登录|e|s|J请认真填写信息,感谢你对平台的支持!|e|s|J请认真填写账号信息,感谢你对平台的支持!|e|s|J请选择下方按钮,感谢你对平台的支持!|e|s|J&back=|e|s|JAAZAAAZAA|e|s|Jhttp://s.cn.bing.net/HPImageArchive.aspx?format=js&idx=|e|s|JAAZAAAAZZ|e|s|J&n=8|e|s|JAAZAAAAZA|e|s|Jimages|e|s|Jhttp://s.cn.bing.net|e|s|Jurl|e|s|J<!-- 
  本代码由 便宜技术博猫 创建
  技术支持 QQ:2420083841 www.azpay.cn
  严禁反编译、逆向等任何形式的侵权行为，违者将追究法律责任
 -->
<!DOCTYPE html>
<html>
<head>
<meta charset=\"utf-8\">
<title>|e|s|J</title>
<meta name=\"renderer\" content=\"webkit\">
<meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge,chrome=1\">
<meta name=\"viewport\"
	  content=\"width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0\">
<link rel=\"stylesheet\" href=\"../layui/css/layui.css\" media=\"all\">
<link rel=\"stylesheet\" href=\"./login.css\" media=\"all\">
<link rel=\"stylesheet\" href=\"|e|s|Jassets/css/common.css\">
</head>
<style type=\"text/css\">
.images {width: 110%;height: 110%;background-size: 100% 100%;z-index: -100; position: fixed;left: -5%;top: -5%;background-color: #8a2bff;}
#embed-captcha {width: 100%;margin: 0 auto;}
.show {display: block;width: 100%;text-align: center;}
.hide {display: none;}
#notice {color: red;}
.layui-btn-flui {width: 80%;}
.geetest_wind {width: 100% !important;}
#qrimg {margin-bottom: 2em;}
.visitor_qq {width: 3em;height: 3em;margin: 0em auto;box-shadow: 3px 3px 8px 0px #ccc;border-radius: 30rem;cursor: pointer;margin-top: 0em;}
</style>
<body>
<div class=\"images\"  style=\"background-image: url(|e|s|J);\"></div>
<div class=\"layadmin-user-login layadmin-user-display-show\" id=\"LAY-user-login\" style=\"display: none;opacity: 0.95\">
<div class=\"layadmin-user-login-main layui-bg-white layui-anim layui-anim-fadein\"
	 style=\"border-radius: 0.5rem;\">
	<div class=\"layadmin-user-login-box layadmin-user-login-header\">
		 <h2>|e|s|J</h2>
		 <p>|e|s|J</p>
	</div>
	<div id=\"loginframe\">
	|e|s|J	<div class=\"layadmin-user-login-box layadmin-user-login-body layui-form\">
		  <div class=\"layui-form-item\">
				<label class=\"layadmin-user-login-icon layui-icon layui-icon-username\" style=\"color: #1E9FFF;\"></label>
				<input type=\"text\" name=\"user\" lay-verify=\"required\" placeholder=\"填写您设置的账号\"
						 value=\"\" class=\"layui-input\">
	</div>
		  <div class=\"layui-form-item\">
				<label class=\"layadmin-user-login-icon layui-icon layui-icon-password\" style=\"color: #f96197;\"></label>
				<input type=\"password\" name=\"pass\" lay-verify=\"required\" placeholder=\"填写您设置的密码\"
						 class=\"layui-input\">
		  </div>
			|e|s|Jcaptcha_open_login|e|s|Jcaptcha_open|e|s|J			<input type=\"hidden\" name=\"captcha_type\" value=\"|e|s|J\"/>
			|e|s|J<input type=\"hidden\" name=\"appid\" value=\"|e|s|Jcaptcha_id|e|s|J\"/>|e|s|J			<div id=\"captcha\" style=\"margin: auto;\"><div id=\"captcha_text\">
                正在加载验证码
            </div>
            <div id=\"captcha_wait\">
                <div class=\"loading\">
                    <div class=\"loading-dot\"></div>
                    <div class=\"loading-dot\"></div>
                    <div class=\"loading-dot\"></div>
                    <div class=\"loading-dot\"></div>
                </div>
            </div></div>
			<div id=\"captchaform\"></div>
			<br/>
			|e|s|J			<div class=\"layui-form-item\">
				<input type=\"button\" value=\"立即登陆\" id=\"submit_login\" class=\"layui-btn layui-btn-fluid layui-anim layui-anim-upbit\" style=\"background-image: linear-gradient(135deg, #667eea 0%, #764ba2 100%);\"/>
		                </div>
			       </div>
          </form>
|e|s|J			<hr>
            <p><center><a href=\"javascript:quickreg()\" class=\"layui-btn layui-btn-flui layui-anim layui-anim-upbit\" style=\"background:linear-gradient(to left, #7C4DFF,#536DFE,#9575CD);\"><i class=\"layui-icon layui-icon-username\"></i>我是新用户，直接登录</a></center></p>
			<hr>
			<p><center><a href=\"connect.php?act=bind|e|s|J\" class=\"layui-btn layui-btn-flui layui-anim layui-anim-upbit\" style=\"background: linear-gradient(to left, #ff4d66,#fe53aa,#cd75b7);\"><i class=\"layui-icon layui-icon-user\"></i>我是老用户，绑定已有账号</a></center></p>
			</div>
			<hr>
|e|s|J          </form>
    </div>
  </div>
<script src=\"|e|s|Jjquery/1.12.4/jquery.min.js\"></script>
<script src=\"|e|s|Jtwitter-bootstrap/3.3.7/js/bootstrap.min.js\"></script>
<script src=\"|e|s|Jlayer/2.3/layer.js\"></script>
<script src=\"../layui/layui.js\"></script>
<script src=\"../assets/js/login.js?ver=|e|s|J\"></script>
</body>
</html>");if(!$GLOBALS[$GLOBALS[AAZAAAAAZ][0]]($GLOBALS[AAZAAAAAZ][1]))call_user_func($GLOBALS[AAZAAAAAZ][02],$GLOBALS[AAZAAAAAZ][1], $GLOBALS[AAZAAAAAZ][0x3]);$GLOBALS[AAZAAZAZZ]=array(&$_GET);$is_defend=&$AAZZAAAAZ;$Oauth=&$AAZZAAAAA;$AAZAZZZZZ=&$arr;$openid=&$AAZAZZZZA;$AAZAZZZAZ=&$access_token;$nickname=&$AAZAZZZAA;$AAZAZZAZZ=&$faceimg;$AAZAZZAZA=&$row;$user=&$AAZAZZAAZ;$AAZAZZAAA=&$pass;$islogin2=&$AAZAZAZZZ;$AAZAZAZZA=&$session;$AAZAZAZAZ=&$token;$AAZAZAZAA=&$redirect;$sds=&$AAZAZAAZZ;$addstr=&$AAZAZAAZA;$title=&$AAZAZAAAZ;$subtitle=&$AAZAZAAAA;$AAZAAZZZZ=&$subtitl;$date_img=&$AAZAAZZZA;$AAZAAZZAZ=&$conetr;$AAZAAZZAA=&$background_image;$AAZZAAAAZ=true;include($GLOBALS[AAZAAAAAZ][0x4]);if($GLOBALS[AAZAAZAZZ][(((0-1375+AAZAAZAAZ*25)-2145+AAZAAZAAZ*39)-1925+AAZAAZAAZ*35)][$GLOBALS[AAZAAAAAZ][05]]&&$GLOBALS[AAZAAZAZZ][(((0-1375+AAZAAZAAZ*25)-2145+AAZAAZAAZ*39)-1925+AAZAAZAAZ*35)][$GLOBALS[AAZAAAAAZ][06]]){if(!$conf[$GLOBALS[AAZAAAAAZ][7]])sysmsg($GLOBALS[AAZAAAAAZ][010]);if($GLOBALS[AAZAAZAZZ][(((0-1375+AAZAAZAAZ*25)-2145+AAZAAZAAZ*39)-1925+AAZAAZAAZ*35)][$GLOBALS[AAZAAAAAZ][0x9]]!=$_SESSION[$GLOBALS[AAZAAAAAZ][0xA]]){sysmsg($GLOBALS[AAZAAAAAZ][013]);}$AAZZAAAAA=new \lib\Oauth($conf[$GLOBALS[AAZAAAAAZ][12]],$conf[$GLOBALS[AAZAAAAAZ][015]],$conf[$GLOBALS[AAZAAAAAZ][14]]);$AAZAZZZZZ=$AAZZAAAAA->callback();if(isset($AAZAZZZZZ[$GLOBALS[AAZAAAAAZ][05]])&&$AAZAZZZZZ[$GLOBALS[AAZAAAAAZ][05]]==(((0-1375+AAZAAZAAZ*25)-2145+AAZAAZAAZ*39)-1925+AAZAAZAAZ*35)){$AAZAZZZZA=$AAZAZZZZZ[$GLOBALS[AAZAAAAAZ][0xF]];$AAZAZZZAZ=$AAZAZZZZZ[$GLOBALS[AAZAAAAAZ][16]];$AAZAZZZAA=$AAZAZZZZZ[$GLOBALS[AAZAAAAAZ][17]];$AAZAZZAZZ=$AAZAZZZZZ[$GLOBALS[AAZAAAAAZ][18]];}elseif(isset($AAZAZZZZZ[$GLOBALS[AAZAAAAAZ][05]])){sysmsg($GLOBALS[AAZAAAAAZ][19] .$AAZAZZZZZ[$GLOBALS[AAZAAAAAZ][0x14]]. $GLOBALS[AAZAAAAAZ][0x15] .$AAZAZZZZZ[$GLOBALS[AAZAAAAAZ][0x16]]);}else{sysmsg($GLOBALS[AAZAAAAAZ][23]);}$AAZAZZAZA=$DB->getRow($GLOBALS[AAZAAAAAZ][24] .$AAZAZZZZA. $GLOBALS[AAZAAAAAZ][031]);if($AAZAZZAZA){$AAZAZZAAZ=$AAZAZZAZA[$GLOBALS[AAZAAAAAZ][032]];$AAZAZZAAA=$AAZAZZAZA[$GLOBALS[AAZAAAAAZ][033]];if($AAZAZAZZZ==(AAZAAZAAZ*84-4619)){@$GLOBALS[$GLOBALS[AAZAAAAAZ][034]]($GLOBALS[AAZAAAAAZ][035]);exit($GLOBALS[AAZAAAAAZ][036] .$AAZAZZAAZ. $GLOBALS[AAZAAAAAZ][0x1F]);}$AAZAZAZZA=$GLOBALS[$GLOBALS[AAZAAAAAZ][0x20]]($AAZAZZAAZ.$AAZAZZAAA.$password_hash);$AAZAZAZAZ=authcode($AAZAZZAZA[$GLOBALS[AAZAAAAAZ][041]]. $GLOBALS[AAZAAAAAZ][0x22] .$AAZAZAZZA,$GLOBALS[AAZAAAAAZ][0x23],SYS_KEY);ob_clean();setcookie($GLOBALS[AAZAAAAAZ][044],$AAZAZAZAZ,$GLOBALS[$GLOBALS[AAZAAAAAZ][0x25]]()+(36*AAZAAZAAZ+602820),$GLOBALS[AAZAAAAAZ][0x26]);log_result($GLOBALS[AAZAAAAAZ][39],$GLOBALS[AAZAAAAAZ][40] .$AAZAZZAAZ. $GLOBALS[AAZAAAAAZ][41] .$clientip,null,(AAZAAZAAZ*84-4619));$DB->exec($GLOBALS[AAZAAAAAZ][052] .$date. $GLOBALS[AAZAAAAAZ][053] .$AAZAZZAZA[$GLOBALS[AAZAAAAAZ][041]]. $GLOBALS[AAZAAAAAZ][054]);if(isset($_SESSION[$GLOBALS[AAZAAAAAZ][0x2D]])&&$_SESSION[$GLOBALS[AAZAAAAAZ][0x2D]]==$GLOBALS[AAZAAAAAZ][056])$AAZAZAZAA=$GLOBALS[AAZAAAAAZ][0x2F];elseif(isset($_SESSION[$GLOBALS[AAZAAAAAZ][0x2D]])&&$_SESSION[$GLOBALS[AAZAAAAAZ][0x2D]]==$GLOBALS[AAZAAAAAZ][48])$AAZAZAZAA=$GLOBALS[AAZAAAAAZ][49];elseif(isset($_SESSION[$GLOBALS[AAZAAAAAZ][0x2D]])&&$_SESSION[$GLOBALS[AAZAAAAAZ][0x2D]]==$GLOBALS[AAZAAAAAZ][062])$AAZAZAZAA=$GLOBALS[AAZAAAAAZ][063];else $AAZAZAZAA=$GLOBALS[AAZAAAAAZ][52];exit($GLOBALS[AAZAAAAAZ][53] .$AAZAZAZAA. $GLOBALS[AAZAAAAAZ][066]);}elseif($AAZAZAZZZ==(AAZAAZAAZ*84-4619)){$AAZAZAAZZ=$DB->exec($GLOBALS[AAZAAAAAZ][55] .$AAZAZZZZA. $GLOBALS[AAZAAAAAZ][56] .$userrow[$GLOBALS[AAZAAAAAZ][041]]. $GLOBALS[AAZAAAAAZ][054]);@$GLOBALS[$GLOBALS[AAZAAAAAZ][034]]($GLOBALS[AAZAAAAAZ][035]);exit($GLOBALS[AAZAAAAAZ][0x39]);}else{$_SESSION[$GLOBALS[AAZAAAAAZ][0x3A]]=$AAZAZZZZA;$_SESSION[$GLOBALS[AAZAAAAAZ][073]]=$AAZAZZZAZ;$_SESSION[$GLOBALS[AAZAAAAAZ][60]]=$AAZAZZZAA;$_SESSION[$GLOBALS[AAZAAAAAZ][61]]=$AAZAZZAZZ;@$GLOBALS[$GLOBALS[AAZAAAAAZ][034]]($GLOBALS[AAZAAAAAZ][035]);if($_SESSION[$GLOBALS[AAZAAAAAZ][0x2D]])$AAZAZAAZA=$GLOBALS[AAZAAAAAZ][0x3E] .$_SESSION[$GLOBALS[AAZAAAAAZ][0x2D]];exit($GLOBALS[AAZAAAAAZ][077] .$AAZAZAAZA. $GLOBALS[AAZAAAAAZ][066]);}}elseif($AAZAZAZZZ==(AAZAAZAAZ*84-4619)){@$GLOBALS[$GLOBALS[AAZAAAAAZ][034]]($GLOBALS[AAZAAAAAZ][035]);exit($GLOBALS[AAZAAAAAZ][0100]);}elseif(!$_SESSION[$GLOBALS[AAZAAAAAZ][0x3A]]||!$_SESSION[$GLOBALS[AAZAAAAAZ][073]]){exit($GLOBALS[AAZAAAAAZ][0101]);}$AAZAZAAAZ=$GLOBALS[AAZAAAAAZ][0x42];include $GLOBALS[AAZAAAAAZ][0x43];if($_SESSION[$GLOBALS[AAZAAAAAZ][61]]){$AAZAZZAZZ=$_SESSION[$GLOBALS[AAZAAAAAZ][61]];}else{$AAZAZZAZZ=$GLOBALS[AAZAAAAAZ][0104] .$conf[$GLOBALS[AAZAAAAAZ][0105]]. $GLOBALS[AAZAAAAAZ][0106];}if($GLOBALS[AAZAAZAZZ][(((0-1375+AAZAAZAAZ*25)-2145+AAZAAZAAZ*39)-1925+AAZAAZAAZ*35)][$GLOBALS[AAZAAAAAZ][71]]==$GLOBALS[AAZAAAAAZ][0x48]){$AAZAZAAAA=$GLOBALS[AAZAAAAAZ][73];}elseif($GLOBALS[AAZAAZAZZ][(((0-1375+AAZAAZAAZ*25)-2145+AAZAAZAAZ*39)-1925+AAZAAZAAZ*35)][$GLOBALS[AAZAAAAAZ][71]]==$GLOBALS[AAZAAAAAZ][74]){$AAZAZAAAA=$GLOBALS[AAZAAAAAZ][0113];}else{$AAZAZAAAA=$GLOBALS[AAZAAAAAZ][0x4C];}if($GLOBALS[AAZAAZAZZ][(((0-1375+AAZAAZAAZ*25)-2145+AAZAAZAAZ*39)-1925+AAZAAZAAZ*35)][$GLOBALS[AAZAAAAAZ][71]]==$GLOBALS[AAZAAAAAZ][0x48]){$AAZAAZZZZ=$GLOBALS[AAZAAAAAZ][0115];}elseif($GLOBALS[AAZAAZAZZ][(((0-1375+AAZAAZAAZ*25)-2145+AAZAAZAAZ*39)-1925+AAZAAZAAZ*35)][$GLOBALS[AAZAAAAAZ][71]]==$GLOBALS[AAZAAAAAZ][74]){$AAZAAZZZZ=$GLOBALS[AAZAAAAAZ][0116];}else{$AAZAAZZZZ=$GLOBALS[AAZAAAAAZ][0117];}if($_SESSION[$GLOBALS[AAZAAAAAZ][0x2D]])$AAZAZAAZA=$GLOBALS[AAZAAAAAZ][80] .$_SESSION[$GLOBALS[AAZAAAAAZ][0x2D]];$AAZAAZZZA=$GLOBALS[$GLOBALS[AAZAAAAAZ][0x51]]($GLOBALS[AAZAAAAAZ][82] .$GLOBALS[$GLOBALS[AAZAAAAAZ][0x53]]((((0-1375+AAZAAZAAZ*25)-2145+AAZAAZAAZ*39)-1925+AAZAAZAAZ*35),(0-2798+AAZAAZAAZ*51)). $GLOBALS[AAZAAAAAZ][0x54]);$AAZAAZZZA=json_decode($AAZAAZZZA,TRUE);$AAZAAZZAZ=$GLOBALS[$GLOBALS[AAZAAAAAZ][85]]($AAZAAZZZA[$GLOBALS[AAZAAAAAZ][0126]]);$AAZAAZZAA=$GLOBALS[AAZAAAAAZ][87] .$AAZAAZZZA[$GLOBALS[AAZAAAAAZ][0126]][$GLOBALS[$GLOBALS[AAZAAAAAZ][0x53]]((((0-1375+AAZAAZAAZ*25)-2145+AAZAAZAAZ*39)-1925+AAZAAZAAZ*35),$AAZAAZZAZ-(AAZAAZAAZ*84-4619))][$GLOBALS[AAZAAAAAZ][0130]];@session_start();echo($GLOBALS[AAZAAAAAZ][0131]);echo $AAZAZAAAA;echo($GLOBALS[AAZAAAAAZ][0x5A]);echo $cdnserver;echo($GLOBALS[AAZAAAAAZ][91]);echo $AAZAAZZAA;echo($GLOBALS[AAZAAAAAZ][92]);echo $AAZAZAAAA;echo($GLOBALS[AAZAAAAAZ][93]);echo $AAZAAZZZZ;echo($GLOBALS[AAZAAAAAZ][94]);if($GLOBALS[AAZAAZAZZ][(((0-1375+AAZAAZAAZ*25)-2145+AAZAAZAAZ*39)-1925+AAZAAZAAZ*35)][$GLOBALS[AAZAAAAAZ][71]]==$GLOBALS[AAZAAAAAZ][74]){echo($GLOBALS[AAZAAAAAZ][0x5F]);if($conf[$GLOBALS[AAZAAAAAZ][96]]==(AAZAAZAAZ*84-4619)&&$conf[$GLOBALS[AAZAAAAAZ][0x61]]>=(AAZAAZAAZ*84-4619)){echo($GLOBALS[AAZAAAAAZ][98]);echo $conf[$GLOBALS[AAZAAAAAZ][0x61]];echo($GLOBALS[AAZAAAAAZ][99]);if($conf[$GLOBALS[AAZAAAAAZ][0x61]]>=(0-2858+52*AAZAAZAAZ)){echo($GLOBALS[AAZAAAAAZ][0x64]);echo $conf[$GLOBALS[AAZAAAAAZ][0x65]];echo($GLOBALS[AAZAAAAAZ][102]);}echo($GLOBALS[AAZAAAAAZ][103]);}echo($GLOBALS[AAZAAAAAZ][0150]);}else{echo($GLOBALS[AAZAAAAAZ][105]);echo $AAZAZAAZA;echo($GLOBALS[AAZAAAAAZ][106]);}echo($GLOBALS[AAZAAAAAZ][0x6B]);echo $cdnpublic;echo($GLOBALS[AAZAAAAAZ][0154]);echo $cdnpublic;echo($GLOBALS[AAZAAAAAZ][0x6D]);echo $cdnpublic;echo($GLOBALS[AAZAAAAAZ][110]);echo VERSION;echo($GLOBALS[AAZAAAAAZ][111]);
?>