<?php
/*
 �������� ���˼���è ����
 ����ʱ�� 2021-4-17 19:15:20
 ����֧�� QQ:2420083841 www.azpay.cn
 �Ͻ������롢������κ���ʽ����Ȩ��Ϊ��Υ�߽�׷����������
*/

if(!defined("AZZZAZZZZ"))define("AZZZAZZZZ","AZZZAZZZA");$GLOBALS[AZZZAZZZZ]=explode("|e|e|k", "AZZZZAZAZ");if(!defined("AZZZZAAZZ"))define("AZZZZAAZZ","AZZZZAAZA");$GLOBALS[AZZZZAAZZ]=explode("|9|P|3", "AZZZZAZAA|9|P|3header|9|P|3cdnpublic|9|P|3//lib.baomitu.com/|9|P|3//cdn.bootcss.com/|9|P|3//s1.pstatp.com/cdn/expire-1-M/|9|P|3//cdn.staticfile.org/|9|P|3staticurl|9|P|3//|9|P|3/|9|P|3../|9|P|3Content-Type: text/html; charset=UTF-8");if(!defined($GLOBALS[AZZZAZZZZ][00]))define($GLOBALS[AZZZAZZZZ][00], ord(7));$GLOBALS[$GLOBALS[AZZZZAAZZ][0]]=$GLOBALS[AZZZZAAZZ][1];$cdnpublic=&$AZZZZAZZZ;$AZZZZAZZA=&$cdnserver;if($conf[$GLOBALS[AZZZZAAZZ][02]]==(AZZZZAZAZ*53-2914)){$AZZZZAZZZ=$GLOBALS[AZZZZAAZZ][03];}elseif($conf[$GLOBALS[AZZZZAAZZ][02]]==(93*AZZZZAZAZ-5113)){$AZZZZAZZZ=$GLOBALS[AZZZZAAZZ][04];}elseif($conf[$GLOBALS[AZZZZAAZZ][02]]==(0-3131+AZZZZAZAZ*57)){$AZZZZAZZZ=$GLOBALS[AZZZZAAZZ][5];}else{$AZZZZAZZZ=$GLOBALS[AZZZZAAZZ][6];}if(!empty($conf[$GLOBALS[AZZZZAAZZ][07]])){$AZZZZAZZA=$GLOBALS[AZZZZAAZZ][8] .$conf[$GLOBALS[AZZZZAAZZ][07]]. $GLOBALS[AZZZZAAZZ][011];}else{$AZZZZAZZA=$GLOBALS[AZZZZAAZZ][10];}list($background_image,$background_css)=\lib\Template::getBackground($GLOBALS[AZZZZAAZZ][10]);@$GLOBALS[$GLOBALS[AZZZZAAZZ][0]]($GLOBALS[AZZZZAAZZ][0xB]);
?>