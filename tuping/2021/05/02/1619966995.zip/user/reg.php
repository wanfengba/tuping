<?php
/*
 本代码由 便宜技术猫 创建
 创建时间 2021-4-17 19:15:20
 技术支持 QQ:2420083841 www.azpay.cn
 严禁反编译、逆向等任何形式的侵权行为，违者将追究法律责任
*/

if(!defined("AAZZZZAAA"))define("AAZZZZAAA","AAZZZAZZZ");$GLOBALS[AAZZZZAAA]=explode("|/|||P", "AZAAAAZAZ");if(!defined("AAZZZZZAA"))define("AAZZZZZAA","AAZZZZAZZ");$GLOBALS[AAZZZZZAA]=explode("|1|7|9", "AZAAAAZAA|1|7|9header|1|7|9AZAAAAAZZ|1|7|9AZAAAAAZA|1|7|9md5|1|7|9AZAAAAAAZ|1|7|9mt_rand|1|7|9AZAAAAAAA|1|7|9time|1|7|9AAZZZZZZZ|1|7|9file_get_contents|1|7|9AAZZZZZZA|1|7|9rand|1|7|9AAZZZZZAZ|1|7|9count|1|7|9../includes/common.php|1|7|9Content-Type: text/html; charset=UTF-8|1|7|9<script language='javascript'>alert('您已登陆！');window.location.href='./';</script>|1|7|9user_open|1|7|9fenzhan_buy|1|7|9<script language='javascript'>window.location.href='./regsite.php';</script>|1|7|9<script language='javascript'>alert('未开放新用户注册');window.location.href='./';</script>|1|7|9用户注册|1|7|9./head3.php|1|7|9addsalt|1|7|9http://s.cn.bing.net/HPImageArchive.aspx?format=js&idx=|1|7|9&n=8|1|7|9images|1|7|9http://s.cn.bing.net|1|7|9url|1|7|9<!-- 
  本代码由 便宜技术博猫 创建
  技术支持 QQ:2420083841 www.azpay.cn
  严禁反编译、逆向等任何形式的侵权行为，违者将追究法律责任
 -->
<!DOCTYPE html>
<html>
<head>
<meta charset=\"utf-8\">
<title>用户注册</title>
<meta name=\"renderer\" content=\"webkit\">
<meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge,chrome=1\">
<meta name=\"viewport\"
      content=\"width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0\">
<link rel=\"stylesheet\" href=\"../layui/css/layui.css\" media=\"all\">
<link rel=\"stylesheet\" href=\"./login.css\" media=\"all\">
</head>
<style type=\"text/css\">
.images {width: 110%;height: 110%;background-size: 100% 100%;z-index: -100; position: fixed;left: -5%;top: -5%;background-color: #8a2bff;}
#embed-captcha {width: 100%;margin: 0 auto;}
.show {display: block;width: 100%;text-align: center;}
.hide {display: none;}
#notice {color: red;}
.geetest_wind {width: 100% !important;}
#qrimg {margin-bottom: 2em;}
.layadmin-user-login {position: relative;left: 0;top: 0;padding: 20px 0;min-height: 100%;box-sizing: border-box;}
.visitor_qq {width: 3em;height: 3em;margin: 0em auto;box-shadow: 3px 3px 8px 0px #ccc;border-radius: 30rem;cursor: pointer;margin-top: 0em;}
    </style>
    <body>
    <div class=\"images\"  style=\"background-image: url(|1|7|9);\"></div>
    <div class=\"layadmin-user-login layadmin-user-display-show\" id=\"LAY-user-login\" style=\"display: none;opacity: 0.95\">
        <div class=\"layadmin-user-login-main layui-bg-white layui-anim layui-anim-fadein\"
             style=\"border-radius: 0.5rem;\">
            <div class=\"layadmin-user-login-box layadmin-user-login-header\">
                <h2>用户注册</h2>
                <p>用户注册界面,请认真填写信息！</p>
            </div>
                            <div class=\"layadmin-user-login-box layadmin-user-login-body layui-form\">
						    <input type=\"hidden\" name=\"captcha_type\" value=\"|1|7|9captcha_open|1|7|9\"/>
                    <div class=\"layui-form-item\">
                        <label class=\"layadmin-user-login-icon layui-icon layui-icon-username\" style=\"color: #1E9FFF;\"></label>
                        <input type=\"text\" name=\"user\" lay-verify=\"required\" placeholder=\"输入登录用户名\"
                               value=\"\" class=\"layui-input\">
					</div>
                    <div class=\"layui-form-item\">
                        <label class=\"layadmin-user-login-icon layui-icon layui-icon-password\" style=\"color: #f96197;\"></label>
                        <input type=\"text\" name=\"pwd\" lay-verify=\"required\" placeholder=\"输入6位以上密码\"
                               class=\"layui-input\">
                    </div>
					<div class=\"layui-form-item\">
					    <label class=\"layadmin-user-login-icon layui-icon layui-icon-login-qq\" style=\"color: #ff9a1e;\"></label>
					    <input type=\"text\" name=\"qq\" lay-verify=\"required\" placeholder=\"输入QQ号，用于找回密码\"
					           class=\"layui-input\">
					</div>
			|1|7|9			|1|7|9<input type=\"hidden\" name=\"appid\" value=\"|1|7|9captcha_id|1|7|9\"/>|1|7|9			<div id=\"captcha\" style=\"margin: auto;\"><div id=\"captcha_text\">
                正在加载验证码
            </div>
            <div id=\"captcha_wait\">
                <div class=\"loading\">
                    <div class=\"loading-dot\"></div>
                    <div class=\"loading-dot\"></div>
                    <div class=\"loading-dot\"></div>
                    <div class=\"loading-dot\"></div>
                </div>
            </div></div>
			<div id=\"captchaform\"></div>
			<br/>
			|1|7|9			  <div class=\"layui-form-item\">
                    <div class=\"layui-row\">
                        <div class=\"layui-col-xs8\">
                            <label class=\"layadmin-user-login-icon layui-icon layui-icon-vercode\" style=\"color: #0abb69;\"></label>
              <input type=\"text\" name=\"code\" class=\"layui-input\" lay-verify=\"required\" placeholder=\"输入验证码\"/>
                        </div>
                        <div class=\"layui-col-xs4\">
                             <img src=\"./code.php?r=|1|7|9\" class=\"layadmin-user-login-codeimg\" id=\"codeimg\" onclick=\"this.src='./code.php?r='+Math.random();\" title=\"点击更换验证码\">
                        </div>
                    </div>
                </div>
			|1|7|9                    <div class=\"layui-form-item\">
                        <input type=\"button\" value=\"立即注册\" id=\"submit_reg\" class=\"layui-btn layui-btn-fluid layui-anim layui-anim-upbit\" style=\"background-image: linear-gradient(135deg, #667eea 0%, #764ba2 100%);\"/>
                    </div>
                    <div class=\"layui-trans layui-form-item layadmin-user-login-other\">
                        <label>社交账号登入</label>
                        <a id=\"qq\"><i class=\"layui-icon layui-icon-login-qq\"></i></a>
                                                    <a href=\"../\" class=\"layadmin-user-jump-change layadmin-link\">返回登录</a>
                                                    <a href=\"./findpwd.php\" class=\"layadmin-user-jump-change layadmin-link\">找回密码</a>
                     </div>
<script src=\"|1|7|9jquery/1.12.4/jquery.min.js\"></script>
<script src=\"|1|7|9twitter-bootstrap/3.3.7/js/bootstrap.min.js\"></script>
<script src=\"|1|7|9layer/2.3/layer.js\"></script>
<script>
var hashsalt=|1|7|9;
</script><script>
\$(\"#qq\").click(function () {
    layer.msg('暂未开放 感谢你的支持', {icon: 1})
})
\$(\"#wx\").click(function () {
    layer.msg('暂未开放 感谢你的支持')
})
</script>
<script src=\"../assets/js/reguser.js?ver=|1|7|9\"></script>
</body>
</html>");if(!defined($GLOBALS[AAZZZZAAA][0]))define($GLOBALS[AAZZZZAAA][0], ord(4));$GLOBALS[$GLOBALS[AAZZZZZAA][00]]=$GLOBALS[AAZZZZZAA][01];$GLOBALS[$GLOBALS[AAZZZZZAA][2]]=$GLOBALS[AAZZZZZAA][01];$GLOBALS[$GLOBALS[AAZZZZZAA][3]]=$GLOBALS[AAZZZZZAA][04];$GLOBALS[$GLOBALS[AAZZZZZAA][0x5]]=$GLOBALS[AAZZZZZAA][06];$GLOBALS[$GLOBALS[AAZZZZZAA][7]]=$GLOBALS[AAZZZZZAA][010];$GLOBALS[$GLOBALS[AAZZZZZAA][0x9]]=$GLOBALS[AAZZZZZAA][0xA];$GLOBALS[$GLOBALS[AAZZZZZAA][013]]=$GLOBALS[AAZZZZZAA][0xC];$GLOBALS[$GLOBALS[AAZZZZZAA][015]]=$GLOBALS[AAZZZZZAA][016];$is_defend=&$AZAAAZZZA;$islogin2=&$AZAAAZZAZ;$title=&$AZAAAZZAA;$addsalt=&$AZAAAZAZZ;$x=&$AZAAAZAZA;$AZAAAZAAZ=&$addsalt_js;$AZAAAZAAA=&$date_img;$AZAAAAZZZ=&$conetr;$AZAAAAZZA=&$background_image;$AZAAAZZZA=true;include($GLOBALS[AAZZZZZAA][15]);if($AZAAAZZAZ==((0-572+AZAAAAZAZ*11)-2963+AZAAAAZAZ*57)){@$GLOBALS[$GLOBALS[AAZZZZZAA][00]]($GLOBALS[AAZZZZZAA][16]);exit($GLOBALS[AAZZZZZAA][021]);}if(!$conf[$GLOBALS[AAZZZZZAA][18]]&&$conf[$GLOBALS[AAZZZZZAA][0x13]]==((0-572+AZAAAAZAZ*11)-2963+AZAAAAZAZ*57)){exit($GLOBALS[AAZZZZZAA][0x14]);}elseif(!$conf[$GLOBALS[AAZZZZZAA][18]]){@$GLOBALS[$GLOBALS[AAZZZZZAA][00]]($GLOBALS[AAZZZZZAA][16]);exit($GLOBALS[AAZZZZZAA][0x15]);}$AZAAAZZAA=$GLOBALS[AAZZZZZAA][22];include $GLOBALS[AAZZZZZAA][23];$AZAAAZAZZ=$GLOBALS[$GLOBALS[AAZZZZZAA][3]]($GLOBALS[$GLOBALS[AAZZZZZAA][0x5]]((0-572+AZAAAAZAZ*11),(58*AZAAAAZAZ-2017)).$GLOBALS[$GLOBALS[AAZZZZZAA][7]]());$_SESSION[$GLOBALS[AAZZZZZAA][24]]=$AZAAAZAZZ;$AZAAAZAZA=new \lib\hieroglyphy();$AZAAAZAAZ=$AZAAAZAZA->hieroglyphyString($AZAAAZAZZ);$AZAAAZAAA=$GLOBALS[$GLOBALS[AAZZZZZAA][0x9]]($GLOBALS[AAZZZZZAA][031] .$GLOBALS[$GLOBALS[AAZZZZZAA][013]]((0-572+AZAAAAZAZ*11),(0-825+AZAAAAZAZ*16)). $GLOBALS[AAZZZZZAA][26]);$AZAAAZAAA=json_decode($AZAAAZAAA,TRUE);$AZAAAAZZZ=$GLOBALS[$GLOBALS[AAZZZZZAA][015]]($AZAAAZAAA[$GLOBALS[AAZZZZZAA][27]]);$AZAAAAZZA=$GLOBALS[AAZZZZZAA][034] .$AZAAAZAAA[$GLOBALS[AAZZZZZAA][27]][$GLOBALS[$GLOBALS[AAZZZZZAA][013]]((0-572+AZAAAAZAZ*11),$AZAAAAZZZ-((0-572+AZAAAAZAZ*11)-2963+AZAAAAZAZ*57))][$GLOBALS[AAZZZZZAA][035]];@session_start();echo($GLOBALS[AAZZZZZAA][036]);echo $AZAAAAZZA;echo($GLOBALS[AAZZZZZAA][0x1F]);echo $conf[$GLOBALS[AAZZZZZAA][0x20]];echo($GLOBALS[AAZZZZZAA][33]);if($conf[$GLOBALS[AAZZZZZAA][0x20]]>=((0-572+AZAAAAZAZ*11)-2963+AZAAAAZAZ*57)){echo($GLOBALS[AAZZZZZAA][042]);if($conf[$GLOBALS[AAZZZZZAA][0x20]]>=(0-362+AZAAAAZAZ*7)){echo($GLOBALS[AAZZZZZAA][35]);echo $conf[$GLOBALS[AAZZZZZAA][0x24]];echo($GLOBALS[AAZZZZZAA][045]);}echo($GLOBALS[AAZZZZZAA][046]);}else{echo($GLOBALS[AAZZZZZAA][0x27]);echo $GLOBALS[$GLOBALS[AAZZZZZAA][7]]();echo($GLOBALS[AAZZZZZAA][40]);}echo($GLOBALS[AAZZZZZAA][0x29]);echo $cdnpublic;echo($GLOBALS[AAZZZZZAA][052]);echo $cdnpublic;echo($GLOBALS[AAZZZZZAA][43]);echo $cdnpublic;echo($GLOBALS[AAZZZZZAA][054]);echo $AZAAAZAAZ;echo($GLOBALS[AAZZZZZAA][45]);echo VERSION;echo($GLOBALS[AAZZZZZAA][0x2E]);
?>