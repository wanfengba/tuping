<?php
/*
 本代码由 便宜技术猫 创建
 创建时间 2021-4-17 19:15:20
 技术支持 QQ:2420083841 www.azpay.cn
 严禁反编译、逆向等任何形式的侵权行为，违者将追究法律责任
*/

if(!defined("AZZAAZZZA"))define("AZZAAZZZA","AZZAAZZAZ");$GLOBALS[AZZAAZZZA]=explode("|*|Z|_", "AZZAZZZZA");if(!defined("AZZAZAAAA"))define("AZZAZAAAA","AZZAAZZZZ");$GLOBALS[AZZAZAAAA]=explode("|f|%|&", "AZZAZZZAZ|f|%|&AZZAZZZAA|f|%|&|5|>|6|f|%|&|5|>|6defined|5|>|6header|5|>|6md5|5|>|6mt_rand|5|>|6time|5|>|6explode|5|>|6file_get_contents|5|>|6rand|5|>|6count");if(!defined("AZZAZAAZA"))define("AZZAZAAZA","AZZAZAAAZ");$GLOBALS[AZZAZAAZA]=explode("|.|]|e", "AZZZAAAAA|.|]|edefine|.|]|eAZZAZZZZZ|.|]|e../includes/common.php|.|]|epower|.|]|eContent-Type: text/html; charset=UTF-8|.|]|e<script language='javascript'>alert('您已开通过分站！');window.location.href='./';</script>|.|]|efenzhan_buy|.|]|e<script language='javascript'>alert('当前站点未开启自助开通分站功能！');window.location.href='./';</script>|.|]|ektfz_price|.|]|efenzhan_price|.|]|efenzhan_cost2|.|]|efenzhan_price2|.|]|ektfz_price2|.|]|e自助开通分站|.|]|e./head3.php|.|]|eaddsalt|.|]|ekind|.|]|ektfz_domain|.|]|e,|.|]|efenzhan_domain|.|]|e|.|]|e<option value=\"|.|]|e\">|.|]|e</option>|.|]|e请先到后台分站设置，填写可选分站域名|.|]|ehttp://s.cn.bing.net/HPImageArchive.aspx?format=js&idx=|.|]|e&n=8|.|]|eimages|.|]|ehttp://s.cn.bing.net|.|]|eurl|.|]|e<!-- 
  本代码由 便宜技术博猫 创建
  技术支持 QQ:2420083841 www.azpay.cn
  严禁反编译、逆向等任何形式的侵权行为，违者将追究法律责任
 -->
<!DOCTYPE html>
<html>
<head>
<meta charset=\"utf-8\">
<title>自助开通分站</title>
<meta name=\"renderer\" content=\"webkit\">
<meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge,chrome=1\">
<meta name=\"viewport\"
	  content=\"width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0\">
<link rel=\"stylesheet\" href=\"../layui/css/layuio.css\" media=\"all\">
<link rel=\"stylesheet\" href=\"./login.css\" media=\"all\">
</head>
<style type=\"text/css\">
.images {width: 110%;height: 110%;background-size: 100% 100%;z-index: -100; position: fixed;left: -5%;top: -5%;background-color: #8a2bff;}
#embed-captcha {width: 100%;margin: 0 auto;}
.show {display: block;width: 100%;text-align: center;}
.hide {display: none;}
#notice {color: red;}
.geetest_wind {width: 100% !important;}
#qrimg {margin-bottom: 2em;}
.layadmin-user-login {position: relative;left: 0;top: 0;padding: 20px 0;min-height: 100%;box-sizing: border-box;}
.visitor_qq {width: 3em;height: 3em;margin: 0em auto;box-shadow: 3px 3px 8px 0px #ccc;border-radius: 30rem;cursor: pointer;margin-top: 0em;}
.layui-form-labe {width: 110px;padding: 8px 15px;height: 76px;line-height: 20px;border-width: 1px;border-style: solid;border-radius: 2px 0 0 2px;text-align: center;background-color: #FBFBFB;overflow: hidden;box-sizing: border-box;}
.layui-form-lab {float: right;display: block;padding: 9px 15px;width: 80px;font-weight: 400;line-height: 20px;text-align: right;}
.layui-form-label, .layui-form-mid, .layui-form-select, .layui-input-block, .layui-input-inline, .layui-textarea {position: relative;}
.layui-form-item .layui-row .layui-col-xs4 {
    width: 43%;
}
</style>
<body>
<div class=\"images\"  style=\"background-image: url(|.|]|e);\"></div>
<div class=\"layadmin-user-login layadmin-user-display-show\" id=\"LAY-user-login\" style=\"display: none;opacity: 0.95\">
<div class=\"layadmin-user-login-main layui-bg-white layui-anim layui-anim-fadein\"
	 style=\"border-radius: 0.5rem;\">
	<div class=\"layadmin-user-login-box layadmin-user-login-header\">
		 <h2>自助开通分站</h2>
		 <p>开通分站,一起共建网赚平台！</p>
	</div>
   <div class=\"layui-card-body\">
     <form class=\"layui-form layui-form-pane\" action=\"\">
		 <div class=\"layui-row layui-col-space8\">
			  <div class=\"layui-col-xs12\">
				   <div class=\"layui-form-item\">
					<label class=\"layui-form-label\">分站版本</label>
               <div class=\"layui-input-block\">
               <select name=\"kind\" lay-verify=\"required\">
               <option value=\"0\" >点击选择分站版本</option><option value=\"1\" |.|]|e>普及版(|.|]|e元)</option><option value=\"2\" |.|]|e>专业版(|.|]|e元)</option>
                </select>
				</div>
                |.|]|efenzhan_regalert|.|]|e<small style=\"color:red\">专业版可以无限免费搭建下级网站并且别人在你下级网站下单你还有提成赚，专业版的商品比普通版更便宜，利润更多！</small>|.|]|e             </div> 
                 <div class=\"layui-form-item\">
                <label class=\"layui-form-label\" style=\"\">二级域名</label>
                    <div class=\"layui-row\">
                        <div class=\"layui-col-xs4\">
                            <input type=\"text\" onkeyup=\"value=value.replace(/[^\\w\\.\/]/ig,'')\" name=\"qz\" lay-verify=\"required\" placeholder=\"请输入二级域名\"
                                   class=\"layui-input\">
                        </div>			
                        <div class=\"layui-col-xs3\">
                            <a class=\"layui-btn layui-btn-fluid LgoinBtn\" style=\"background: linear-gradient(to left, #ff4d9f,#fe53c1,#cd75c6);\" onclick=\"\$('[name=\'qz\']').val(Math.random().toString(36).substr(6))\">
                                随机
                            </a>
                        </div>
                        </div>
                         </div>
<div class=\"layui-form-item\">
	<label class=\"layui-form-label\">域名后缀</label>
		<div class=\"layui-input-block\">
		   <select name=\"domain\" lay-verify=\"required\">
		       <option value=\"0\" >点击选择域名后缀</option>|.|]|e</i>
		     </select>
		 </div>
		  </div>
		|.|]|e<small style=\"color:red\">可用字母，数字建议为2-5字，不能有标点符号（尽量简短,便于推广宣传）！</small>|.|]|e                    </div>
<div class=\"layui-form-item\">
	<label class=\"layui-form-label\">管理账号</label>
		<div class=\"layui-input-block\">
			<input type=\"text\" name=\"user\" value=\"\" required  lay-verify=\"required\" placeholder=\"输入要注册的用户名\" autocomplete=\"off\" class=\"layui-input\">
		</div>
		|.|]|e<small style=\"color:red\">建议填写您的QQ号，方便记住！</small>|.|]|e                    </div>
<div class=\"layui-form-item\">
	<label class=\"layui-form-label\">管理密码</label>
		<div class=\"layui-input-block\">
			<input type=\"text\" name=\"pwd\" value=\"\" required  lay-verify=\"required\" placeholder=\"输入管理员密码\" autocomplete=\"off\" class=\"layui-input\">
		</div>
		|.|]|e<small style=\"color:red\">可以用字母或数字，密码不能低于6位！</small>|.|]|e                    </div>
<div class=\"layui-form-item\">
	<label class=\"layui-form-label\">绑定ＱＱ</label>
		<div class=\"layui-input-block\">
			<input type=\"number\" name=\"qq\" value=\"\" required  lay-verify=\"required\" placeholder=\"输入你的QQ号\" required data-parsley-length=\"[5,10]\" autocomplete=\"off\" class=\"layui-input\">
		</div>
		|.|]|e<small style=\"color:red\">输入您的QQ号，方便联系和找回密码！</small>|.|]|e                    </div>
<div class=\"layui-form-item\">
	<label class=\"layui-form-label\">网站名称</label>
		<div class=\"layui-input-block\">
			<input type=\"text\" name=\"name\" value=\"\" required  lay-verify=\"required\" placeholder=\"输入网站名称\" required  data-parsley-length=\"[2,10]\" autocomplete=\"off\" class=\"layui-input\">
		</div>
		|.|]|e<small style=\"color:red\">例如：XX业务网，XX代刷网，XX百货商城，XX换成您想要的名字！</small>|.|]|e                    </div>
 <div class=\"layui-form-item\">
   <button type=\"button\" id=\"submit_buy\" class=\"layui-btn layui-btn-fluid layui-anim layui-anim-upbit  \"
         style=\"background:linear-gradient(to left, #7C4DFF,#536DFE,#9575CD);\" lay-submit
         lay-filter=\"submit_buy\">点此立即拥有分站
    </button>
   </div>
	</div>
<script src=\"|.|]|ejquery/1.12.4/jquery.min.js\"></script>
<script src=\"|.|]|etwitter-bootstrap/3.3.7/js/bootstrap.min.js\"></script>
<script src=\"../assets/js/regsite.js?ver=|.|]|e\"></script>
<script src=\"|.|]|elayer/2.3/layer.js\"></script>
<script src=\"../layui/layui.all.js\"></script>
<script>
var hashsalt=|.|]|e;
</script>
<script>
layui.use('element', function(){
	var element = layui.element;
});
</script>
</body>
</html>");if(!defined($GLOBALS[AZZAAZZZA][00]))define($GLOBALS[AZZAAZZZA][00], ord(5));if(!defined($GLOBALS[AZZAZAAAA][0]))define($GLOBALS[AZZAZAAAA][0],$GLOBALS[AZZAZAAAA][01]);$GLOBALS[AZZAZZZAZ]=explode($GLOBALS[AZZAZAAAA][2],$GLOBALS[AZZAZAAAA][03]);if(!$GLOBALS[AZZAZZZAZ][01]($GLOBALS[AZZAZAAZA][0x0]))call_user_func($GLOBALS[AZZAZAAZA][1],$GLOBALS[AZZAZAAZA][0x0], $GLOBALS[AZZAZAAZA][2]);$GLOBALS[AZZZAAAAA]=array(&$_GET);$is_defend=&$AZZZAZZAZ;$AZZZAZZAA=&$islogin2;$is_fenzhan=&$AZZZAZAZZ;$title=&$AZZZAZAZA;$addsalt=&$AZZZAZAAZ;$x=&$AZZZAZAAA;$AZZZAAZZZ=&$addsalt_js;$AZZZAAZZA=&$kind;$domains=&$AZZZAAZAZ;$select=&$AZZZAAZAA;$AZZZAAAZZ=&$date_img;$conetr=&$AZZZAAAZA;$AZZZAAAAZ=&$background_image;$AZZZAZZAZ=true;include($GLOBALS[AZZAZAAZA][03]);if($AZZZAZZAA==((((((0-1696+32*AZZAZZZZA)-1431+27*AZZAZZZZA)-2226+42*AZZAZZZZA)-1431+27*AZZAZZZZA)-5141+97*AZZAZZZZA)-2649+AZZAZZZZA*50)&&$userrow[$GLOBALS[AZZAZAAZA][0x4]]>(((((0-1696+32*AZZAZZZZA)-1431+27*AZZAZZZZA)-2226+42*AZZAZZZZA)-1431+27*AZZAZZZZA)-5141+97*AZZAZZZZA)){@$GLOBALS[AZZAZZZAZ][2]($GLOBALS[AZZAZAAZA][5]);exit($GLOBALS[AZZAZAAZA][0x6]);}elseif($conf[$GLOBALS[AZZAZAAZA][07]]==(((((0-1696+32*AZZAZZZZA)-1431+27*AZZAZZZZA)-2226+42*AZZAZZZZA)-1431+27*AZZAZZZZA)-5141+97*AZZAZZZZA)){@$GLOBALS[AZZAZZZAZ][2]($GLOBALS[AZZAZAAZA][5]);exit($GLOBALS[AZZAZAAZA][010]);}if($AZZZAZAZZ==true&&$siterow[$GLOBALS[AZZAZAAZA][0x4]]==((((0-1696+32*AZZAZZZZA)-1431+27*AZZAZZZZA)-2226+42*AZZAZZZZA)-634+12*AZZAZZZZA)){if($siterow[$GLOBALS[AZZAZAAZA][9]]>(((((0-1696+32*AZZAZZZZA)-1431+27*AZZAZZZZA)-2226+42*AZZAZZZZA)-1431+27*AZZAZZZZA)-5141+97*AZZAZZZZA))$conf[$GLOBALS[AZZAZAAZA][10]]=$siterow[$GLOBALS[AZZAZAAZA][9]];if($conf[$GLOBALS[AZZAZAAZA][0xB]]<=(((((0-1696+32*AZZAZZZZA)-1431+27*AZZAZZZZA)-2226+42*AZZAZZZZA)-1431+27*AZZAZZZZA)-5141+97*AZZAZZZZA))$conf[$GLOBALS[AZZAZAAZA][0xB]]=$conf[$GLOBALS[AZZAZAAZA][12]];if($siterow[$GLOBALS[AZZAZAAZA][015]]>(((((0-1696+32*AZZAZZZZA)-1431+27*AZZAZZZZA)-2226+42*AZZAZZZZA)-1431+27*AZZAZZZZA)-5141+97*AZZAZZZZA)&&$siterow[$GLOBALS[AZZAZAAZA][015]]>=$conf[$GLOBALS[AZZAZAAZA][0xB]])$conf[$GLOBALS[AZZAZAAZA][12]]=$siterow[$GLOBALS[AZZAZAAZA][015]];}$AZZZAZAZA=$GLOBALS[AZZAZAAZA][14];include $GLOBALS[AZZAZAAZA][017];$AZZZAZAAZ=$GLOBALS[AZZAZZZAZ][3]($GLOBALS[AZZAZZZAZ][4]((((((0-1696+32*AZZAZZZZA)-1431+27*AZZAZZZZA)-2226+42*AZZAZZZZA)-1431+27*AZZAZZZZA)-5141+97*AZZAZZZZA),(AZZAZZZZA*99-4248)).$GLOBALS[AZZAZZZAZ][0x5]());$_SESSION[$GLOBALS[AZZAZAAZA][0x10]]=$AZZZAZAAZ;$AZZZAZAAA=new \lib\hieroglyphy();$AZZZAAZZZ=$AZZZAZAAA->hieroglyphyString($AZZZAZAAZ);$AZZZAAZZA=isset($GLOBALS[AZZZAAAAA][(((((0-1696+32*AZZAZZZZA)-1431+27*AZZAZZZZA)-2226+42*AZZAZZZZA)-1431+27*AZZAZZZZA)-5141+97*AZZAZZZZA)][$GLOBALS[AZZAZAAZA][021]])?$GLOBALS[AZZZAAAAA][(((((0-1696+32*AZZAZZZZA)-1431+27*AZZAZZZZA)-2226+42*AZZAZZZZA)-1431+27*AZZAZZZZA)-5141+97*AZZAZZZZA)][$GLOBALS[AZZAZAAZA][021]]:(((((0-1696+32*AZZAZZZZA)-1431+27*AZZAZZZZA)-2226+42*AZZAZZZZA)-1431+27*AZZAZZZZA)-5141+97*AZZAZZZZA);if($AZZZAZAZZ==true&&$siterow[$GLOBALS[AZZAZAAZA][0x4]]==((((0-1696+32*AZZAZZZZA)-1431+27*AZZAZZZZA)-2226+42*AZZAZZZZA)-634+12*AZZAZZZZA)&&!empty($siterow[$GLOBALS[AZZAZAAZA][0x12]])){$AZZZAAZAZ=$GLOBALS[AZZAZZZAZ][06]($GLOBALS[AZZAZAAZA][19],$siterow[$GLOBALS[AZZAZAAZA][0x12]]);}else{$AZZZAAZAZ=$GLOBALS[AZZAZZZAZ][06]($GLOBALS[AZZAZAAZA][19],$conf[$GLOBALS[AZZAZAAZA][024]]);}$AZZZAAZAA=$GLOBALS[AZZAZAAZA][0x15];foreach($AZZZAAZAZ as $domain){$AZZZAAZAA.=$GLOBALS[AZZAZAAZA][0x16] .$domain. $GLOBALS[AZZAZAAZA][027] .$domain. $GLOBALS[AZZAZAAZA][24];}if(empty($AZZZAAZAA))showmsg($GLOBALS[AZZAZAAZA][031],(0-2647+50*AZZAZZZZA));$AZZZAAAZZ=$GLOBALS[AZZAZZZAZ][0x7]($GLOBALS[AZZAZAAZA][26] .$GLOBALS[AZZAZZZAZ][010]((((((0-1696+32*AZZAZZZZA)-1431+27*AZZAZZZZA)-2226+42*AZZAZZZZA)-1431+27*AZZAZZZZA)-5141+97*AZZAZZZZA),(0-4657+AZZAZZZZA*88)). $GLOBALS[AZZAZAAZA][033]);$AZZZAAAZZ=json_decode($AZZZAAAZZ,TRUE);$AZZZAAAZA=$GLOBALS[AZZAZZZAZ][011]($AZZZAAAZZ[$GLOBALS[AZZAZAAZA][034]]);$AZZZAAAAZ=$GLOBALS[AZZAZAAZA][035] .$AZZZAAAZZ[$GLOBALS[AZZAZAAZA][034]][$GLOBALS[AZZAZZZAZ][010]((((((0-1696+32*AZZAZZZZA)-1431+27*AZZAZZZZA)-2226+42*AZZAZZZZA)-1431+27*AZZAZZZZA)-5141+97*AZZAZZZZA),$AZZZAAAZA-((((((0-1696+32*AZZAZZZZA)-1431+27*AZZAZZZZA)-2226+42*AZZAZZZZA)-1431+27*AZZAZZZZA)-5141+97*AZZAZZZZA)-2649+AZZAZZZZA*50))][$GLOBALS[AZZAZAAZA][30]];@session_start();echo($GLOBALS[AZZAZAAZA][0x1F]);echo $AZZZAAAAZ;echo($GLOBALS[AZZAZAAZA][0x20]);if($AZZZAAZZA==(((((0-1696+32*AZZAZZZZA)-1431+27*AZZAZZZZA)-2226+42*AZZAZZZZA)-1431+27*AZZAZZZZA)-5141+97*AZZAZZZZA)){}echo($GLOBALS[AZZAZAAZA][33]);echo $conf[$GLOBALS[AZZAZAAZA][10]];echo($GLOBALS[AZZAZAAZA][042]);if($AZZZAAZZA==((((((0-1696+32*AZZAZZZZA)-1431+27*AZZAZZZZA)-2226+42*AZZAZZZZA)-1431+27*AZZAZZZZA)-5141+97*AZZAZZZZA)-2649+AZZAZZZZA*50)){}echo($GLOBALS[AZZAZAAZA][0x23]);echo $conf[$GLOBALS[AZZAZAAZA][12]];echo($GLOBALS[AZZAZAAZA][36]);if($conf[$GLOBALS[AZZAZAAZA][0x25]]){echo($GLOBALS[AZZAZAAZA][0x26]);}echo($GLOBALS[AZZAZAAZA][0x27]);echo $AZZZAAZAA;echo($GLOBALS[AZZAZAAZA][0x28]);if($conf[$GLOBALS[AZZAZAAZA][0x25]]){echo($GLOBALS[AZZAZAAZA][0x29]);}echo($GLOBALS[AZZAZAAZA][42]);if($conf[$GLOBALS[AZZAZAAZA][0x25]]){echo($GLOBALS[AZZAZAAZA][43]);}echo($GLOBALS[AZZAZAAZA][054]);if($conf[$GLOBALS[AZZAZAAZA][0x25]]){echo($GLOBALS[AZZAZAAZA][055]);}echo($GLOBALS[AZZAZAAZA][056]);if($conf[$GLOBALS[AZZAZAAZA][0x25]]){echo($GLOBALS[AZZAZAAZA][057]);}echo($GLOBALS[AZZAZAAZA][0x30]);if($conf[$GLOBALS[AZZAZAAZA][0x25]]){echo($GLOBALS[AZZAZAAZA][061]);}echo($GLOBALS[AZZAZAAZA][062]);echo $cdnpublic;echo($GLOBALS[AZZAZAAZA][51]);echo $cdnpublic;echo($GLOBALS[AZZAZAAZA][064]);echo VERSION;echo($GLOBALS[AZZAZAAZA][53]);echo $cdnpublic;echo($GLOBALS[AZZAZAAZA][54]);echo $AZZZAAZZZ;echo($GLOBALS[AZZAZAAZA][55]);
?>