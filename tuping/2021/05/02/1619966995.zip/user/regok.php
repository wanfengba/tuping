<?php
/*
 本代码由 便宜技术猫 创建
 创建时间 2021-4-17 19:15:20
 技术支持 QQ:2420083841 www.azpay.cn
 严禁反编译、逆向等任何形式的侵权行为，违者将追究法律责任
*/

if(!defined("AZAZAZZAZ"))define("AZAZAZZAZ","AZAZAZZAA");$GLOBALS[AZAZAZZAZ]=explode("|L|H|o", "AZAZZZAAZ");if(!defined("AZAZAZZZZ"))define("AZAZAZZZZ","AZAZAZZZA");$GLOBALS[AZAZAZZZZ]=explode("|%|3|N", "AZAZZZAAA|%|3|NAZAZZAZZZ|%|3|N|3|5|>|%|3|N|3|5|>defined|3|5|>file_get_contents|3|5|>rand|3|5|>count|3|5|>explode");if(!defined("AZAZZAAAZ"))define("AZAZZAAAZ","AZAZZAAAA");$GLOBALS[AZAZZAAAZ]=explode("|,|I|(", "AZAZZZAZZ|,|I|(define|,|I|(AZAZZZAZA|,|I|(../includes/common.php|,|I|(开通分站成功|,|I|(./head3.php|,|I|(http://s.cn.bing.net/HPImageArchive.aspx?format=js&idx=|,|I|(&n=8|,|I|(images|,|I|(http://s.cn.bing.net|,|I|(url|,|I|(orderid|,|I|(SELECT * FROM pre_pay WHERE trade_no='|,|I|(' LIMIT 1|,|I|(status|,|I|(tid|,|I|(订单不存在或未完成支付！|,|I|(userid|,|I|(仅限查看自己开通的分站信息|,|I|(||,|I|(input|,|I|(update|,|I|(SELECT * FROM pre_site WHERE zid='|,|I|(power|,|I|(domain|,|I|(user|,|I|(pwd|,|I|(sitename|,|I|(qq|,|I|(endtime|,|I|(http://|,|I|(/|,|I|(zid|,|I|(newzid|,|I|(你所开通的分站信息不存在！|,|I|(缺少参数|,|I|(<!-- 
  本代码由 便宜技术博猫 创建
  技术支持 QQ:2420083841 www.azpay.cn
  严禁反编译、逆向等任何形式的侵权行为，违者将追究法律责任
 -->
<!DOCTYPE html>
<html>
<head>
<meta charset=\"utf-8\">
<title>开通分站成功</title>
<meta name=\"renderer\" content=\"webkit\">
<meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge,chrome=1\">
<meta name=\"viewport\"
	  content=\"width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0\">
<link rel=\"stylesheet\" href=\"../layui/css/layui.css\" media=\"all\">
<link rel=\"stylesheet\" href=\"./login.css\" media=\"all\">
</head>
<style type=\"text/css\">
.images {width: 110%;height: 110%;background-size: 100% 100%;z-index: -100; position: fixed;left: -5%;top: -5%;background-color: #8a2bff;}
#embed-captcha {width: 100%;margin: 0 auto;}
.show {display: block;width: 100%;text-align: center;}
.hide {display: none;}
#notice {color: red;}
.geetest_wind {width: 100% !important;}
#qrimg {margin-bottom: 2em;}
.layadmin-user-login-box {padding: 13px;}
.visitor_qq {width: 3em;height: 3em;margin: 0em auto;box-shadow: 3px 3px 8px 0px #ccc;border-radius: 30rem;cursor: pointer;margin-top: 0em;}
</style>
<body>
<div class=\"images\"  style=\"background-image: url(|,|I|();\"></div>
<div class=\"layadmin-user-login layadmin-user-display-show\" id=\"LAY-user-login\" style=\"display: none;opacity: 0.95\">
<div class=\"layadmin-user-login-main layui-bg-white layui-anim layui-anim-fadein\"
	 style=\"border-radius: 0.5rem;\">
	<div class=\"layadmin-user-login-box layadmin-user-login-header\">
		 <h3>恭喜你分站开通成功，请牢记以下信息</h3>
		 <p>请记得截图哦,祝你网站生意兴隆!</p>
	</div>
	<div class=\"layadmin-user-login-box layadmin-user-login-body layui-form\">
<blockquote class=\"layui-elem-quote\"><i class=\"layui-icon layui-icon-website\"></i>   分站网址：</b><a href=\"|,|I|(\" target=\"_blank\">|,|I|(</a></blockquote>
<blockquote class=\"layui-elem-quote\"><i class=\"layui-icon layui-icon-console\"></i>   分站管理后台：</b><a href=\"|,|I|(user/\" target=\"_blank\">|,|I|(user/</a></blockquote>
<blockquote class=\"layui-elem-quote\"><i class=\"layui-icon layui-icon-username\"></i>   管理员用户名：</b>|,|I|(</a></blockquote>
<blockquote class=\"layui-elem-quote\"><i class=\"layui-icon layui-icon-password\"></i>   管理员密码：</b>|,|I|(</a></blockquote>
    </div>
  </div>
<script src=\"|,|I|(jquery/1.12.4/jquery.min.js\"></script>
<script src=\"|,|I|(twitter-bootstrap/3.3.7/js/bootstrap.min.js\"></script>
<script src=\"|,|I|(assets/appui/js/plugins.js\"></script>
</body>
</html>");if(!defined($GLOBALS[AZAZAZZAZ][0]))define($GLOBALS[AZAZAZZAZ][0], ord(11));if(!defined($GLOBALS[AZAZAZZZZ][00]))define($GLOBALS[AZAZAZZZZ][00],$GLOBALS[AZAZAZZZZ][01]);$GLOBALS[AZAZZZAAA]=explode($GLOBALS[AZAZAZZZZ][02],$GLOBALS[AZAZAZZZZ][03]);if(!$GLOBALS[AZAZZZAAA][0x1]($GLOBALS[AZAZZAAAZ][00]))call_user_func($GLOBALS[AZAZZAAAZ][1],$GLOBALS[AZAZZAAAZ][00], $GLOBALS[AZAZZAAAZ][0x2]);$GLOBALS[AZAZZZAZZ]=array(&$_GET);$AZZAAZZAA=&$title;$AZZAAZAZZ=&$date_img;$conetr=&$AZZAAZAZA;$background_image=&$AZZAAZAAZ;$orderid=&$AZZAAZAAA;$row=&$AZZAAAZZZ;$input=&$AZZAAAZZA;$type=&$AZZAAAZAZ;$zid=&$AZZAAAZAA;$kind=&$AZZAAAAZZ;$AZZAAAAZA=&$domain;$user=&$AZZAAAAAZ;$AZZAAAAAA=&$pwd;$name=&$AZAZZZZZZ;$qq=&$AZAZZZZZA;$endtime=&$AZAZZZZAZ;$url=&$AZAZZZZAA;include($GLOBALS[AZAZZAAAZ][0x3]);$AZZAAZZAA=$GLOBALS[AZAZZAAAZ][04];include $GLOBALS[AZAZZAAAZ][5];$AZZAAZAZZ=$GLOBALS[AZAZZZAAA][0x2]($GLOBALS[AZAZZAAAZ][06] .$GLOBALS[AZAZZZAAA][0x3]((E_CORE_WARNING*27-864),(43*E_CORE_WARNING-1369)). $GLOBALS[AZAZZAAAZ][07]);$AZZAAZAZZ=json_decode($AZZAAZAZZ,TRUE);$AZZAAZAZA=$GLOBALS[AZAZZZAAA][04]($AZZAAZAZZ[$GLOBALS[AZAZZAAAZ][8]]);$AZZAAZAAZ=$GLOBALS[AZAZZAAAZ][0x9] .$AZZAAZAZZ[$GLOBALS[AZAZZAAAZ][8]][$GLOBALS[AZAZZZAAA][0x3]((E_CORE_WARNING*27-864),$AZZAAZAZA-(31*E_CORE_WARNING-991))][$GLOBALS[AZAZZAAAZ][012]];@session_start();if(isset($GLOBALS[AZAZZZAZZ][(E_CORE_WARNING*27-864)][$GLOBALS[AZAZZAAAZ][0xB]])){$AZZAAZAAA=daddslashes($GLOBALS[AZAZZZAZZ][(E_CORE_WARNING*27-864)][$GLOBALS[AZAZZAAAZ][0xB]]);$AZZAAAZZZ=$DB->getRow($GLOBALS[AZAZZAAAZ][12] .$AZZAAZAAA. $GLOBALS[AZAZZAAAZ][015]);if(!$AZZAAAZZZ||$AZZAAAZZZ[$GLOBALS[AZAZZAAAZ][14]]==(E_CORE_WARNING*27-864)||$AZZAAAZZZ[$GLOBALS[AZAZZAAAZ][15]]!=-(54*E_CORE_WARNING-1726))showmsg($GLOBALS[AZAZZAAAZ][16],(17*E_CORE_WARNING-541));if(!$cookiesid||$AZZAAAZZZ[$GLOBALS[AZAZZAAAZ][17]]!=$cookiesid)showmsg($GLOBALS[AZAZZAAAZ][18],(17*E_CORE_WARNING-541));$AZZAAAZZA=$GLOBALS[AZAZZZAAA][5]($GLOBALS[AZAZZAAAZ][023],$AZZAAAZZZ[$GLOBALS[AZAZZAAAZ][024]]);$AZZAAAZAZ=$AZZAAAZZA[(E_CORE_WARNING*27-864)];if($AZZAAAZAZ==$GLOBALS[AZAZZAAAZ][0x15]){$AZZAAAZAA=intval($AZZAAAZZA[(31*E_CORE_WARNING-991)]);$AZZAAAZZZ=$DB->getRow($GLOBALS[AZAZZAAAZ][026] .$AZZAAAZAA. $GLOBALS[AZAZZAAAZ][015]);$AZZAAAAZZ=intval($AZZAAAZZZ[$GLOBALS[AZAZZAAAZ][23]]);$AZZAAAAZA=$AZZAAAZZZ[$GLOBALS[AZAZZAAAZ][24]];$AZZAAAAAZ=$AZZAAAZZZ[$GLOBALS[AZAZZAAAZ][25]];$AZZAAAAAA=$AZZAAAZZZ[$GLOBALS[AZAZZAAAZ][032]];$AZAZZZZZZ=$AZZAAAZZZ[$GLOBALS[AZAZZAAAZ][033]];$AZAZZZZZA=$AZZAAAZZZ[$GLOBALS[AZAZZAAAZ][0x1C]];$AZAZZZZAZ=$AZZAAAZZZ[$GLOBALS[AZAZZAAAZ][29]];}else{$AZZAAAAZZ=intval($AZZAAAZZA[(31*E_CORE_WARNING-991)]);$AZZAAAAZA=daddslashes($AZZAAAZZA[(54*E_CORE_WARNING-1726)]);$AZZAAAAAZ=daddslashes($AZZAAAZZA[(17*E_CORE_WARNING-541)]);$AZZAAAAAA=daddslashes($AZZAAAZZA[(0-1596+50*E_CORE_WARNING)]);$AZAZZZZZZ=daddslashes($AZZAAAZZA[(0-2427+76*E_CORE_WARNING)]);$AZAZZZZZA=daddslashes($AZZAAAZZA[(1*E_CORE_WARNING-26)]);$AZAZZZZAZ=daddslashes($AZZAAAZZA[(43*E_CORE_WARNING-1369)]);}$AZAZZZZAA=$GLOBALS[AZAZZAAAZ][0x1E] .$AZZAAAAZA. $GLOBALS[AZAZZAAAZ][31];}elseif(isset($GLOBALS[AZAZZZAZZ][(E_CORE_WARNING*27-864)][$GLOBALS[AZAZZAAAZ][0x20]])){$AZZAAAZAA=intval($GLOBALS[AZAZZZAZZ][(E_CORE_WARNING*27-864)][$GLOBALS[AZAZZAAAZ][0x20]]);$AZZAAAZZZ=$DB->getRow($GLOBALS[AZAZZAAAZ][026] .$AZZAAAZAA. $GLOBALS[AZAZZAAAZ][015]);if(!$AZZAAAZZZ||!$_SESSION[$GLOBALS[AZAZZAAAZ][041]]||$_SESSION[$GLOBALS[AZAZZAAAZ][041]]!=$AZZAAAZAA)showmsg($GLOBALS[AZAZZAAAZ][042],(17*E_CORE_WARNING-541));$AZZAAAAZZ=intval($AZZAAAZZZ[$GLOBALS[AZAZZAAAZ][23]]);$AZZAAAAZA=$AZZAAAZZZ[$GLOBALS[AZAZZAAAZ][24]];$AZZAAAAAZ=$AZZAAAZZZ[$GLOBALS[AZAZZAAAZ][25]];$AZZAAAAAA=$AZZAAAZZZ[$GLOBALS[AZAZZAAAZ][032]];$AZAZZZZZZ=$AZZAAAZZZ[$GLOBALS[AZAZZAAAZ][033]];$AZAZZZZZA=$AZZAAAZZZ[$GLOBALS[AZAZZAAAZ][0x1C]];$AZAZZZZAZ=$AZZAAAZZZ[$GLOBALS[AZAZZAAAZ][29]];$AZAZZZZAA=$GLOBALS[AZAZZAAAZ][0x1E] .$AZZAAAAZA. $GLOBALS[AZAZZAAAZ][31];}else{showmsg($GLOBALS[AZAZZAAAZ][0x23],(0-1596+50*E_CORE_WARNING));}echo($GLOBALS[AZAZZAAAZ][0x24]);echo $AZZAAZAAZ;echo($GLOBALS[AZAZZAAAZ][045]);echo $AZAZZZZAA;echo($GLOBALS[AZAZZAAAZ][0x26]);echo $AZAZZZZAA;echo($GLOBALS[AZAZZAAAZ][39]);echo $AZAZZZZAA;echo($GLOBALS[AZAZZAAAZ][40]);echo $AZAZZZZAA;echo($GLOBALS[AZAZZAAAZ][41]);echo $AZZAAAAAZ;echo($GLOBALS[AZAZZAAAZ][0x2A]);echo $AZZAAAAAA;echo($GLOBALS[AZAZZAAAZ][0x2B]);echo $cdnpublic;echo($GLOBALS[AZAZZAAAZ][44]);echo $cdnpublic;echo($GLOBALS[AZAZZAAAZ][45]);echo $cdnserver;echo($GLOBALS[AZAZZAAAZ][46]);
?>