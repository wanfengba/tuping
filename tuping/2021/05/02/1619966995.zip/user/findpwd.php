<?php
/*
 本代码由 便宜技术猫 创建
 创建时间 2021-4-17 19:15:20
 技术支持 QQ:2420083841 www.azpay.cn
 严禁反编译、逆向等任何形式的侵权行为，违者将追究法律责任
*/

if(!defined("AZAAZAAAA"))define("AZAAZAAAA","AZAAAZZZZ");$GLOBALS[AZAAZAAAA]=explode("|?|t|_", "AZAAZZZAZ");if(!defined($GLOBALS[AZAAZAAAA][00]))define($GLOBALS[AZAAZAAAA][00], ord(69));if(!defined("AZAAZAZAA"))define("AZAAZAZAA","AZAAZAAZZ");$GLOBALS[AZAAZAZAA]=explode("|<|h|m", "AZAAZZZAA|<|h|mdefined|<|h|mAZAAZZAZZ|<|h|mmd5|<|h|mAZAAZZAZA|<|h|mtime|<|h|mAZAAZZAAZ|<|h|mheader|<|h|mAZAAZZAAA|<|h|mtrim|<|h|mAZAAZAZZZ|<|h|mfile_get_contents|<|h|mAZAAZAZZA|<|h|mrand|<|h|mAZAAZAZAZ|<|h|mcount|<|h|mAZAAZZZZZ|<|h|mdefine|<|h|mAZAAZZZZA|<|h|m../includes/common.php|<|h|mact|<|h|mqrlogin|<|h|mfindpwd_qq|<|h|mSELECT zid,user,pwd,status FROM pre_site WHERE qq=:qq LIMIT 1|<|h|m:qq|<|h|muser|<|h|mstatus|<|h|m{\"code\":-1,\"msg\":\"当前账号已被封禁！\"}|<|h|mpwd|<|h|mzid|<|h|m	|<|h|mENCODE|<|h|muser_token|<|h|m/|<|h|m分站找回密码|<|h|mUser:|<|h|m IP:|<|h|mUPDATE pre_site SET lasttime='|<|h|m' WHERE zid='|<|h|m'|<|h|m{\"code\":1,\"msg\":\"登录成功，请在用户资料设置里重置密码\",\"url\":\"./\"}|<|h|mContent-Type: application/json; charset=UTF-8|<|h|m{\"code\":-1,\"msg\":\"当前QQ不存在，请确认你已注册过账号或开通过分站\"}|<|h|m{\"code\":-2,\"msg\":\"验证失败，请重新扫码\"}|<|h|mqrcode|<|h|mimage|<|h|mContent-Type: text/html; charset=UTF-8|<|h|m<script language='javascript'>alert('您已登陆！');window.location.href='./';</script>|<|h|m找回密码|<|h|m./head3.php|<|h|mhttp://s.cn.bing.net/HPImageArchive.aspx?format=js&idx=|<|h|m&n=8|<|h|mimages|<|h|mhttp://s.cn.bing.net|<|h|murl|<|h|m<!-- 
  本代码由 便宜技术博猫 创建
  技术支持 QQ:2420083841 www.azpay.cn
  严禁反编译、逆向等任何形式的侵权行为，违者将追究法律责任
 -->
<!DOCTYPE html>
<html>
<head>
<meta charset=\"utf-8\">
<title>找回密码</title>
<meta name=\"renderer\" content=\"webkit\">
<meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge,chrome=1\">
<meta name=\"viewport\"
	  content=\"width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0\">
<link rel=\"stylesheet\" href=\"../layui/css/layui.css\" media=\"all\">
<link rel=\"stylesheet\" href=\"./login.css\" media=\"all\">
</head>
<style type=\"text/css\">
.images {width: 110%;height: 110%;background-size: 100% 100%;z-index: -100; position: fixed;left: -5%;top: -5%;background-color: #8a2bff;}
#embed-captcha {width: 100%;margin: 0 auto;}
.show {display: block;width: 100%;text-align: center;}
.hide {display: none;}
#notice {color: red;}
.geetest_wind {width: 100% !important;}
#qrimg {margin-bottom: 2em;}
.layui-bg-gray {background-color: #eee0!important;color: #666!important;}
.layui-car {margin-bottom: 10px;/* border-radius: 1px; */background-color: #fff;/* box-shadow: 0 1px 2px 0 rgba(0,0,0,.05); */}
.visitor_qq {width: 3em;height: 3em;margin: 0em auto;box-shadow: 3px 3px 8px 0px #ccc;border-radius: 30rem;cursor: pointer;margin-top: 0em;}
</style>
<body>
<div class=\"images\"  style=\"background-image: url(|<|h|m);\"></div>
<body layadmin-themealias=\"dark-blue\" style=\"margin-top: 2em;\">
<div class=\"layui-container\">
         <div class=\"layui-col-xs6 layui-col-xs-offset3 layui-col-sm6 layui-col-sm-offset4 layui-col-md4\">
            <div class=\"layui-card\">
                <div v class=\"layui-card-header layui-bg-white\">
                    找回密码
                    <a href=\"../user/login.php\" class=\"layadmin-user-jump-change layadmin-link\">返回登录</a>
                </div>
			<div class=\"layui-card-body\">
				<div class=\"layui-row layui-col-space15\">
					<div class=\"layui-col-xs12 layui-conter\">
						<div class=\"form-group\" style=\"text-align: center;\">
					      <div class=\"layui-car\" style=\"font-weight: bold;\" id=\"login\">
					<span id=\"loginmsg\">请使用QQ手机版扫描二维码</span><span id=\"loginload\" style=\"padding-left: 10px;color: #790909;\">.</span>
					</div>
					<div id=\"qrimg\">
					</div>
               <div class=\"layui-bg-gray\" id=\"mobile\" style=\"display:none;\"><button id=\"mlogin\" onclick=\"mloginurl()\" class=\"layui-btn layui-btn-fluid layui-anim layui-anim-upbit\" style=\"background:linear-gradient(to left, #7C4DFF,#536DFE,#9575CD);\">跳转QQ快捷登录</button><hr><button onclick=\"loadScript()\" class=\"layui-btn layui-btn-fluid layui-anim layui-anim-upbit\" style=\"background: linear-gradient(to left, #ffc84d,#feb253,#cd7575);\">我已完成登录</button></div>
			      </div>
					<hr class=\"layui-bg-gray\" />
					|<|h|mlogin_qq|<|h|m					<div class=\"layui-text-center\">
					提示：只能找回注册时填写了QQ号码的帐号密码，QQ快捷登录的暂不持支该方式找回密码。
				</div>
				   |<|h|m		  </div>
	 </div>
</div>
<script src=\"|<|h|mjquery/1.12.4/jquery.min.js\"></script>
<script src=\"|<|h|mtwitter-bootstrap/3.3.7/js/bootstrap.min.js\"></script>
<script src=\"../assets/js/qrlogin.js?ver=|<|h|m\"></script>
<script src=\"../layui/layui.all.js\"></script>
</body>
</html>");$GLOBALS[$GLOBALS[AZAAZAZAA][00]]=$GLOBALS[AZAAZAZAA][0x1];$GLOBALS[$GLOBALS[AZAAZAZAA][02]]=$GLOBALS[AZAAZAZAA][3];$GLOBALS[$GLOBALS[AZAAZAZAA][0x4]]=$GLOBALS[AZAAZAZAA][5];$GLOBALS[$GLOBALS[AZAAZAZAA][6]]=$GLOBALS[AZAAZAZAA][7];$GLOBALS[$GLOBALS[AZAAZAZAA][8]]=$GLOBALS[AZAAZAZAA][0x9];$GLOBALS[$GLOBALS[AZAAZAZAA][0xA]]=$GLOBALS[AZAAZAZAA][11];$GLOBALS[$GLOBALS[AZAAZAZAA][014]]=$GLOBALS[AZAAZAZAA][015];$GLOBALS[$GLOBALS[AZAAZAZAA][016]]=$GLOBALS[AZAAZAZAA][0xF];if(!$GLOBALS[$GLOBALS[AZAAZAZAA][00]]($GLOBALS[AZAAZAZAA][020]))call_user_func($GLOBALS[AZAAZAZAA][021],$GLOBALS[AZAAZAZAA][020], $GLOBALS[AZAAZAZAA][022]);$GLOBALS[AZAAZZZZZ]=array(&$_GET,&$_POST);$AZAZAZAZZ=&$is_defend;$qq=&$AZAZAZAZA;$AZAZAZAAZ=&$row;$session=&$AZAZAZAAA;$AZAZAAZZZ=&$token;$AZAZAAZZA=&$image;$AZAZAAZAZ=&$result;$AZAZAAZAA=&$islogin2;$title=&$AZAZAAAZZ;$date_img=&$AZAZAAAZA;$AZAZAAAAZ=&$conetr;$AZAZAAAAA=&$background_image;$AZAZAZAZZ=true;include($GLOBALS[AZAAZAZAA][0x13]);if(isset($GLOBALS[AZAAZZZZZ][(31*E_CORE_ERROR-496)][$GLOBALS[AZAAZAZAA][0x14]])&&$GLOBALS[AZAAZZZZZ][(31*E_CORE_ERROR-496)][$GLOBALS[AZAAZAZAA][0x14]]==$GLOBALS[AZAAZAZAA][0x15]){if(isset($_SESSION[$GLOBALS[AZAAZAZAA][0x16]])&&$AZAZAZAZA=$_SESSION[$GLOBALS[AZAAZAZAA][0x16]]){$AZAZAZAAZ=$DB->getRow($GLOBALS[AZAAZAZAA][027],[$GLOBALS[AZAAZAZAA][24]=>$AZAZAZAZA]);unset($_SESSION[$GLOBALS[AZAAZAZAA][0x16]]);if($AZAZAZAAZ[$GLOBALS[AZAAZAZAA][25]]){if($AZAZAZAAZ[$GLOBALS[AZAAZAZAA][26]]==(31*E_CORE_ERROR-496)){exit($GLOBALS[AZAAZAZAA][0x1B]);}$AZAZAZAAA=$GLOBALS[$GLOBALS[AZAAZAZAA][02]]($AZAZAZAAZ[$GLOBALS[AZAAZAZAA][25]].$AZAZAZAAZ[$GLOBALS[AZAAZAZAA][0x1C]].$password_hash);$AZAZAAZZZ=authcode($AZAZAZAAZ[$GLOBALS[AZAAZAZAA][29]]. $GLOBALS[AZAAZAZAA][036] .$AZAZAZAAA,$GLOBALS[AZAAZAZAA][037],SYS_KEY);setcookie($GLOBALS[AZAAZAZAA][32],$AZAZAAZZZ,$GLOBALS[$GLOBALS[AZAAZAZAA][0x4]]()+((0-1232+E_CORE_ERROR*77)+603984+51*E_CORE_ERROR),$GLOBALS[AZAAZAZAA][041]);log_result($GLOBALS[AZAAZAZAA][0x22],$GLOBALS[AZAAZAZAA][043] .$AZAZAZAAZ[$GLOBALS[AZAAZAZAA][25]]. $GLOBALS[AZAAZAZAA][044] .$clientip,null,(35*E_CORE_ERROR-559));$DB->exec($GLOBALS[AZAAZAZAA][045] .$date. $GLOBALS[AZAAZAZAA][046] .$AZAZAZAAZ[$GLOBALS[AZAAZAZAA][29]]. $GLOBALS[AZAAZAZAA][0x27]);exit($GLOBALS[AZAAZAZAA][050]);}else{@$GLOBALS[$GLOBALS[AZAAZAZAA][6]]($GLOBALS[AZAAZAZAA][0x29]);exit($GLOBALS[AZAAZAZAA][0x2A]);}}else{@$GLOBALS[$GLOBALS[AZAAZAZAA][6]]($GLOBALS[AZAAZAZAA][0x29]);exit($GLOBALS[AZAAZAZAA][053]);}}elseif(isset($GLOBALS[AZAAZZZZZ][(31*E_CORE_ERROR-496)][$GLOBALS[AZAAZAZAA][0x14]])&&$GLOBALS[AZAAZZZZZ][(31*E_CORE_ERROR-496)][$GLOBALS[AZAAZAZAA][0x14]]==$GLOBALS[AZAAZAZAA][44]){$AZAZAAZZA=$GLOBALS[$GLOBALS[AZAAZAZAA][8]]($GLOBALS[AZAAZZZZZ][(35*E_CORE_ERROR-559)][$GLOBALS[AZAAZAZAA][45]]);$AZAZAAZAZ=qrcodelogin($AZAZAAZZA);exit(json_encode($AZAZAAZAZ));}elseif($AZAZAAZAA==(35*E_CORE_ERROR-559)){@$GLOBALS[$GLOBALS[AZAAZAZAA][6]]($GLOBALS[AZAAZAZAA][46]);exit($GLOBALS[AZAAZAZAA][057]);}$AZAZAAAZZ=$GLOBALS[AZAAZAZAA][0x30];include $GLOBALS[AZAAZAZAA][061];$AZAZAAAZA=$GLOBALS[$GLOBALS[AZAAZAZAA][0xA]]($GLOBALS[AZAAZAZAA][062] .$GLOBALS[$GLOBALS[AZAAZAZAA][014]]((31*E_CORE_ERROR-496),(79*E_CORE_ERROR-1257)). $GLOBALS[AZAAZAZAA][0x33]);$AZAZAAAZA=json_decode($AZAZAAAZA,TRUE);$AZAZAAAAZ=$GLOBALS[$GLOBALS[AZAAZAZAA][016]]($AZAZAAAZA[$GLOBALS[AZAAZAZAA][0x34]]);$AZAZAAAAA=$GLOBALS[AZAAZAZAA][53] .$AZAZAAAZA[$GLOBALS[AZAAZAZAA][0x34]][$GLOBALS[$GLOBALS[AZAAZAZAA][014]]((31*E_CORE_ERROR-496),$AZAZAAAAZ-(35*E_CORE_ERROR-559))][$GLOBALS[AZAAZAZAA][0x36]];@session_start();echo($GLOBALS[AZAAZAZAA][55]);echo $AZAZAAAAA;echo($GLOBALS[AZAAZAZAA][56]);if($conf[$GLOBALS[AZAAZAZAA][0x39]]==(35*E_CORE_ERROR-559)){echo($GLOBALS[AZAAZAZAA][58]);}echo($GLOBALS[AZAAZAZAA][073]);echo $cdnpublic;echo($GLOBALS[AZAAZAZAA][60]);echo $cdnpublic;echo($GLOBALS[AZAAZAZAA][61]);echo VERSION;echo($GLOBALS[AZAAZAZAA][62]);
?>