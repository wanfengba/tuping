<?php
/*
 本代码由 便宜技术猫 创建
 创建时间 2021-4-17 19:15:20
 技术支持 QQ:2420083841 www.azpay.cn
 严禁反编译、逆向等任何形式的侵权行为，违者将追究法律责任
*/

if(!defined("AAZZAAAZZ"))define("AAZZAAAZZ","AAZZAAAZA");$GLOBALS[AAZZAAAZZ]=explode("|T|)|y", "AAZZAZZZA");if(!defined($GLOBALS[AAZZAAAZZ][0]))define($GLOBALS[AAZZAAAZZ][0], ord(4));if(!defined("AAZZAAZAZ"))define("AAZZAAZAZ","AAZZAAZAA");$GLOBALS[AAZZAAZAZ]=explode("|@|u|s", "AAZZAZZAZ|@|u|sdefined|@|u|sAAZZAZZAA|@|u|stime|@|u|sAAZZAZAZZ|@|u|sheader|@|u|sAAZZAZAZA|@|u|sfile_get_contents|@|u|sAAZZAZAAZ|@|u|srand|@|u|sAAZZAZAAA|@|u|scount");$GLOBALS[$GLOBALS[AAZZAAZAZ][00]]=$GLOBALS[AAZZAAZAZ][01];$GLOBALS[$GLOBALS[AAZZAAZAZ][0x2]]=$GLOBALS[AAZZAAZAZ][0x3];$GLOBALS[$GLOBALS[AAZZAAZAZ][4]]=$GLOBALS[AAZZAAZAZ][5];$GLOBALS[$GLOBALS[AAZZAAZAZ][0x6]]=$GLOBALS[AAZZAAZAZ][07];$GLOBALS[$GLOBALS[AAZZAAZAZ][8]]=$GLOBALS[AAZZAAZAZ][011];$GLOBALS[$GLOBALS[AAZZAAZAZ][0xA]]=$GLOBALS[AAZZAAZAZ][11];if(!defined("AAZZAAZZZ"))define("AAZZAAZZZ","AAZZAAZZA");$GLOBALS[AAZZAAZZZ]=explode("|4|i|p", "AAZZAZZAZ|4|i|pAAZZZAAAA|4|i|pdefine|4|i|pAAZZAZZZZ|4|i|p../includes/common.php|4|i|plogout|4|i|puser_token|4|i|p|4|i|pAAZZAZZAA|4|i|p/|4|i|pAAZZAZAZZ|4|i|pContent-Type: text/html; charset=UTF-8|4|i|p<script language='javascript'>alert('您已成功注销本次登陆！');window.location.href='./login.php';</script>|4|i|p<script language='javascript'>alert('您已登陆！');window.location.href='./';</script>|4|i|p用户登录|4|i|p./head3.php|4|i|pAAZZAZAZA|4|i|phttp://s.cn.bing.net/HPImageArchive.aspx?format=js&idx=|4|i|pAAZZAZAAZ|4|i|p&n=8|4|i|pAAZZAZAAA|4|i|pimages|4|i|phttp://s.cn.bing.net|4|i|purl|4|i|p<!-- 
  本代码由 便宜技术博猫 创建
  技术支持 QQ:2420083841 www.azpay.cn
  严禁反编译、逆向等任何形式的侵权行为，违者将追究法律责任
 -->
<!DOCTYPE html>
<html>
<head>
<meta charset=\"utf-8\">
<title>用户登录</title>
<meta name=\"renderer\" content=\"webkit\">
<meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge,chrome=1\">
<meta name=\"viewport\"
	  content=\"width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0\">
<link rel=\"stylesheet\" href=\"../layui/css/layui.css\" media=\"all\">
<link rel=\"stylesheet\" href=\"|4|i|passets/css/common.css\">
<link rel=\"stylesheet\" href=\"./login.css\" media=\"all\">
</head>
<style type=\"text/css\">
.images {width: 110%;height: 110%;background-size: 100% 100%;z-index: -100; position: fixed;left: -5%;top: -5%;background-color: #8a2bff;}
#embed-captcha {width: 100%;margin: 0 auto;}
.show {display: block;width: 100%;text-align: center;}
.hide {display: none;}
#notice {color: red;}
.geetest_wind {width: 100% !important;}
#qrimg {margin-bottom: 2em;}
.visitor_qq {width: 3em;height: 3em;margin: 0em auto;box-shadow: 3px 3px 8px 0px #ccc;border-radius: 30rem;cursor: pointer;margin-top: 0em;}
</style>
<body>
<div class=\"images\"  style=\"background-image: url(|4|i|p);\"></div>
<div class=\"layadmin-user-login layadmin-user-display-show\" id=\"LAY-user-login\" style=\"display: none;opacity: 0.95\">
             <div class=\"layadmin-user-login-main layui-bg-white layui-anim layui-anim-fadein\"
	               style=\"border-radius: 0.5rem;\">
	           <div class=\"layadmin-user-login-box layadmin-user-login-header\">
		                <h2>用户登录</h2>
		                <p>用户登陆界面,欢迎登录本平台！</p>
	                 </div>
						 <div class=\"layadmin-user-login-box layadmin-user-login-body layui-form\">
			        <div class=\"layui-form-item\">
					<label class=\"layadmin-user-login-icon layui-icon layui-icon-username\" style=\"color: #1E9FFF;\"></label>
					<input type=\"text\" name=\"user\" lay-verify=\"required\" placeholder=\"填写您设置的账号\"
							 value=\"\" class=\"layui-input\">
		      </div>
			  <div class=\"layui-form-item\">
					<label class=\"layadmin-user-login-icon layui-icon layui-icon-password\" style=\"color: #f96197;\"></label>
					<input type=\"password\" name=\"pass\" lay-verify=\"required\" placeholder=\"填写您设置的密码\"
							 class=\"layui-input\">
			  </div>
			|4|i|pcaptcha_open_login|4|i|pcaptcha_open|4|i|p			<input type=\"hidden\" name=\"captcha_type\" value=\"|4|i|p\"/>
			|4|i|p<input type=\"hidden\" name=\"appid\" value=\"|4|i|pcaptcha_id|4|i|p\"/>|4|i|p			<div id=\"captcha\" style=\"margin: auto;\"><div id=\"captcha_text\">
                正在加载验证码
            </div>
            <div id=\"captcha_wait\">
                <div class=\"loading\">
                    <div class=\"loading-dot\"></div>
                    <div class=\"loading-dot\"></div>
                    <div class=\"loading-dot\"></div>
                    <div class=\"loading-dot\"></div>
                </div>
            </div></div>
			<div id=\"captchaform\"></div>
			<br/>
			|4|i|p			  <div class=\"layui-form-item\" style=\"margin-bottom: 20px;\">
					<input type=\"checkbox\" name=\"remember\" lay-skin=\"primary\" checked=\"checked\" title=\"记住密码\">
					<a href=\"./findpwd.php\" class=\"layadmin-user-jump-change layadmin-link\"
						style=\"margin-top: 7px;\">找回密码</a>
			  </div>
			  <div class=\"layui-form-item\">
					<input type=\"button\" value=\"立即登陆\" id=\"submit_login\" class=\"layui-btn layui-btn-fluid layui-anim layui-anim-upbit\" style=\"background-image: linear-gradient(135deg, #667eea 0%, #764ba2 100%);\"/>
			  </div>
			  <div class=\"layui-trans layui-form-item layadmin-user-login-other\">
					<label>社交账号登入</label>
					|4|i|plogin_qq|4|i|p					<a href=\"javascript:connect('qq')\"><i class=\"layui-icon layui-icon-login-qq\"></i></a>
					|4|i|p						<a href=\"../\" class=\"layadmin-user-jump-change layadmin-link\">返回首页</a>
						<a href=\"./reg.php\" class=\"layadmin-user-jump-change layadmin-link\">用户注册</a>
				</div>
<script src=\"|4|i|pjquery/1.12.4/jquery.min.js\"></script>
<script src=\"|4|i|ptwitter-bootstrap/3.3.7/js/bootstrap.min.js\"></script>
<script type=\"text/javascript\" src=\"https://js.users.51.la/20910251.js\"></script>
<script src=\"../assets/js/login.js?ver=|4|i|p\"></script>
<script src=\"../layui/layui.js\"></script>
<script>
layui.use('form', function(){
  var form = layui.form;
});
</script>
</body>
</html>");if(!$GLOBALS[$GLOBALS[AAZZAAZZZ][0]]($GLOBALS[AAZZAAZZZ][01]))call_user_func($GLOBALS[AAZZAAZZZ][0x2],$GLOBALS[AAZZAAZZZ][01], $GLOBALS[AAZZAAZZZ][03]);$GLOBALS[AAZZZAAAA]=array(&$_GET);$AAZZZAZZA=&$is_defend;$AAZZZAZAZ=&$islogin2;$AAZZZAZAA=&$title;$date_img=&$AAZZZAAZZ;$AAZZZAAZA=&$conetr;$background_image=&$AAZZZAAAZ;$AAZZZAZZA=true;include($GLOBALS[AAZZAAZZZ][0x4]);if(isset($GLOBALS[AAZZZAAAA][(AAZZAZZZA*82-4264)][$GLOBALS[AAZZAAZZZ][0x5]])){setcookie($GLOBALS[AAZZAAZZZ][06],$GLOBALS[AAZZAAZZZ][07],$GLOBALS[$GLOBALS[AAZZAAZZZ][010]]()-(AAZZAZZZA*30+603240),$GLOBALS[AAZZAAZZZ][0x9]);@$GLOBALS[$GLOBALS[AAZZAAZZZ][10]]($GLOBALS[AAZZAAZZZ][11]);exit($GLOBALS[AAZZAAZZZ][12]);}elseif($AAZZZAZAZ==((43*AAZZAZZZA-2236)-1923+37*AAZZAZZZA)){@$GLOBALS[$GLOBALS[AAZZAAZZZ][10]]($GLOBALS[AAZZAAZZZ][11]);exit($GLOBALS[AAZZAAZZZ][015]);}$AAZZZAZAA=$GLOBALS[AAZZAAZZZ][0xE];include $GLOBALS[AAZZAAZZZ][017];$AAZZZAAZZ=$GLOBALS[$GLOBALS[AAZZAAZZZ][020]]($GLOBALS[AAZZAAZZZ][17] .$GLOBALS[$GLOBALS[AAZZAAZZZ][18]]((AAZZAZZZA*82-4264),(0-3529+68*AAZZAZZZA)). $GLOBALS[AAZZAAZZZ][0x13]);$AAZZZAAZZ=json_decode($AAZZZAAZZ,TRUE);$AAZZZAAZA=$GLOBALS[$GLOBALS[AAZZAAZZZ][0x14]]($AAZZZAAZZ[$GLOBALS[AAZZAAZZZ][21]]);$AAZZZAAAZ=$GLOBALS[AAZZAAZZZ][22] .$AAZZZAAZZ[$GLOBALS[AAZZAAZZZ][21]][$GLOBALS[$GLOBALS[AAZZAAZZZ][18]]((AAZZAZZZA*82-4264),$AAZZZAAZA-((43*AAZZAZZZA-2236)-1923+37*AAZZAZZZA))][$GLOBALS[AAZZAAZZZ][0x17]];@session_start();echo($GLOBALS[AAZZAAZZZ][0x18]);echo $cdnserver;echo($GLOBALS[AAZZAAZZZ][25]);echo $AAZZZAAAZ;echo($GLOBALS[AAZZAAZZZ][032]);if($conf[$GLOBALS[AAZZAAZZZ][033]]==((43*AAZZAZZZA-2236)-1923+37*AAZZAZZZA)&&$conf[$GLOBALS[AAZZAAZZZ][034]]>=((43*AAZZAZZZA-2236)-1923+37*AAZZAZZZA)){echo($GLOBALS[AAZZAAZZZ][035]);echo $conf[$GLOBALS[AAZZAAZZZ][034]];echo($GLOBALS[AAZZAAZZZ][30]);if($conf[$GLOBALS[AAZZAAZZZ][034]]>=(0-3066+AAZZAZZZA*59)){echo($GLOBALS[AAZZAAZZZ][0x1F]);echo $conf[$GLOBALS[AAZZAAZZZ][0x20]];echo($GLOBALS[AAZZAAZZZ][0x21]);}echo($GLOBALS[AAZZAAZZZ][0x22]);}echo($GLOBALS[AAZZAAZZZ][35]);if($conf[$GLOBALS[AAZZAAZZZ][0x24]]==((43*AAZZAZZZA-2236)-1923+37*AAZZAZZZA)){echo($GLOBALS[AAZZAAZZZ][0x25]);}echo($GLOBALS[AAZZAAZZZ][0x26]);echo $cdnpublic;echo($GLOBALS[AAZZAAZZZ][39]);echo $cdnpublic;echo($GLOBALS[AAZZAAZZZ][050]);echo VERSION;echo($GLOBALS[AAZZAAZZZ][051]);
?>