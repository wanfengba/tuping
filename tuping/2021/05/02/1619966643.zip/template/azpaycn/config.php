<?php
/*
 本代码由 便宜技术猫 创建
 创建时间 2021-5-1 8:16:30
 技术支持 QQ:2420083841 www.azpay.cn
 严禁反编译、逆向等任何形式的侵权行为，违者将追究法律责任
*/

if(!defined("AAZAAZA"))define("AAZAAZA","AAZAAAZ");$GLOBALS[AAZAAZA]=explode("|/|p|3", "AAZAZZZ");if(!defined("AAZAZZA"))define("AAZAZZA","AAZAZAZ");$GLOBALS[AAZAZZA]=explode("|t|f|o", "name|t|f|o简洁模板|t|f|oversion|t|f|ochdsn_cn_zuocew|t|f|o头像顶部背景|t|f|otype|t|f|oinput|t|f|onote|t|f|o如果喜欢头像顶部背景请留空,如需更换，请填写外链！");if(!defined($GLOBALS[AAZAAZA][0x0]))define($GLOBALS[AAZAAZA][0x0], ord(0));$AAZZAAZ=&$template_info;$template_settings=&$AAZZAAA;$AAZZAAZ=[$GLOBALS[AAZAZZA][0]=>$GLOBALS[AAZAZZA][0x1],$GLOBALS[AAZAZZA][02]=>3.0];$AAZZAAA=[$GLOBALS[AAZAZZA][03]=>[$GLOBALS[AAZAZZA][0]=>$GLOBALS[AAZAZZA][0x4],$GLOBALS[AAZAZZA][05]=>$GLOBALS[AAZAZZA][6],$GLOBALS[AAZAZZA][07]=>$GLOBALS[AAZAZZA][010]],];
?>