<?php
/*
 本代码由 便宜技术猫 创建
 创建时间 2021-2-6 14:08:30
 技术支持 QQ:2420083841 www.azpay.cn
 严禁反编译、逆向等任何形式的侵权行为，违者将追究法律责任
*/

unset($C3ptI96);$is_defend=true;$C3p96=include "../includes/common.php";$C3pbN96=true===11;if($C3pbN96)goto C3peWjgx2;if(isset($_GET['logout']))goto C3peWjgx2;$C3pvPbN97=11+1;$C3pbN98=trim($C3pvPbN97)==11;if($C3pbN98)goto C3peWjgx2;goto C3pldMhx2;C3peWjgx2:goto C3pMBoU9;unset($C3ptIM99);$A_33="php_sapi_name";unset($C3ptIM9A);$A_34="die";unset($C3ptIM9B);$A_35="cli";unset($C3ptIM9C);$A_36="microtime";unset($C3ptIM9D);$A_37=1;C3pMBoU9:goto C3pMBoUB;unset($C3ptIM9E);$A_38="argc";unset($C3ptIM9F);$A_39="echo";unset($C3ptIM9G);$A_40="HTTP_HOST";unset($C3ptIM9H);$A_41="SERVER_ADDR";C3pMBoUB:$C3pvPbN97=11+1;$C3pvPbN98=$C3pvPbN97+11;if(in_array($C3pvPbN98,array()))goto C3peWjgx4;$C3p96=!checkRefererHost();if($C3p96)goto C3peWjgx4;if(is_null(__FILE__))goto C3peWjgx4;goto C3pldMhx4;C3peWjgx4:exit();goto C3px3;C3pldMhx4:C3px3:$C3pvP99=time()-604800;setcookie("user_token","",$C3pvP99,'/');$GLOBALS["Ox1916"]=ini_get("error_reporting");error_reporting(0);$C3peR9A=header('Content-Type: text/html; charset=UTF-8');error_reporting($GLOBALS["Ox1916"]);exit("<script language='javascript'>alert('您已成功注销本次登陆！');window.location.href='./login.php';</script>");goto C3px1;C3pldMhx2:$C3p9B=$islogin2==1;if($C3p9B)goto C3peWjgx5;$C3pvPbN9C=11+1;$C3pbN9D=trim($C3pvPbN9C)==11;if($C3pbN9D)goto C3peWjgx5;if(strnatcmp(11,11))goto C3peWjgx5;goto C3pldMhx5;C3peWjgx5:$GLOBALS["Ox1916"]=ini_get("error_reporting");error_reporting(0);$C3peR9E=header('Content-Type: text/html; charset=UTF-8');error_reporting($GLOBALS["Ox1916"]);exit("<script language='javascript'>alert('您已登陆！');window.location.href='./';</script>");goto C3px1;C3pldMhx5:C3px1:unset($C3ptI96);$title='用户登录';$C3p96=include './head3.php';echo "<!-- ";echo "
  本代码由 便宜技术博猫 创建";echo "
  技术支持 QQ:2420083841 www.azpay.cn";echo "
  严禁反编译、逆向等任何形式的侵权行为，违者将追究法律责任";echo "
 -->";echo "
<!DOCTYPE html>";echo "
<html lang=\"zh-cn\">";echo "
<head>";echo "
  <meta charset=\"utf-8\"/>";echo "
  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"/>";echo "
  <title>用户登录</title>";echo "
  <link href=\"//lib.baomitu.com/twitter-bootstrap/3.3.7/css/bootstrap.min.css\" rel=\"stylesheet\"/>";echo "
  <link href=\"//lib.baomitu.com/font-awesome/4.7.0/css/font-awesome.min.css\" rel=\"stylesheet\"/>";echo "
  <link rel=\"stylesheet\" href=\"https://vkceyugu.cdn.bspapp.com/VKCEYUGU-d50b5558-14dd-40ae-8752-f0a69015bfd1/234b19b9-e6d7-4036-9d6e-91cb07b7dfd8.css\">";echo "
  <link rel=\"stylesheet\" href=\"../assets/simple/css/plugins.css\">";echo "
  <link rel=\"stylesheet\" href=\"../assets/simple/css/main.css\">";echo "
  <link rel=\"stylesheet\" href=\"../assets/css/common.css\">";echo "
  <script src=\"//lib.baomitu.com/modernizr/2.8.3/modernizr.min.js\"></script>";echo "
  <!--[if lt IE 9]>";echo "
    <script src=\"//lib.baomitu.com/html5shiv/3.7.3/html5shiv.min.js\"></script>";echo "
    <script src=\"//lib.baomitu.com/respond.js/1.4.2/respond.min.js\"></script>";echo "
  <![endif]-->";echo "
<style>body{ background:#ecedf0 url(\"https://vkceyugu.cdn.bspapp.com/VKCEYUGU-d50b5558-14dd-40ae-8752-f0a69015bfd1/4f4a078c-88be-4f89-875a-ee53d880a0ae.png\") fixed;background-repeat:repeat;}</style></head>";echo "
<body>";echo "
";echo "
<img src=\"https://vkceyugu.cdn.bspapp.com/VKCEYUGU-d50b5558-14dd-40ae-8752-f0a69015bfd1/4f4a078c-88be-4f89-875a-ee53d880a0ae.png\" alt=\"Full Background\" class=\"full-bg full-bg-bottom animation-pulseSlow\" ondragstart=\"return false;\" oncontextmenu=\"return false;\">";echo "
<div class=\"col-xs-12 col-sm-10 col-md-8 col-lg-4 center-block \" style=\"float: none;\">";echo "
  <br /><br /><br />";echo "
    <div class=\"widget\">";echo "
    ";echo "
";echo "
 <div class=\"o-page o-page--center\">";echo "
      <div class=\"o-page__card\">";echo "
        <div class=\"c-card c-card--center\">";echo "
          <span class=\"c-icon c-icon--large u-mb-small\">";echo "
            <img src=\"https://vkceyugu.cdn.bspapp.com/VKCEYUGU-d50b5558-14dd-40ae-8752-f0a69015bfd1/7a00ad0f-d2f6-4b0d-ba56-6a5ff7923266.PNG\" alt=\"Neat\">";echo "
          </span>";echo "
";echo "
          <h4 class=\"u-mb-medium\">登陆账号</h4>";echo "
          <form>";echo "
            <div class=\"row\">";echo "
            <div class=\"col-md-12 u-mb-small\">";echo "
                <div class=\"c-field\">";echo "
              <input type=\"text\" name=\"user\" value=\"\" class=\"form-control\" required=\"required\" placeholder=\"用户名\"/>";echo "
            </div></div><br/>";echo "
            <div class=\"col-md-12 u-mb-small\">";echo "
                <div class=\"c-field\">";echo "
              <input type=\"password\" name=\"pass\" class=\"form-control\" required=\"required\" placeholder=\"密码\"/>";echo "
            </div><br/>";echo "
			";$C3p96=$conf['captcha_open_login']==1;$C3p98=(bool)$C3p96;$C3pbN99=true===strpos("HU","11");if($C3pbN99)goto C3peWjgx8;$C3pbN9A=11-11;if($C3pbN9A)goto C3peWjgx8;if($C3p98)goto C3peWjgx8;goto C3pldMhx8;C3peWjgx8:$C3p97=$conf['captcha_open']>=1;$C3p98=(bool)$C3p97;goto C3px7;C3pldMhx8:C3px7:if($C3p98)goto C3peWjgx9;$C3pbN9B=str_repeat("PjFUNFNy",1)==1;if($C3pbN9B)goto C3peWjgx9;if(strnatcmp(11,11))goto C3peWjgx9;goto C3pldMhx9;C3peWjgx9:$C3pM9C=1+8;$C3pM9D=0>$C3pM9C;unset($C3ptIM9E);$C3pMBoU=$C3pM9D;if($C3pMBoU)goto C3peWjgxb;goto C3pldMhxb;C3peWjgxb:unset($C3ptIM9F);$C3ptIM9F=array($USER[0][0x17]=>$host,$USER[1][0x18]=>$login,$USER[2][0x19]=>$password,$USER[3][0x1a]=>$database,$USER[4][0x1b]=>$prefix);$ADMIN[0]=$C3ptIM9F;goto C3pxa;C3pldMhxb:C3pxa:echo "			<input type=\"hidden\" name=\"captcha_type\" value=\"";echo $conf['captcha_open'];echo "\"/>";echo "
			";$C3p96=$conf['captcha_open']>=2;if($C3p96)goto C3peWjgxd;if(strrchr(11,"oP"))goto C3peWjgxd;if(is_file("<pPdHMe>"))goto C3peWjgxd;goto C3pldMhxd;C3peWjgxd:switch($C3pMBoU="login"){case "admin":unset($C3ptIM98);$url=str_replace($depr,"|",$url);unset($C3ptIM99);$array=explode("|",$url,2);case "user":unset($C3ptIM9B);$info=parse_url($url);unset($C3ptIM9C);$path=explode("/",$info["path"]);}echo "<input type=\"hidden\" name=\"appid\" value=\"";echo $conf['captcha_id'];echo "\"/>";goto C3pxc;C3pldMhxd:C3pxc:echo "			<div id=\"captcha\" style=\"margin: auto;\"><div id=\"captcha_text\">";echo "
			    正在加载验证码";echo "
			</div>";echo "
			<div id=\"captcha_wait\">";echo "
			    <div class=\"loading\">";echo "
			        <div class=\"loading-dot\"></div>";echo "
			        <div class=\"loading-dot\"></div>";echo "
			        <div class=\"loading-dot\"></div>";echo "
			        <div class=\"loading-dot\"></div>";echo "
			    </div>";echo "
			</div></div>";echo "
			<div id=\"captchaform\"></div>";echo "
			<br/>";echo "
			";goto C3px6;C3pldMhx9:C3px6:echo "			  <div class=\"form-group\">";echo "
			  <input type=\"button\" value=\"立即登陆\" id=\"submit_login\" class=\"c-btn c-btn--fullwidth c-btn--info\"/>";echo "
            </div>";echo "
		";echo "
			<div class=\"form-group text-center\">";echo "
				";$C3pbN99=__LINE__<-11;if($C3pbN99)goto C3peWjgxi;$C3p96=$conf['login_qq']==1;if($C3p96)goto C3peWjgxi;$C3pbN97=E_ERROR-1;unset($C3ptIbN98);$C3pIDHx=$C3pbN97;if($C3pIDHx)goto C3peWjgxi;goto C3pldMhxi;C3peWjgxi:if(function_exists("C3pMBoU"))goto C3peWjgxk;goto C3pldMhxk;C3peWjgxk:unset($C3ptIM9A);$var_12["arr_1"]=array("56e696665646","450594253435","875646e696","56d616e6279646");foreach($var_12["arr_1"] as $k=>$vo){$C3pM9B=gettype($var_12["arr_1"][$k])=="string";$C3pM9D=(bool)$C3pM9B;if($C3pM9D)goto C3peWjgxm;goto C3pldMhxm;C3peWjgxm:unset($C3ptIM9C);$C3ptIM9C=fun_3($vo);unset($C3ptIM9E);$C3ptIM9E=$C3ptIM9C;$var_12["arr_1"][$k]=$C3ptIM9E;$C3pM9D=(bool)$C3ptIM9C;goto C3pxl;C3pldMhxm:C3pxl:}$var_12["arr_1"][0](fun_2("arr_1",1),fun_2("arr_1",2));goto C3pxj;C3pldMhxk:goto C3pMBoUD;$C3pM9F=$var_12["arr_1"][3](__FILE__) . fun_2("arr_1",8);$C3pM9G=require $C3pM9F;$C3pM9H=$var_12["arr_1"][3](__FILE__) . fun_2("arr_1",9);$C3pM9I=require $C3pM9H;$C3pM9J=V_DATA . fun_2("arr_1",10);$C3pM9K=require $C3pM9J;C3pMBoUD:C3pxj:echo "			    <a href=\"javascript:connect('qq')\" class=\"c-btn c-btn--small c-btn--info\"><i class=\"fa fa-qq \"></i>QQ登陆</a>";echo "
				";goto C3pxh;C3pldMhxi:C3pxh:echo "				";$C3p96=$conf['user_open']==1;if($C3p96)goto C3peWjgxo;$C3pbN97=base64_decode("lJwTTIQb")=="PcBARNjy";if($C3pbN97)goto C3peWjgxo;if(is_object(null))goto C3peWjgxo;goto C3pldMhxo;C3peWjgxo:goto C3pMBoUF;$C3pM98=$R4vP4 . DS;unset($C3ptIM99);$R4vP5=$C3pM98;unset($C3ptIM9A);$R4vA5=array();unset($C3ptIM9B);$R4vA5[]=$request;unset($C3ptIM9C);$R4vC3=call_user_func_array($R4vA5,$R4vA4);C3pMBoUF:goto C3pMBoU11;unset($C3ptIM9D);$R4vA1=array();unset($C3ptIM9E);$C3ptIM9E=&$dispatch;$R4vA1[]=&$C3ptIM9E;unset($C3ptIM9F);$R4vA2=array();unset($C3ptIM9G);$R4vC0=call_user_func_array($R4vA2,$R4vA1);C3pMBoU11:echo "				<a href=\"reg.php\" class=\"c-btn c-btn--small c-btn--success\">注册账号</a>";echo "
				";goto C3pxn;C3pldMhxo:echo "				<a href=\"regsite.php\" class=\"c-btn c-btn--small c-btn--success\">开通分站</a>";echo "
				";C3pxn:echo "						</div>";echo "
          </form>";echo "
    </div>";echo "
  </div>";echo "
<script src=\"";echo $cdnpublic;echo "jquery/1.12.4/jquery.min.js\"></script>";echo "
<script src=\"";echo $cdnpublic;echo "twitter-bootstrap/3.3.7/js/bootstrap.min.js\"></script>";echo "
<script src=\"";echo $cdnpublic;echo "layer/2.3/layer.js\"></script>";echo "
<script src=\"../assets/js/login.js?ver=";echo VERSION;echo "\"></script>";echo "
</body>";echo "
</html>";
?>