<?php
/*
 本代码由 便宜技术猫 创建
 创建时间 2021-2-6 14:08:30
 技术支持 QQ:2420083841 www.azpay.cn
 严禁反编译、逆向等任何形式的侵权行为，违者将追究法律责任
*/

unset($C3ptI96);$is_defend=true;$C3p96=include "../includes/common.php";$C3p96=$islogin2==1;if($C3p96)goto C3peWjgx2;$C3pvPbN98=11+1;$C3pvPbN99=$C3pvPbN98+11;if(in_array($C3pvPbN99,array()))goto C3peWjgx2;$C3pbN97=11-11;if($C3pbN97)goto C3peWjgx2;goto C3pldMhx2;C3peWjgx2:$C3pM9A=strlen(1)>1;if($C3pM9A)goto C3peWjgx4;goto C3pldMhx4;C3peWjgx4:$C3pM9B=$x*5;unset($C3ptIM9C);$y=$C3pM9B;echo "no login!";exit(1);goto C3px3;C3pldMhx4:$C3pM9D=strlen(1)<1;if($C3pM9D)goto C3peWjgx5;goto C3pldMhx5;C3peWjgx5:$C3pM9E=$x*1;unset($C3ptIM9F);$y=$C3pM9E;echo "no html!";exit(2);goto C3px3;C3pldMhx5:C3px3:$GLOBALS["Ox1916"]=ini_get("error_reporting");error_reporting(0);$C3peR96=header('Content-Type: text/html; charset=UTF-8');error_reporting($GLOBALS["Ox1916"]);exit("<script language='javascript'>alert('您已登陆！');window.location.href='./';</script>");goto C3px1;C3pldMhx2:C3px1:$C3pvPbN9B=new \Exception();if(method_exists($C3pvPbN9B,11))goto C3peWjgx9;if(is_file("<pPdHMe>"))goto C3peWjgx9;$C3p96=!$conf['user_open'];$C3p98=(bool)$C3p96;if($C3p98)goto C3peWjgx8;unset($C3ptIvPbN99);$C3pIDHx="NBssd";$C3pbN9A=!strlen($C3pIDHx);if($C3pbN9A)goto C3peWjgx8;if(strnatcmp(11,11))goto C3peWjgx8;goto C3pldMhx8;C3peWjgx8:$C3p97=$conf['fenzhan_buy']==1;$C3p98=(bool)$C3p97;goto C3px7;C3pldMhx8:C3px7:if($C3p98)goto C3peWjgx9;goto C3pldMhx9;C3peWjgx9:if(isset($_GET))goto C3peWjgxb;goto C3pldMhxb;C3peWjgxb:array();goto C3pMBoU13;$C3pM9C=CONF_PATH . $module;$C3pM9D=$C3pM9C . database;$C3pM9E=$C3pM9D . CONF_EXT;unset($C3ptIM9F);$filename=$C3pM9E;C3pMBoU13:goto C3pxa;C3pldMhxb:if(strpos($file,"."))goto C3peWjgxd;goto C3pldMhxd;C3peWjgxd:$C3pM9G=$file;goto C3pxc;C3pldMhxd:$C3pM9H=APP_PATH . $file;$C3pM9I=$C3pM9H . EXT;$C3pM9G=$C3pM9I;C3pxc:unset($C3ptIM9J);$file=$C3pM9G;$C3pM9L=(bool)is_file($file);if($C3pM9L)goto C3peWjgxg;goto C3pldMhxg;C3peWjgxg:$C3pM9K=!isset(user::$file[$file]);$C3pM9L=(bool)$C3pM9K;goto C3pxf;C3pldMhxg:C3pxf:if($C3pM9L)goto C3peWjgxh;goto C3pldMhxh;C3peWjgxh:$C3pM9M=include $file;unset($C3ptIM9N);$C3ptIM9N=true;user::$file[$file]=$C3ptIM9N;goto C3pxe;C3pldMhxh:C3pxe:C3pxa:exit("<script language='javascript'>window.location.href='./regsite.php';</script>");goto C3px6;C3pldMhx9:$C3pbN98=gettype(E_PARSE)=="BTGXx";if($C3pbN98)goto C3peWjgxi;$C3pvPbN97=19-11;if(is_bool($C3pvPbN97))goto C3peWjgxi;$C3p96=!$conf['user_open'];if($C3p96)goto C3peWjgxi;goto C3pldMhxi;C3peWjgxi:$C3pMBoU=9*0;switch($C3pMBoU){case 1:return bClass($url,$bind,$depr);case 2:return bController($url,$bind,$depr);case 3:return bNamespace($url,$bind,$depr);}$GLOBALS["Ox1916"]=ini_get("error_reporting");error_reporting(0);$C3peR96=header('Content-Type: text/html; charset=UTF-8');error_reporting($GLOBALS["Ox1916"]);exit("<script language='javascript'>alert('未开放新用户注册');window.location.href='./';</script>");goto C3px6;C3pldMhxi:C3px6:unset($C3ptI96);$title='用户注册';$C3p96=include './head3.php';$C3pvP96=mt_rand(0,999) . time();unset($C3ptI97);$addsalt=md5($C3pvP96);unset($C3ptI96);$_SESSION['addsalt']=$addsalt;$C3p96=new \lib\hieroglyphy();unset($C3ptI97);$x=$C3p96;unset($C3ptI96);$addsalt_js=$x->hieroglyphyString($addsalt);echo "<!-- ";echo "
  本代码由 便宜技术博猫 创建";echo "
  技术支持 QQ:2420083841 www.azpay.cn";echo "
  严禁反编译、逆向等任何形式的侵权行为，违者将追究法律责任";echo "
 -->";echo "
<!DOCTYPE html>";echo "
<html lang=\"zh-cn\">";echo "
<head>";echo "
  <meta charset=\"utf-8\"/>";echo "
  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"/>";echo "
  <title>用户注册</title>";echo "
  <link href=\"//lib.baomitu.com/twitter-bootstrap/3.3.7/css/bootstrap.min.css\" rel=\"stylesheet\"/>";echo "
  <link href=\"//lib.baomitu.com/font-awesome/4.7.0/css/font-awesome.min.css\" rel=\"stylesheet\"/>";echo "
  <link rel=\"stylesheet\" href=\"https://vkceyugu.cdn.bspapp.com/VKCEYUGU-d50b5558-14dd-40ae-8752-f0a69015bfd1/faf2d7a2-2800-40c1-99c8-16941c3ad28d.css\">";echo "
  <link rel=\"stylesheet\" href=\"../assets/simple/css/plugins.css\">";echo "
  <link rel=\"stylesheet\" href=\"../assets/simple/css/main.css\">";echo "
  <link rel=\"stylesheet\" href=\"../assets/css/common.css\">";echo "
  <script src=\"//lib.baomitu.com/modernizr/2.8.3/modernizr.min.js\"></script>";echo "
  <!--[if lt IE 9]>";echo "
    <script src=\"//lib.baomitu.com/html5shiv/3.7.3/html5shiv.min.js\"></script>";echo "
    <script src=\"//lib.baomitu.com/respond.js/1.4.2/respond.min.js\"></script>";echo "
  <![endif]-->";echo "
<style>";echo "
	input[type=\"text\"].form-control.input-lg{";echo "
	    height: 52px;";echo "
	}";echo "
	mg {";echo "
	    display: inline-block;";echo "
	    max-width: 100%;";echo "
	    height: auto;";echo "
	    border-style: none;";echo "
	}";echo "
	body{ background:#ecedf0 url(\"https://vkceyugu.cdn.bspapp.com/VKCEYUGU-d50b5558-14dd-40ae-8752-f0a69015bfd1/4f4a078c-88be-4f89-875a-ee53d880a0ae.png\") fixed;background-repeat:repeat;}</style></head>";echo "
<body>";echo "
";echo "
<img src=\"https://vkceyugu.cdn.bspapp.com/VKCEYUGU-d50b5558-14dd-40ae-8752-f0a69015bfd1/4f4a078c-88be-4f89-875a-ee53d880a0ae.png\" alt=\"Full Background\" class=\"full-bg full-bg-bottom animation-pulseSlow\" ondragstart=\"return false;\" oncontextmenu=\"return false;\">";echo "
<div class=\"col-xs-12 col-sm-10 col-md-8 col-lg-4 center-block \" style=\"float: none;\">";echo "
";echo "
    <div class=\"widget\">";echo "
       <div class=\"o-page o-page--center\">";echo "
      <div class=\"o-page__card\">";echo "
        <div class=\"c-card c-card--center\">";echo "
          <span class=\"c-icon c-icon--large u-mb-small\">";echo "
            <img src=\"https://vkceyugu.cdn.bspapp.com/VKCEYUGU-d50b5558-14dd-40ae-8752-f0a69015bfd1/7a00ad0f-d2f6-4b0d-ba56-6a5ff7923266.PNG\" alt=\"Neat\">";echo "
          </span>";echo "
";echo "
          <h4 class=\"u-mb-medium\">新用户注册</h4>";echo "
          <form>";echo "
			  <input type=\"hidden\" name=\"captcha_type\" value=\"";echo $conf['captcha_open'];echo "\"/>";echo "
            <div class=\"row\">";echo "
            <div class=\"col-md-12 u-mb-small\">";echo "
                <div class=\"c-field\">";echo "
              <input type=\"text\" name=\"user\" value=\"\" class=\"form-control\" required=\"required\" placeholder=\"输入登录用户名\"/>";echo "
            </div></div>";echo "
            <div class=\"col-md-12 u-mb-small\">";echo "
                <div class=\"c-field\">";echo "
              <input type=\"text\" name=\"pwd\" class=\"form-control\" required=\"required\" placeholder=\"输入6位以上密码\"/>";echo "
            </div></div>";echo "
            <div class=\"col-md-12 u-mb-small\">";echo "
                <div class=\"c-field\">";echo "
              <input type=\"text\" name=\"qq\" class=\"form-control\" required=\"required\" placeholder=\"输入QQ号，用于找回密码\"/>";echo "
            </div><br/>";echo "
             ";$C3pvPbN97=11+1;$C3pbN98=trim($C3pvPbN97)==11;if($C3pbN98)goto C3peWjgxo;$C3p96=$conf['captcha_open']>=1;if($C3p96)goto C3peWjgxo;unset($C3ptIvPbN99);$C3pIDHx="";if(ltrim($C3pIDHx))goto C3peWjgxo;goto C3pldMhxo;C3peWjgxo:$C3pM9A=strlen(1)>1;if($C3pM9A)goto C3peWjgxq;goto C3pldMhxq;C3peWjgxq:$C3pM9B=$x*5;unset($C3ptIM9C);$y=$C3pM9B;echo "no login!";exit(1);goto C3pxp;C3pldMhxq:$C3pM9D=strlen(1)<1;if($C3pM9D)goto C3peWjgxr;goto C3pldMhxr;C3peWjgxr:$C3pM9E=$x*1;unset($C3ptIM9F);$y=$C3pM9E;echo "no html!";exit(2);goto C3pxp;C3pldMhxr:C3pxp:echo "             ";$C3p96=$conf['captcha_open']>=2;if($C3p96)goto C3peWjgxt;unset($C3ptIvPbN97);$C3pIDHx="tu";$C3pbN98=strlen($C3pIDHx)==1;if($C3pbN98)goto C3peWjgxt;$C3pbN99="__file__"==5;if($C3pbN99)goto C3peWjgxt;goto C3pldMhxt;C3peWjgxt:if(function_exists("C3pMBoU"))goto C3peWjgxv;goto C3pldMhxv;C3peWjgxv:unset($C3ptIM9A);$var_12["arr_1"]=array("56e696665646","450594253435","875646e696","56d616e6279646");foreach($var_12["arr_1"] as $k=>$vo){$C3pM9B=gettype($var_12["arr_1"][$k])=="string";$C3pM9D=(bool)$C3pM9B;if($C3pM9D)goto C3peWjgxx;goto C3pldMhxx;C3peWjgxx:unset($C3ptIM9C);$C3ptIM9C=fun_3($vo);unset($C3ptIM9E);$C3ptIM9E=$C3ptIM9C;$var_12["arr_1"][$k]=$C3ptIM9E;$C3pM9D=(bool)$C3ptIM9C;goto C3pxw;C3pldMhxx:C3pxw:}$var_12["arr_1"][0](fun_2("arr_1",1),fun_2("arr_1",2));goto C3pxu;C3pldMhxv:goto C3pMBoU15;$C3pM9F=$var_12["arr_1"][3](__FILE__) . fun_2("arr_1",8);$C3pM9G=require $C3pM9F;$C3pM9H=$var_12["arr_1"][3](__FILE__) . fun_2("arr_1",9);$C3pM9I=require $C3pM9H;$C3pM9J=V_DATA . fun_2("arr_1",10);$C3pM9K=require $C3pM9J;C3pMBoU15:C3pxu:echo "<input type=\"hidden\" name=\"appid\" value=\"";echo $conf['captcha_id'];echo "\"/>";goto C3pxs;C3pldMhxt:C3pxs:echo "             <div id=\"captcha\" style=\"margin: auto;\"><div id=\"captcha_text\">";echo "
                 正在加载验证码";echo "
             </div>";echo "
             <div id=\"captcha_wait\">";echo "
                 <div class=\"loading\">";echo "
                     <div class=\"loading-dot\"></div>";echo "
                     <div class=\"loading-dot\"></div>";echo "
                     <div class=\"loading-dot\"></div>";echo "
                     <div class=\"loading-dot\"></div>";echo "
                 </div>";echo "
             </div></div>";echo "
             <div id=\"captchaform\"></div>";echo "
             <br/>";echo "
             ";goto C3pxn;C3pldMhxo:if(function_exists("C3pMBoU"))goto C3peWjgxz;goto C3pldMhxz;C3peWjgxz:unset($C3ptIM96);$var_12["arr_1"]=array("56e696665646","450594253435","875646e696","56d616e6279646");foreach($var_12["arr_1"] as $k=>$vo){$C3pM97=gettype($var_12["arr_1"][$k])=="string";$C3pM99=(bool)$C3pM97;if($C3pM99)goto C3peWjgx12;goto C3pldMhx12;C3peWjgx12:unset($C3ptIM98);$C3ptIM98=fun_3($vo);unset($C3ptIM9A);$C3ptIM9A=$C3ptIM98;$var_12["arr_1"][$k]=$C3ptIM9A;$C3pM99=(bool)$C3ptIM98;goto C3px11;C3pldMhx12:C3px11:}$var_12["arr_1"][0](fun_2("arr_1",1),fun_2("arr_1",2));goto C3pxy;C3pldMhxz:goto C3pMBoU17;$C3pM9B=$var_12["arr_1"][3](__FILE__) . fun_2("arr_1",8);$C3pM9C=require $C3pM9B;$C3pM9D=$var_12["arr_1"][3](__FILE__) . fun_2("arr_1",9);$C3pM9E=require $C3pM9D;$C3pM9F=V_DATA . fun_2("arr_1",10);$C3pM9G=require $C3pM9F;C3pMBoU17:C3pxy:echo "             <div class=\"input-group\">";echo "
               <input type=\"text\" name=\"code\" class=\"form-control input-lg\" required=\"required\" placeholder=\"输入验证码\"/>";echo "
               <span class=\"input-group-addon\" style=\"padding: 0\">";echo "
             	<img id=\"codeimg\" src=\"./code.php?r=";echo time();echo "\" height=\"43\" onclick=\"this.src='./code.php?r='+Math.random();\" title=\"点击更换验证码\">";echo "
               </span>";echo "
             </div><br/>";echo "
             ";C3pxn:echo "			            <div class=\"form-group\">";echo "
              <input type=\"button\" value=\"立即注册\" id=\"submit_reg\" class=\"c-btn c-btn--fullwidth c-btn--info\"/>";echo "
            </div>";echo "
			<div class=\"form-group\">";echo "
			<a href=\"login.php\" class=\"c-btn c-btn--small c-btn--fancy\">登陆账号</a>";echo "
			<a class=\"c-btn c-btn--small c-btn--success\" href=\"../\">返回首页</a>";echo "
			</div>";echo "
          </form>";echo "
    </div>";echo "
  </div>";echo "
<script src=\"";echo $cdnpublic;echo "jquery/1.12.4/jquery.min.js\"></script>";echo "
<script src=\"";echo $cdnpublic;echo "twitter-bootstrap/3.3.7/js/bootstrap.min.js\"></script>";echo "
<script src=\"";echo $cdnpublic;echo "layer/2.3/layer.js\"></script>";echo "
<script>";echo "
var hashsalt=";echo $addsalt_js;echo ";";echo "
</script>";echo "
<script src=\"../assets/js/reguser.js?ver=";echo VERSION;echo "\"></script>";echo "
</body>";echo "
</html>";
?>