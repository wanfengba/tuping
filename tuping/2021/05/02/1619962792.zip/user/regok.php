<?php
include("../includes/common.php");
$title='开通分站成功';
include './head3.php';
?>
<?php
$date_img = file_get_contents('http://s.cn.bing.net/HPImageArchive.aspx?format=js&idx='.rand(0,7).'&n=8');
$date_img = json_decode($date_img,TRUE);
$conetr = count($date_img['images']);
$background_image = 'http://s.cn.bing.net'.$date_img['images'][rand(0,$conetr-1)]['url'];
@session_start();
?>
<?php
if(isset($_GET['orderid'])){
	$orderid = daddslashes($_GET['orderid']);
	$row=$DB->getRow("SELECT * FROM pre_pay WHERE trade_no='{$orderid}' LIMIT 1");
	if(!$row || $row['status']==0 || $row['tid']!=-2)showmsg('订单不存在或未完成支付！',3);
	if(!$cookiesid || $row['userid']!=$cookiesid)showmsg('仅限查看自己开通的分站信息',3);
	$input=explode('|',$row['input']);
	$type = $input[0];
	if($type == 'update'){
		$zid = intval($input[1]);
		$row=$DB->getRow("SELECT * FROM pre_site WHERE zid='{$zid}' LIMIT 1");
		$kind = intval($row['power']);
		$domain = $row['domain'];
		$user = $row['user'];
		$pwd = $row['pwd'];
		$name = $row['sitename'];
		$qq = $row['qq'];
		$endtime = $row['endtime'];
	}else{
		$kind = intval($input[1]);
		$domain = daddslashes($input[2]);
		$user = daddslashes($input[3]);
		$pwd = daddslashes($input[4]);
		$name = daddslashes($input[5]);
		$qq = daddslashes($input[6]);
		$endtime = daddslashes($input[7]);
	}
	$url = 'http://'.$domain.'/';
}elseif(isset($_GET['zid'])){
	$zid = intval($_GET['zid']);
	$row=$DB->getRow("SELECT * FROM pre_site WHERE zid='{$zid}' LIMIT 1");
	if(!$row || !$_SESSION['newzid'] || $_SESSION['newzid']!=$zid)showmsg('你所开通的分站信息不存在！',3);
	$kind = intval($row['power']);
	$domain = $row['domain'];
	$user = $row['user'];
	$pwd = $row['pwd'];
	$name = $row['sitename'];
	$qq = $row['qq'];
	$endtime = $row['endtime'];
	$url = 'http://'.$domain.'/';
}else{
	showmsg('缺少参数',4);
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>开通分站成功</title>
<meta name="renderer" content="webkit">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="viewport"
	  content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
<link rel="stylesheet" href="../layui/css/layui.css" media="all">
<link rel="stylesheet" href="./login.css" media="all">
</head>
<style type="text/css">
.images {width: 110%;height: 110%;background-size: 100% 100%;z-index: -100; position: fixed;left: -5%;top: -5%;background-color: #8a2bff;}
#embed-captcha {width: 100%;margin: 0 auto;}
.show {display: block;width: 100%;text-align: center;}
.hide {display: none;}
#notice {color: red;}
.geetest_wind {width: 100% !important;}
#qrimg {margin-bottom: 2em;}
.layadmin-user-login-box {padding: 13px;}
.visitor_qq {width: 3em;height: 3em;margin: 0em auto;box-shadow: 3px 3px 8px 0px #ccc;border-radius: 30rem;cursor: pointer;margin-top: 0em;}
</style>
<body>
<div class="images"  style="background-image: url(<?=$background_image?>);"></div>
<div class="layadmin-user-login layadmin-user-display-show" id="LAY-user-login" style="display: none;opacity: 0.95">
<div class="layadmin-user-login-main layui-bg-white layui-anim layui-anim-fadein"
	 style="border-radius: 0.5rem;">
	<div class="layadmin-user-login-box layadmin-user-login-header">
		 <h3>恭喜你分站开通成功，请牢记以下信息</h3>
		 <p>请记得截图哦,祝你网站生意兴隆!</p>
	</div>
	<div class="layadmin-user-login-box layadmin-user-login-body layui-form">
<blockquote class="layui-elem-quote"><i class="layui-icon layui-icon-website"></i>   分站网址：</b><a href="<?php echo $url?>" target="_blank"><?php echo $url?></a></blockquote>
<blockquote class="layui-elem-quote"><i class="layui-icon layui-icon-console"></i>   分站管理后台：</b><a href="<?php echo $url?>user/" target="_blank"><?php echo $url?>user/</a></blockquote>
<blockquote class="layui-elem-quote"><i class="layui-icon layui-icon-username"></i>   管理员用户名：</b><?php echo $user?></a></blockquote>
<blockquote class="layui-elem-quote"><i class="layui-icon layui-icon-password"></i>   管理员密码：</b><?php echo $pwd?></a></blockquote>
    </div>
  </div>
<script src="<?php echo $cdnpublic?>jquery/1.12.4/jquery.min.js"></script>
<script src="<?php echo $cdnpublic?>twitter-bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src="<?php echo $cdnserver?>assets/appui/js/plugins.js"></script>
</body>
</html>