<?php
$is_defend=true;
include("../includes/common.php");
if(isset($_GET['logout'])){
	setcookie("user_token", "", time() - 604800, '/');
	@header('Content-Type: text/html; charset=UTF-8');
	exit("<script language='javascript'>alert('您已成功注销本次登陆！');window.location.href='./login.php';</script>");
}elseif($islogin2==1){
	@header('Content-Type: text/html; charset=UTF-8');
	exit("<script language='javascript'>alert('您已登陆！');window.location.href='./';</script>");
}
$title='用户登录';
include './head3.php';
?>
<?php
$date_img = file_get_contents('http://s.cn.bing.net/HPImageArchive.aspx?format=js&idx='.rand(0,7).'&n=8');
$date_img = json_decode($date_img,TRUE);
$conetr = count($date_img['images']);
$background_image = 'http://s.cn.bing.net'.$date_img['images'][rand(0,$conetr-1)]['url'];
@session_start();
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>用户登录</title>
<meta name="renderer" content="webkit">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="viewport"
	  content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
<link rel="stylesheet" href="../layui/css/layui.css" media="all">
<link rel="stylesheet" href="<?php echo $cdnserver?>assets/css/common.css">
<link rel="stylesheet" href="./login.css" media="all">
</head>
<style type="text/css">
.images {width: 110%;height: 110%;background-size: 100% 100%;z-index: -100; position: fixed;left: -5%;top: -5%;background-color: #8a2bff;}
#embed-captcha {width: 100%;margin: 0 auto;}
.show {display: block;width: 100%;text-align: center;}
.hide {display: none;}
#notice {color: red;}
.geetest_wind {width: 100% !important;}
#qrimg {margin-bottom: 2em;}
.visitor_qq {width: 3em;height: 3em;margin: 0em auto;box-shadow: 3px 3px 8px 0px #ccc;border-radius: 30rem;cursor: pointer;margin-top: 0em;}
</style>
<body>
<div class="images"  style="background-image: url(<?=$background_image?>);"></div>
<div class="layadmin-user-login layadmin-user-display-show" id="LAY-user-login" style="display: none;opacity: 0.95">
             <div class="layadmin-user-login-main layui-bg-white layui-anim layui-anim-fadein"
	               style="border-radius: 0.5rem;">
	           <div class="layadmin-user-login-box layadmin-user-login-header">
		                <h2>用户登录</h2>
		                <p>用户登陆界面,欢迎登录本平台！</p>
	                 </div>
						 <div class="layadmin-user-login-box layadmin-user-login-body layui-form">
			        <div class="layui-form-item">
					<label class="layadmin-user-login-icon layui-icon layui-icon-username" style="color: #1E9FFF;"></label>
					<input type="text" name="user" lay-verify="required" placeholder="填写您设置的账号"
							 value="" class="layui-input">
		      </div>
			  <div class="layui-form-item">
					<label class="layadmin-user-login-icon layui-icon layui-icon-password" style="color: #f96197;"></label>
					<input type="password" name="pass" lay-verify="required" placeholder="填写您设置的密码"
							 class="layui-input">
			  </div>
			<?php if($conf['captcha_open_login']==1 && $conf['captcha_open']>=1){?>
			<input type="hidden" name="captcha_type" value="<?php echo $conf['captcha_open']?>"/>
			<?php if($conf['captcha_open']>=2){?><input type="hidden" name="appid" value="<?php echo $conf['captcha_id']?>"/><?php }?>
			<div id="captcha" style="margin: auto;"><div id="captcha_text">
                正在加载验证码
            </div>
            <div id="captcha_wait">
                <div class="loading">
                    <div class="loading-dot"></div>
                    <div class="loading-dot"></div>
                    <div class="loading-dot"></div>
                    <div class="loading-dot"></div>
                </div>
            </div></div>
			<div id="captchaform"></div>
			<br/>
			<?php }?>
			  <div class="layui-form-item" style="margin-bottom: 20px;">
					<input type="checkbox" name="remember" lay-skin="primary" checked="checked" title="记住密码">
					<a href="./findpwd.php" class="layadmin-user-jump-change layadmin-link"
						style="margin-top: 7px;">找回密码</a>
			  </div>
			  <div class="layui-form-item">
					<input type="button" value="立即登陆" id="submit_login" class="layui-btn layui-btn-fluid layui-anim layui-anim-upbit" style="background-image: linear-gradient(135deg, #667eea 0%, #764ba2 100%);"/>
			  </div>
			  <div class="layui-trans layui-form-item layadmin-user-login-other">
					<label>社交账号登入</label>
					<?php if($conf['login_qq']==1){?>
					<a href="javascript:connect('qq')"><i class="layui-icon layui-icon-login-qq"></i></a>
					<?php }?>
						<a href="../" class="layadmin-user-jump-change layadmin-link">返回首页</a>
						<a href="./reg.php" class="layadmin-user-jump-change layadmin-link">用户注册</a>
				</div>
<script src="<?php echo $cdnpublic?>jquery/1.12.4/jquery.min.js"></script>
<script src="<?php echo $cdnpublic?>twitter-bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script type="text/javascript" src="https://js.users.51.la/20910251.js"></script>
<script src="../assets/js/login.js?ver=<?php echo VERSION ?>"></script>
<script src="../layui/layui.js"></script>
<script>
layui.use('form', function(){
  var form = layui.form;
});
</script>
</body>
</html>