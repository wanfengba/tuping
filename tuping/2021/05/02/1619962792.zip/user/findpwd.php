<?php
$is_defend=true;
include("../includes/common.php");
if(isset($_GET['act']) && $_GET['act']=='qrlogin'){
	if(isset($_SESSION['findpwd_qq']) && $qq=$_SESSION['findpwd_qq']){
		$row=$DB->getRow("SELECT zid,user,pwd,status FROM pre_site WHERE qq=:qq LIMIT 1", [':qq'=>$qq]);
		unset($_SESSION['findpwd_qq']);
		if($row['user']){
			if($row['status']==0){
				exit('{"code":-1,"msg":"当前账号已被封禁！"}');
			}
			$session=md5($row['user'].$row['pwd'].$password_hash);
			$token=authcode("{$row['zid']}\t{$session}", 'ENCODE', SYS_KEY);
			setcookie("user_token", $token, time() + 604800, '/');
			log_result('分站找回密码', 'User:'.$row['user'].' IP:'.$clientip, null, 1);
			$DB->exec("UPDATE pre_site SET lasttime='$date' WHERE zid='{$row['zid']}'");
			exit('{"code":1,"msg":"登录成功，请在用户资料设置里重置密码","url":"./"}');
		}else{
			@header('Content-Type: application/json; charset=UTF-8');
			exit('{"code":-1,"msg":"当前QQ不存在，请确认你已注册过账号或开通过分站"}');
		}
	}else{
		@header('Content-Type: application/json; charset=UTF-8');
		exit('{"code":-2,"msg":"验证失败，请重新扫码"}');
	}
}elseif(isset($_GET['act']) && $_GET['act']=='qrcode'){
	$image=trim($_POST['image']);
	$result = qrcodelogin($image);
	exit(json_encode($result));
}elseif($islogin2==1){
	@header('Content-Type: text/html; charset=UTF-8');
	exit("<script language='javascript'>alert('您已登陆！');window.location.href='./';</script>");
}
$title='找回密码';
include './head3.php';
?>
<?php
$date_img = file_get_contents('http://s.cn.bing.net/HPImageArchive.aspx?format=js&idx='.rand(0,7).'&n=8');
$date_img = json_decode($date_img,TRUE);
$conetr = count($date_img['images']);
$background_image = 'http://s.cn.bing.net'.$date_img['images'][rand(0,$conetr-1)]['url'];
@session_start();
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>找回密码</title>
<meta name="renderer" content="webkit">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="viewport"
	  content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
<link rel="stylesheet" href="../layui/css/layui.css" media="all">
<link rel="stylesheet" href="./login.css" media="all">
</head>
<style type="text/css">
.images {width: 110%;height: 110%;background-size: 100% 100%;z-index: -100; position: fixed;left: -5%;top: -5%;background-color: #8a2bff;}
#embed-captcha {width: 100%;margin: 0 auto;}
.show {display: block;width: 100%;text-align: center;}
.hide {display: none;}
#notice {color: red;}
.geetest_wind {width: 100% !important;}
#qrimg {margin-bottom: 2em;}
.visitor_qq {width: 3em;height: 3em;margin: 0em auto;box-shadow: 3px 3px 8px 0px #ccc;border-radius: 30rem;cursor: pointer;margin-top: 0em;}
</style>
<body>
<div class="images"  style="background-image: url(<?=$background_image?>);"></div>
<body layadmin-themealias="dark-blue" style="margin-top: 2em;">
<div class="layui-container">
         <div class="layui-col-xs12 layui-col-sm6 layui-col-sm-offset3">
            <div class="layui-card">
                <div v class="layui-card-header layui-bg-white">
                    找回密码
                </div>
			<div class="layui-card-body">
				<div class="layui-row layui-col-space15">
					<div class="layui-col-xs12 layui-conter">
						<div class="form-group" style="text-align: center;">
					      <div class="layui-card" style="font-weight: bold;" id="login">
					<span id="loginmsg">请使用QQ手机版扫描二维码</span><span id="loginload" style="padding-left: 10px;color: #790909;">.</span>
					</div>
					<div id="qrimg">
               <div class="layui-bg-gray" id="mobile" style="display:none;"><button type="button" id="mlogin" onclick="mloginurl()" class="layui-btn layui-btn-fluid layui-anim layui-anim-upbit" style="background:linear-gradient(to left, #7C4DFF,#536DFE,#9575CD);">跳转QQ快捷登录</button><br/><button type="button" onclick="loadScript()" class="layui-btn layui-btn-fluid layui-anim layui-anim-upbit" style="background: linear-gradient(to left, #ffc84d,#feb253,#cd7575);">我已完成登录</button></div>
			      </div>
					<hr class="layui-bg-gray" />
					<div class="layui-text-center">
					提示：只能找回注册时填写了QQ号码的帐号密码，QQ快捷登录的暂不持支该方式找回密码。
				</div>
		  </div>
	 </div>
</div>
<script src="<?php echo $cdnpublic?>jquery/1.12.4/jquery.min.js"></script>
<script src="<?php echo $cdnpublic?>twitter-bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src="../assets/js/qrlogin.js?ver=<?php echo VERSION ?>"></script>
<script src="../layui/layui.all.js"></script>
</body>
</html>