<?php
/**
 * 注册用户
**/
$is_defend=true;
include("../includes/common.php");
if($islogin2==1){
	@header('Content-Type: text/html; charset=UTF-8');
	exit("<script language='javascript'>alert('您已登陆！');window.location.href='./';</script>");
}
if(!$conf['user_open'] && $conf['fenzhan_buy']==1){
	exit("<script language='javascript'>window.location.href='./regsite.php';</script>");
}elseif(!$conf['user_open']){
	@header('Content-Type: text/html; charset=UTF-8');
	exit("<script language='javascript'>alert('未开放新用户注册');window.location.href='./';</script>");
}
$title='用户注册';
include './head2.php';

$addsalt=md5(mt_rand(0,999).time());
$_SESSION['addsalt']=$addsalt;
$x = new \lib\hieroglyphy();
$addsalt_js = $x->hieroglyphyString($addsalt);
?>

    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="utf-8">
        <title>用户注册 - 彩虹代刷系统</title>
        <meta name="renderer" content="webkit">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <meta name="viewport"
              content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
        <link rel="stylesheet" href="../layui/css/layui.css" media="all">
        <link rel="stylesheet" href="./login.css" media="all">
    </head>
    <style type="text/css">

        #embed-captcha {
            width: 100%;
            margin: 0 auto;
        }

        .show {
            display: block;
            width: 100%;
            text-align: center;
        }

        .hide {
            display: none;
        }

        #notice {
            color: red;
        }

        .geetest_wind {
            width: 100% !important;
        }

        #qrimg {
            margin-bottom: 2em;
        }

        .visitor_qq {
            width: 3em;
            height: 3em;
            margin: 0em auto;
            box-shadow: 3px 3px 8px 0px #ccc;
            border-radius: 30rem;
            cursor: pointer;
            margin-top: 0em;
        }
    </style>
    <body>
    <div class="layadmin-user-login layadmin-user-display-show" id="LAY-user-login" style="display: none;opacity: 0.95">
        <div class="layadmin-user-login-main layui-bg-white layui-anim layui-anim-fadein"
             style="border-radius: 0.5rem;">
            <div class="layadmin-user-login-box layadmin-user-login-header">
                <h2>用户注册</h2>
                <p>用户注册界面,请认真填写信息！</p>
            </div>
                            <div class="layadmin-user-login-box layadmin-user-login-body layui-form">
						    <input type="hidden" name="captcha_type" value="<?php echo $conf['captcha_open']?>"/>
                    <div class="layui-form-item">
                        <label class="layadmin-user-login-icon layui-icon layui-icon-username" style="color: #1E9FFF;"></label>
                        <input type="text" name="user" lay-verify="required" placeholder="输入登录用户名"
                               value="" class="layui-input">
					</div>
                    <div class="layui-form-item">
                        <label class="layadmin-user-login-icon layui-icon layui-icon-password" style="color: #f96197;"></label>
                        <input type="text" name="pwd" lay-verify="required" placeholder="输入6位以上密码"
                               class="layui-input">
                    </div>
					<div class="layui-form-item">
					    <label class="layadmin-user-login-icon layui-icon layui-icon-login-qq" style="color: #5fb878;"></label>
					    <input type="text" name="qq" lay-verify="required" placeholder="输入QQ号，用于找回密码"
					           class="layui-input">
					</div>
			<?php if($conf['captcha_open']>=1){?>
			<?php if($conf['captcha_open']>=2){?><input type="hidden" name="appid" value="<?php echo $conf['captcha_id']?>"/><?php }?>
			<div id="captcha" style="margin: auto;"><div id="captcha_text">
                正在加载验证码
            </div>
            <div id="captcha_wait">
                <div class="loading">
                    <div class="loading-dot"></div>
                    <div class="loading-dot"></div>
                    <div class="loading-dot"></div>
                    <div class="loading-dot"></div>
                </div>
            </div></div>
			<div id="captchaform"></div>
			<br/>
			<?php }else{?>
			<div class="input-group"><div class="input-group-addon"><span class="fa fa-adjust"></span></div>
              <input type="text" name="code" class="form-control input-lg" required="required" placeholder="输入验证码"/>
			  <span class="input-group-addon" style="padding: 0">
				<img id="codeimg" src="./code.php?r=<?php echo time();?>" height="43" onclick="this.src='./code.php?r='+Math.random();" title="点击更换验证码">
			  </span>
            </div><br/>
			<?php }?>
                    <div class="layui-form-item">
                        <input type="button" value="立即注册" id="submit_reg" class="layui-btn layui-btn-fluid layui-anim layui-anim-upbit" style="background-image: linear-gradient(135deg, #667eea 0%, #764ba2 100%);"/>
                    </div>
                    <div class="layui-trans layui-form-item layadmin-user-login-other">
                        <label>社交账号登入</label>
                        <a id="qq"><i class="layui-icon layui-icon-login-qq"></i></a>
                                                    <a href="../" class="layadmin-user-jump-change layadmin-link">返回首页</a>
                                                    <a href="./findpwd.php" class="layadmin-user-jump-change layadmin-link">找回密码</a>
                     </div>
<script src="<?php echo $cdnpublic?>jquery/1.12.4/jquery.min.js"></script>
<script src="<?php echo $cdnpublic?>twitter-bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src="<?php echo $cdnpublic?>layer/2.3/layer.js"></script>
<script>
var hashsalt=<?php echo $addsalt_js?>;
</script><script>
$("#qq").click(function () {
    layer.msg('暂未开放 感谢你的支持', {icon: 1})
})
$("#wx").click(function () {
    layer.msg('暂未开放 感谢你的支持')
})
</script>
<script src="../assets/js/reguser.js?ver=<?php echo VERSION ?>"></script>
</body>
</html>