<?php
/**
 * 快捷登录
**/
$is_defend=true;
include("../includes/common.php");
if($_GET['code'] && $_GET['type']){
	if(!$conf['login_qq'])sysmsg('当前站点未开启QQ快捷登录');
	if($_GET['state'] != $_SESSION['Oauth_state']){
		sysmsg("<h2>The state does not match. You may be a victim of CSRF.</h2>");
	}
	$Oauth = new \lib\Oauth($conf['login_apiurl'], $conf['login_appid'], $conf['login_appkey']);
	$arr = $Oauth->callback();
	if(isset($arr['code']) && $arr['code']==0){
		$openid=$arr['social_uid'];
		$access_token=$arr['access_token'];
		$nickname=$arr['nickname'];
		$faceimg=$arr['faceimg'];
	}elseif(isset($arr['code'])){
		sysmsg('<h3>error:</h3>'.$arr['errcode'].'<h3>msg  :</h3>'.$arr['msg']);
	}else{
		sysmsg('获取登录数据失败');
	}

	$row=$DB->getRow("SELECT * FROM pre_site WHERE qq_openid='{$openid}' limit 1");
	if($row){
		$user=$row['user'];
		$pass=$row['pwd'];
		if($islogin2==1){
			@header('Content-Type: text/html; charset=UTF-8');
			exit("<script language='javascript'>alert('当前QQ已绑定用户:{$user}，请勿重复绑定！');window.location.href='./uset.php?mod=user';</script>");
		}
		$session=md5($user.$pass.$password_hash);
		$token=authcode("{$row['zid']}\t{$session}", 'ENCODE', SYS_KEY);
		ob_clean();
		setcookie("user_token", $token, time() + 604800, '/');
		log_result('分站登录', 'User:'.$user.' IP:'.$clientip, null, 1);
		$DB->exec("UPDATE pre_site SET lasttime='$date' WHERE zid='{$row['zid']}'");
		if(isset($_SESSION['Oauth_back']) && $_SESSION['Oauth_back']=='index')$redirect = '../';
		elseif(isset($_SESSION['Oauth_back']) && $_SESSION['Oauth_back']=='recharge')$redirect = './recharge.php';
		elseif(isset($_SESSION['Oauth_back']) && $_SESSION['Oauth_back']=='workorder')$redirect = './workorder.php';
		else $redirect = './';
		exit("<script language='javascript'>window.location.href='{$redirect}';</script>");
	}elseif($islogin2==1){
		$sds=$DB->exec("update `pre_site` set `qq_openid` ='$openid' where `zid`='{$userrow['zid']}'");
		@header('Content-Type: text/html; charset=UTF-8');
		exit("<script language='javascript'>alert('已成功绑定QQ！');window.location.href='./uset.php?mod=user';</script>");
	}else{
		$_SESSION['Oauth_qq_openid']=$openid;
		$_SESSION['Oauth_qq_token']=$access_token;
		$_SESSION['Oauth_qq_nickname']=$nickname;
		$_SESSION['Oauth_qq_faceimg']=$faceimg;
		@header('Content-Type: text/html; charset=UTF-8');
		if($_SESSION['Oauth_back'])$addstr = '?back='.$_SESSION['Oauth_back'];
		exit("<script language='javascript'>window.location.href='./connect.php{$addstr}';</script>");
	}
}elseif($islogin2==1){
	@header('Content-Type: text/html; charset=UTF-8');
	exit("<script language='javascript'>alert('您已登陆！');window.location.href='./';</script>");
}elseif(!$_SESSION['Oauth_qq_openid'] || !$_SESSION['Oauth_qq_token']){
	exit("<script language='javascript'>window.location.href='./login.php';</script>");
}

$title='QQ快捷登录';
include './head3.php';

if($_SESSION['Oauth_qq_faceimg']){
	$faceimg = $_SESSION['Oauth_qq_faceimg'];
}else{
	$faceimg = '//q4.qlogo.cn/headimg_dl?dst_uin='.$conf['kfqq'].'&spec=100';
}

if($_GET['act'] == 'new'){
	$subtitle = '完善信息';
}elseif($_GET['act'] == 'bind'){
	$subtitle = '绑定账号';
}else{
	$subtitle = 'QQ登录';
}

if($_GET['act'] == 'new'){
	$subtitl = '请认真填写信息,感谢你对平台的支持!';
}elseif($_GET['act'] == 'bind'){
	$subtitl = '请认真填写账号信息,感谢你对平台的支持!';
}else{
	$subtitl = '请选择下方按钮,感谢你对平台的支持!';
}

if($_SESSION['Oauth_back'])$addstr = '&back='.$_SESSION['Oauth_back'];
?>
<?php
$date_img = file_get_contents('http://s.cn.bing.net/HPImageArchive.aspx?format=js&idx='.rand(0,7).'&n=8');
$date_img = json_decode($date_img,TRUE);
$conetr = count($date_img['images']);
$background_image = 'http://s.cn.bing.net'.$date_img['images'][rand(0,$conetr-1)]['url'];
@session_start();
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title><?php echo $subtitle?></title>
<meta name="renderer" content="webkit">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="viewport"
	  content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
<link rel="stylesheet" href="../layui/css/layui.css" media="all">
<link rel="stylesheet" href="./login.css" media="all">
<link rel="stylesheet" href="<?php echo $cdnserver?>assets/css/common.css">
</head>
<style type="text/css">
.images {width: 110%;height: 110%;background-size: 100% 100%;z-index: -100; position: fixed;left: -5%;top: -5%;background-color: #8a2bff;}
#embed-captcha {width: 100%;margin: 0 auto;}
.show {display: block;width: 100%;text-align: center;}
.hide {display: none;}
#notice {color: red;}
.layui-btn-flui {width: 80%;}
.geetest_wind {width: 100% !important;}
#qrimg {margin-bottom: 2em;}
.visitor_qq {width: 3em;height: 3em;margin: 0em auto;box-shadow: 3px 3px 8px 0px #ccc;border-radius: 30rem;cursor: pointer;margin-top: 0em;}
</style>
<body>
<div class="images"  style="background-image: url(<?=$background_image?>);"></div>
<div class="layadmin-user-login layadmin-user-display-show" id="LAY-user-login" style="display: none;opacity: 0.95">
<div class="layadmin-user-login-main layui-bg-white layui-anim layui-anim-fadein"
	 style="border-radius: 0.5rem;">
	<div class="layadmin-user-login-box layadmin-user-login-header">
		 <h2><?php echo $subtitle?></h2>
		 <p><?php echo $subtitl?></p>
	</div>
	<div id="loginframe">
	<?php if($_GET['act'] == 'bind'){?>
	<div class="layadmin-user-login-box layadmin-user-login-body layui-form">
		  <div class="layui-form-item">
				<label class="layadmin-user-login-icon layui-icon layui-icon-username" style="color: #1E9FFF;"></label>
				<input type="text" name="user" lay-verify="required" placeholder="填写您设置的账号"
						 value="" class="layui-input">
	</div>
		  <div class="layui-form-item">
				<label class="layadmin-user-login-icon layui-icon layui-icon-password" style="color: #f96197;"></label>
				<input type="password" name="pass" lay-verify="required" placeholder="填写您设置的密码"
						 class="layui-input">
		  </div>
			<?php if($conf['captcha_open_login']==1 && $conf['captcha_open']>=1){?>
			<input type="hidden" name="captcha_type" value="<?php echo $conf['captcha_open']?>"/>
			<?php if($conf['captcha_open']>=2){?><input type="hidden" name="appid" value="<?php echo $conf['captcha_id']?>"/><?php }?>
			<div id="captcha" style="margin: auto;"><div id="captcha_text">
                正在加载验证码
            </div>
            <div id="captcha_wait">
                <div class="loading">
                    <div class="loading-dot"></div>
                    <div class="loading-dot"></div>
                    <div class="loading-dot"></div>
                    <div class="loading-dot"></div>
                </div>
            </div></div>
			<div id="captchaform"></div>
			<br/>
			<?php }?>
			<div class="layui-form-item">
				<input type="button" value="立即登陆" id="submit_login" class="layui-btn layui-btn-fluid layui-anim layui-anim-upbit" style="background-image: linear-gradient(135deg, #667eea 0%, #764ba2 100%);"/>
		                </div>
			       </div>
          </form>
<?php }else{?>
			<hr>
            <p><center><a href="javascript:quickreg()" class="layui-btn layui-btn-flui layui-anim layui-anim-upbit" style="background:linear-gradient(to left, #7C4DFF,#536DFE,#9575CD);"><i class="layui-icon layui-icon-username"></i>我是新用户，直接登录</a></center></p>
			<hr>
			<p><center><a href="connect.php?act=bind<?php echo $addstr?>" class="layui-btn layui-btn-flui layui-anim layui-anim-upbit" style="background: linear-gradient(to left, #ff4d66,#fe53aa,#cd75b7);"><i class="layui-icon layui-icon-user"></i>我是老用户，绑定已有账号</a></center></p>
			</div>
			<hr>
<?php }?>
          </form>
    </div>
  </div>
<script src="<?php echo $cdnpublic?>jquery/1.12.4/jquery.min.js"></script>
<script src="<?php echo $cdnpublic?>twitter-bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src="<?php echo $cdnpublic?>layer/2.3/layer.js"></script>
<script src="../layui/layui.js"></script>
<script src="../assets/js/login.js?ver=<?php echo VERSION ?>"></script>
</body>
</html>