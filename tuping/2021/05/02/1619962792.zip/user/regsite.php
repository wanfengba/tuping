<?php
$is_defend=true;
include("../includes/common.php");
if($islogin2==1 && $userrow['power']>0){
	@header('Content-Type: text/html; charset=UTF-8');
	exit("<script language='javascript'>alert('您已开通过分站！');window.location.href='./';</script>");
}elseif($conf['fenzhan_buy']==0){
	@header('Content-Type: text/html; charset=UTF-8');
	exit("<script language='javascript'>alert('当前站点未开启自助开通分站功能！');window.location.href='./';</script>");
}

if($is_fenzhan == true && $siterow['power']==2){
	if($siterow['ktfz_price']>0)$conf['fenzhan_price']=$siterow['ktfz_price'];
	if($conf['fenzhan_cost2']<=0)$conf['fenzhan_cost2']=$conf['fenzhan_price2'];
	if($siterow['ktfz_price2']>0 && $siterow['ktfz_price2']>=$conf['fenzhan_cost2'])$conf['fenzhan_price2']=$siterow['ktfz_price2'];
}
$title='自助开通分站';
include './head3.php';

$addsalt=md5(mt_rand(0,999).time());
$_SESSION['addsalt']=$addsalt;
$x = new \lib\hieroglyphy();
$addsalt_js = $x->hieroglyphyString($addsalt);

$kind = isset($_GET['kind'])?$_GET['kind']:0;

if($is_fenzhan == true && $siterow['power']==2 && !empty($siterow['ktfz_domain'])){
	$domains=explode(',',$siterow['ktfz_domain']);
}else{
	$domains=explode(',',$conf['fenzhan_domain']);
}
$select='';
foreach($domains as $domain){
	$select.='<option value="'.$domain.'">'.$domain.'</option>';
}
if(empty($select))showmsg('请先到后台分站设置，填写可选分站域名',3);
?>
<?php
$date_img = file_get_contents('http://s.cn.bing.net/HPImageArchive.aspx?format=js&idx='.rand(0,7).'&n=8');
$date_img = json_decode($date_img,TRUE);
$conetr = count($date_img['images']);
$background_image = 'http://s.cn.bing.net'.$date_img['images'][rand(0,$conetr-1)]['url'];
@session_start();
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>自助开通分站</title>
<meta name="renderer" content="webkit">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="viewport"
	  content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
<link rel="stylesheet" href="../layui/css/layui.css" media="all">
<link rel="stylesheet" href="./login.css" media="all">
</head>
<style type="text/css">
.images {width: 110%;height: 110%;background-size: 100% 100%;z-index: -100; position: fixed;left: -5%;top: -5%;background-color: #8a2bff;}
#embed-captcha {width: 100%;margin: 0 auto;}
.show {display: block;width: 100%;text-align: center;}
.hide {display: none;}
#notice {color: red;}
.geetest_wind {width: 100% !important;}
#qrimg {margin-bottom: 2em;}
.layadmin-user-login {position: relative;left: 0;top: 0;padding: 60px 0;min-height: 100%;box-sizing: border-box;}
.visitor_qq {width: 3em;height: 3em;margin: 0em auto;box-shadow: 3px 3px 8px 0px #ccc;border-radius: 30rem;cursor: pointer;margin-top: 0em;}
.layui-form-labe {width: 110px;padding: 8px 15px;height: 76px;line-height: 20px;border-width: 1px;border-style: solid;border-radius: 2px 0 0 2px;text-align: center;background-color: #FBFBFB;overflow: hidden;box-sizing: border-box;}
</style>
<body>
<div class="images"  style="background-image: url(<?=$background_image?>);"></div>
<div class="layadmin-user-login layadmin-user-display-show" id="LAY-user-login" style="display: none;opacity: 0.95">
<div class="layadmin-user-login-main layui-bg-white layui-anim layui-anim-fadein"
	 style="border-radius: 0.5rem;">
	<div class="layadmin-user-login-box layadmin-user-login-header">
		 <h2>自助开通分站</h2>
		 <p>开通分站,一起共建网赚平台！</p>
	</div>
   <div class="layui-card-body">
     <form class="layui-form layui-form-pane" action="">
		 <div class="layui-row layui-col-space8">
			  <div class="layui-col-xs12">
				   <div class="layui-form-item">
					<label class="layui-form-label">分站版本</label>
               <div class="layui-input-block">
               <select name="kind" lay-verify="required">
               <option value="1" <?php if($kind==0){?><?php }?>>普及版(<?php echo $conf['fenzhan_price']?>元)</option><option value="2" <?php if($kind==1){?><?php }?>>专业版(<?php echo $conf['fenzhan_price2']?>元)</option>
                </select>
				</div>
		</div>
<div class="layui-form-item">
	<label class="layui-form-label" style="height: 75px;line-height: 55px;">二级域名</label>
	   <div class="layui-input-block">
			<input type="text" onkeyup="value=value.replace(/[^\w\.\/]/ig,'')" name="qz" value="" required  lay-verify="required" placeholder="输入你想要的二级前缀" required data-parsley-length="[2,8]" autocomplete="off" class="layui-input">
		   <select name="domain" lay-verify="required">
		       <?php echo $select?>
		     </select>
		 </div>
	</div>
<div class="layui-form-item">
	<label class="layui-form-label">管理账号</label>
		<div class="layui-input-block">
			<input type="text" name="user" value="" required  lay-verify="required" placeholder="输入要注册的用户名" autocomplete="off" class="layui-input">
		</div>
		</div>
<div class="layui-form-item">
	<label class="layui-form-label">管理密码</label>
		<div class="layui-input-block">
			<input type="text" name="pwd" value="" required  lay-verify="required" placeholder="输入管理员密码" autocomplete="off" class="layui-input">
		</div>
		</div>
<div class="layui-form-item">
	<label class="layui-form-label">绑定ＱＱ</label>
		<div class="layui-input-block">
			<input type="number" name="qq" value="" required  lay-verify="required" placeholder="输入你的QQ号" required data-parsley-length="[5,10]" autocomplete="off" class="layui-input">
		</div>
		</div>
<div class="layui-form-item">
	<label class="layui-form-label">网站名称</label>
		<div class="layui-input-block">
			<input type="text" name="name" value="" required  lay-verify="required" placeholder="输入网站名称" required  data-parsley-length="[2,10]" autocomplete="off" class="layui-input">
		</div>
		</div>
 <div class="layui-form-item">
   <button type="button" id="submit_buy" class="layui-btn layui-btn-fluid layui-anim layui-anim-upbit  "
         style="background:linear-gradient(to left, #7C4DFF,#536DFE,#9575CD);" lay-submit
         lay-filter="submit_buy">点此立即拥有分站
    </button>
   </div>
	</div>
<script src="<?php echo $cdnpublic?>jquery/1.12.4/jquery.min.js"></script>
<script src="<?php echo $cdnpublic?>twitter-bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src="../assets/js/regsite.js?ver=<?php echo VERSION ?>"></script>
<script src="<?php echo $cdnpublic?>layer/2.3/layer.js"></script>
<script src="../layui/layui.all.js"></script>
<script>
var hashsalt=<?php echo $addsalt_js?>;
</script>
<script>
layui.use('element', function(){
	var element = layui.element;
});
</script>
</body>
</html>