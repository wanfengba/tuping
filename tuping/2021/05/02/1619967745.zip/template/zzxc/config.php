<?php
/*
 本代码由 便宜技术猫 创建
 创建时间 2021-1-16 08:24:54
 技术支持 QQ:2420083841 www.azpay.cn
 严禁反编译、逆向等任何形式的侵权行为，违者将追究法律责任
*/

unset($C39tI8Q);$C39tI8Q=['name'=>'渐蓝模板第一套','version'=>2.5];$template_info=$C39tI8Q;unset($C39tI8Q);$C39tI8Q=['aaynm_wzsl'=>['name'=>'文章简介显示文字数量','type'=>'input','note'=>'此处为每一条文章简介文字显示数量,默认为45个文字,如需更改,请填写数字!'],'aaynm_wzdx'=>['name'=>'文章简介字体大小','type'=>'input','note'=>'此处为每一条文章简介文字显示字体大小,默认为13px,如需更改,请填写数字!'],'aaynm_wz'=>['name'=>'文章显示数量','type'=>'input','note'=>'此处为文章显示数量,默认为5条,如需更改,请填写数字!'],];$template_settings=$C39tI8Q;
?>