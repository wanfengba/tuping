<?php
/*
 本代码由 便宜技术猫 创建
 创建时间 2021-1-21 14:24:54
 技术支持 QQ:2420083841 www.azpay.cn
 严禁反编译、逆向等任何形式的侵权行为，违者将追究法律责任
*/
if(!defined('IN_CRONLITE'))exit();
?>
<!-- 
  本代码由 便宜技术博猫 创建
  技术支持 QQ:2420083841 www.azpay.cn
  严禁反编译、逆向等任何形式的侵权行为，违者将追究法律责任
 -->
<!DOCTYPE html>
<html lang="zh-cn">
<head>
  <meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no"/>
  <title><?php echo $hometitle?></title>
  <meta name="keywords" content="<?php echo $conf['keywords']?>">
  <meta name="description" content="<?php echo $conf['description']?>">
  <link href="<?php echo $cdnpublic?>twitter-bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet"/>
  <link href="<?php echo $cdnpublic?>font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet"/>
  <link rel="stylesheet" href="<?php echo $cdnserver?>assets/simple/css/oneui.css">
  <link rel="stylesheet" href="<?php echo $cdnserver?>assets/css/common.css?ver=<?php echo VERSION ?>">
  <script src="<?php echo $cdnpublic?>modernizr/2.8.3/modernizr.min.js"></script>
  <!--[if lt IE 9]>
    <script src="<?php echo $cdnpublic?>html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="<?php echo $cdnpublic?>respond.js/1.4.2/respond.min.js"></script>
  <![endif]-->
<style>
body{ background: linear-gradient(to right,#d00123,#ea875a) fixed;}
.img-avatar{
    -webkit-animation:rotateImg 3s linear infinite;
}
@keyframes rotateImg {
0% {transform : rotate(0deg);}
100% {transform : rotate(360deg);}
}
@-webkit-keyframes rotateImg {
0%{-webkit-transform : rotate(0deg);}
100%{-webkit-transform : rotate(360deg);}
</style>
<style>
.input-group-addon{color:#3a1616;background:linear-gradient(to right,#FFF6B7,#F6416C);border-color:#fbacd4;border-radius:18px;}.input-group-addon{padding:6px 13px;font-size:15px;font-weight:normal;line-height:1;text-align:center;border:1px solid #fbbfa1;}.form-control{color:#f64e72;border:1px solid #fcc0a1;border-radius:18px;box-shadow:none;transition:all 0.15s ease-out;}.form-control{height:34px;padding:6px 15px;font-size:14.5px;line-height:1.42857143;background-color:#fffcf5;background-image:none;}.table{width:100%;max-width:100%;margin-bottom:10px;}
</style>
<style type="text/css">
.col-xs-6{width:33%;}.btn-success{color:#ffffff;background-color:#f317e6;border-color:#f317e6;}.btn-success:hover,.btn-success:active,.btn-success:focus,.btn-success.active,.btn-success.focus{color:#ffffff;background-color:#dc16d0!important;border-color:#dc16d0!important;}.btn-primary{color:#ffffff;background-color:#e61b20;border-color:#e61b20;}.btn-primary:hover,.btn-primary:active,.btn-primary:focus,.btn-primary.active,.btn-primary.focus{color:#ffffff;background-color:#cb161b!important;border-color:#cb161b!important;}.article-card:last-child{margin-bottom:0;}.btn{font-weight:600;border-radius:20px;}.btn-sm,.btn-group-sm > .btn{padding:6px 10px;font-size:12px;line-height:1.5;}.alert{padding-bottom:10px;border-radius:10px;border:none;}.article-card{margin-bottom:15px;border-radius:2px;background-color:#fff;box-shadow:0 1px 2px 0 rgba(0,0,0,.05);}.article-card-header{position:relative;height:42px;line-height:42px;padding:0 15px;border-bottom:0px solid #f6f6f6;color:#333;border-radius:2px 2px 0 0;font-size:14px;}.article-elip,.article-form-checkbox span,.article-form-pane .article-form-label{text-overflow:ellipsis;white-space:nowrap;}.article-body,.article-edge,.article-elip{overflow:hidden;}.article-badge{height:18px;line-height:18px;}.article-badge,.article-badge-dot,.article-badge-rim{position:relative;display:inline-block;padding:0 6px;font-size:12px;text-align:center;background-color:#FF5722;color:#fff;border-radius:2px;}.article-bg-orange{background-color:#FFB800!important;}.article-bg-green{background-color:#009688!important;}.article-bg-gray{background-color:#eee!important;color:#666!important;}.btn-default{color:#fec57d;background-color:rgba(255,255,255,0.15);border-color:rgba(255,255,255,0.15);}
</style>
<style>
.elevator_item {
    position: fixed;
    right: 0;
    bottom: 95px;
    z-index: 11;
}
.elevator_item .feedback {
    width: 36px;
    height: 41px;
    font-size: 12px;
    padding: 5px 6px;
    display: block;
    border-radius: 5px;
    text-align: center;
    margin-top: 10px;
    box-shadow: 0 1px 2px rgba(0,0,0,.35);
    cursor: pointer;
}
.graHover {
    position: relative;
    overflow: hidden;
}
.bg-image {
    background-color: #18aeef00;
    background-position: center center;
    background-repeat: no-repeat;
    -webkit-background-size: cover;
    background-size: cover;
}
.btn-default {
    color: #fec57d;
    background-color: rgb(255, 255, 255);
    border-color: rgba(255, 255, 255, 0.77);
}
</style>
</head>
<script type="text/javascript">var online = [];online[0]=0;</script>
  <!--商品推荐开始-->
<div class="modal fade" align="left" id="sptj" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
<div class="modal-dialog">
<div class="modal-content">
      <div class="modal-header" style="background:linear-gradient(120deg, #0174DF 30%, #DF01D7 70%);">
        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true"></span><span class="sr-only">Close</span></button>
            <center><h4 class="modal-title" id="myModalLabel"><b><font color="#fff">商品推荐</font></b></h4></center>
    </div>
    <br/>
        <table class="table table-bordered table-striped">
    <tbody>
    <tr>
    </tr>
    </tbody>
    </table>
    <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">关闭</button>
    </div>
    </div>
    </div>
    </div>
<!--商品推荐结束-->
<!--在线登录-->
<div class="modal fade" id="cmLoginModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title" id="myModalLabel">在线登录</h4>
            </div>
            <div class="modal-body">
                <div class="form-group">
                    <div class="input-group">
                        <div class="input-group-addon">登录账号</div>
                        <input type="text" id="username" class="form-control" placeholder="请填写登录账号">
                    </div>
                </div>
                <div class="form-group">
                    <div class="input-group">
                        <div class="input-group-addon">登录密码</div>
                        <input type="password" id="password" class="form-control" placeholder="请填写登录密码">
                    </div>
                    <small>忘记密码？<a href="/user/findpwd.php">点我</a>(找回后记得返回本页面哦)</small>
                </div>
                <br/>
                <div class="form-group">
                    <a class="btn btn-info btn-block" id="login" onclick="cm_login()">确定登录</a><br/>
                    <a class="btn btn-success btn-rounded" data-dismiss="modal" onclick="$('#cmRegModal').modal('show')">现在注册</a>
                    <a id="siterowmit" class="btn btn-primary btn-rounded" data-dismiss="modal" style="float:right;">取消登录</a>
                </div>
            </div>
        </div>
    </div>
</div>
<!--在线登录 end-->
<!--在线注册-->
<div class="modal fade" id="cmRegModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title" id="myModalLabel">注册新用户</h4>
            </div>
            <div class="modal-body">
                <div class="form-group">
                    <div class="input-group">
                        <div class="input-group-addon">登录账号</div>
                        <input type="text" id="reg_username" class="form-control" placeholder="请填写登录账号">
                    </div>
                    <small>登录账号可以使用QQ，微信号，手机号等</small>
                </div>
                <div class="form-group">
                    <div class="input-group">
                        <div class="input-group-addon">登录密码</div>
                        <input type="password" id="reg_password" class="form-control" placeholder="请填写登录密码">
                    </div>
                    <small>登录密码建议不要跟账号相同，可以使用字母数字和下划线等任意组合</small>
                </div>
                <div class="form-group">
                    <div class="input-group">
                        <div class="input-group-addon">联系QQ</div>
                        <input type="text" id="reg_qq" class="form-control" placeholder="请填写联系QQ">
                    </div>
                    <small>填写的你QQ号码，方便联系和咨询我们</small>
                </div>
                <br/>
                <div class="form-group">
                    <a class="btn btn-info btn-block" id="reg" onclick="cm_reg()">立即注册</a><br/>
                    <a class="btn btn-success btn-rounded" data-dismiss="modal" onclick="$(\'#cmLoginModal\').modal(\'show\')">已有账号</a>
                    <a id="siterowmit" class="btn btn-primary btn-rounded" data-dismiss="modal" style="float:right;">取消注册</a>
                </div>
            </div>
        </div>
    </div>
</div>
<!--在线注册 end-->

<!--拉圈圈 end-->
<div class="modal fade" id="lqq" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-popin">
        <div class="modal-content">
            <div class="block block-themed block-transparent remove-margin-b">
                <div class="block-header bg-primary-dark">
                    <ul class="block-options">
                        <li>
                            <button data-dismiss="modal" type="button"><i class="si si-close"></i></button>
                        </li>
                    </ul>
                    <h4 class="block-title">免费拉圈圈99+</h4>
                </div>
                <div class="modal-body">
                    <div class="alert alert-info">
                        免费拉取圈圈标签赞 99+ ，不是100%成功哦！
                    </div>
                    <div class="form-group">
                        <div class="input-group">
                            <div class="input-group-addon">请输入QQ</div>
                            <input type="text" name="qq" id="qq4" value="" class="form-control" required/>
                        </div>
                    </div>
                    <input type="submit" id="submit_lqq" class="btn btn-primary btn-block" value="立即提交">
                    <div id="result3" class="form-group text-center" style="display:none;"></div>
                    <br/>
                </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-sm btn-default" type="button" data-dismiss="modal">关闭</button>
            </div>
        </div>
    </div>
</div>
<!--拉圈圈 end-->

<!--版本介绍-->
<div align="left" aria-hidden="true" aria-labelledby="myModalLabel" class="modal fade" id="userjs" role="dialog" style="display: none;" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header" style="background:linear-gradient(120deg, #FE2EF7 10%, #71D7A2 90%);">
                <button aria-hidden="true" class="close" data-dismiss="modal" type="button">
                    ×
                </button>
                <h4 class="modal-title" id="myModalLabel">
                    版本介绍
                </h4>
            </div>
            <div class="modal-body">
                <div class="table-responsive">
                    <table class="table table-borderless table-vcenter">
                        <thead>
                            <tr>
                                <th style="width: 100px;">
                                    功能
                                </th>
                                <th class="text-center" style="width: 20px;">
                                    普通版/高级版
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr class="active">
                                <td>
                                    独立网站/专属后台
                                </td>
                                <td class="text-center">
                                    <span class="btn btn-effect-ripple btn-xs btn-success" style="overflow: hidden; position: relative;">
                                        <i class="fa fa-check">
                                        </i>
                                    </span>
                                    <span class="btn btn-effect-ripple btn-xs btn-success" style="overflow: hidden; position: relative;">
                                        <i class="fa fa-check">
                                        </i>
                                    </span>
                                </td>
                            </tr>
                            <tr class="">
                                <td>
                                    低价拿货/调整价格
                                </td>
                                <td class="text-center">
                                    <span class="btn btn-effect-ripple btn-xs btn-success" style="overflow: hidden; position: relative;">
                                        <i class="fa fa-check">
                                        </i>
                                    </span>
                                    <span class="btn btn-effect-ripple btn-xs btn-success" style="overflow: hidden; position: relative;">
                                        <i class="fa fa-check">
                                        </i>
                                    </span>
                                </td>
                            </tr>
                            <tr class="info">
                                <td>
                                    搭建分站/管理分站
                                </td>
                                <td class="text-center">
                                    <span class="btn btn-effect-ripple btn-xs btn-danger" style="overflow: hidden; position: relative;">
                                        <i class="fa fa-close">
                                        </i>
                                    </span>
                                    <span class="btn btn-effect-ripple btn-xs btn-success" style="overflow: hidden; position: relative;">
                                        <i class="fa fa-check">
                                        </i>
                                    </span>
                                </td>
                            </tr>
                            <tr class="">
                                <td>
                                    超低密价/高额提成
                                </td>
                                <td class="text-center">
                                    <span class="btn btn-effect-ripple btn-xs btn-danger" style="overflow: hidden; position: relative;">
                                        <i class="fa fa-close">
                                        </i>
                                    </span>
                                    <span class="btn btn-effect-ripple btn-xs btn-success" style="overflow: hidden; position: relative;">
                                        <i class="fa fa-check">
                                        </i>
                                    </span>
                                </td>
                            </tr>
                            <tr class="danger">
                                <td>
                                    赠送代刷APP
                                </td>
                                <td class="text-center">
                                    <span class="btn btn-effect-ripple btn-xs btn-danger" style="overflow: hidden; position: relative;">
                                        <i class="fa fa-close">
                                        </i>
                                    </span>
                                    <span class="btn btn-effect-ripple btn-xs btn-success" style="overflow: hidden; position: relative;">
                                        <i class="fa fa-check">
                                        </i>
                                    </span>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-default" data-dismiss="modal" type="button">
                    关闭
                </button>
            </div>
        </div>
    </div>
</div>
<!--版本介绍 end-->

<!--球球大作战-->
<div align="left" aria-hidden="true" aria-labelledby="myModalLabel" class="modal fade" id="qqdzz" role="dialog" style="display: none;" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="list-group-item reed" style="background:linear-gradient(120deg, #5ED1D7 10%, #71D7A2 90%);">
                <button class="close" data-dismiss="modal" type="button">
                    <span aria-hidden="true">
                        x
                    </span>
                    <span class="sr-only">
                        Close
                    </span>
                </button>
                <center>
                    <h4 class="modal-title" id="myModalLabel">
                        <b>
                            <font color="#fff">
                                数量要求
                            </font>
                        </b>
                    </h4>
                </center>
            </div>
            <br/>
            <div class="modal-body">
                <center>
                    <p class="bg-primary" style="background-color:#424242;padding: 10px;">
                        球球粉丝
                        <br/>
                        固定数量:100,200,400,800,
                        <br/>
                        1000,2000,4000,8000,10000,20000
                    </p>
                    <p class="bg-primary" style="background-color:#FF6666;padding: 10px;">
                        球球爱心
                        <br/>
                        固定数量:1000,2000,4000,
                        <br/>
                        8000,10000,20000,40000,80000
                    </p>
                </center>
                <div class="modal-footer">
                    <button class="btn btn-default" data-dismiss="modal" type="button">
                        我知道了
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>
<!--球球大作战 end-->

<!--全民K歌-->
<div align="left" aria-hidden="true" aria-labelledby="myModalLabel" class="modal fade" id="qmkg" role="dialog" style="display: none;" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="list-group-item reed" style="background:linear-gradient(120deg, #DF01A5 10%, #FF0080 90%);">
                <button class="close" data-dismiss="modal" type="button">
                    <span aria-hidden="true">
                    </span>
                    <span class="sr-only">
                        Close
                    </span>
                </button>
                <center>
                    <h4 class="modal-title" id="myModalLabel">
                        <b>
                            <font color="#fff">
                                经验上限表
                            </font>
                        </b>
                    </h4>
                </center>
            </div>
            <div class="modal-body">
                <center>
                    <p class="bg-primary" style="background-color:#424242;padding: 10px;">
                        0-6级： 每天可获得1000点经验
                    </p>
                    <p class="bg-primary" style="background-color:#FF6666;padding: 10px;">
                        7-9级： 每天可获得1500点经验
                    </p>
                    <p class="bg-primary" style="background-color:#0404B4;padding: 10px;">
                        10-12级：每天可获得3500点经验
                    </p>
                    <p class="bg-primary" style="background-color:#FF8000;padding: 10px;">
                        13-15级：每天可获得26000点经验
                    </p>
                    <p class="bg-primary" style="background-color:#04B431;padding: 10px;">
                        16-18级：每天可获得45000点经验
                    </p>
                </center>
                <div class="modal-footer">
                    <button class="btn btn-default" data-dismiss="modal" type="button">
                        我知道了
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>
<!--全民K歌 end-->

<!--钻类-->

<div class="modal fade" align="left" id="zlsm" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">

   <div class="modal-dialog">

    <div class="modal-content">

         <div class="list-group-item reed" style="background:linear-gradient(120deg, #0000FF 10%, #FE2EF7 90%);">

        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true"></span><span class="sr-only">Close</span></button>

    <center><h4 class="modal-title" id="myModalLabel"><b><font color="#fff">钻类介绍</font></b></h4></center>

      </div>

      <br/>

  <div class="modal-body">

<p class="bg-primary" style="background-color:#04B45F;padding: 10px;">

问题：什么是质保期，理论永久是什么？</p>

 <p class="bg-primary" style="background-color:#A8904B1;padding: 10px;">

质保：理论永久，每个人用的时间都不一样，质保期就像家电的保修期一样，有问题可以联系客服处理哦！</p>     </div>

      <div class="modal-footer">

      <button type="button" class="btn btn-default" data-dismiss="modal">我知道了</button>

     </div>

   </div>

  </div>

 </div>

<!--钻类 end-->

<!--查单说明开始-->
<div class="modal fade" align="left" id="cxsm" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">
              <span aria-hidden="true">
                &times;
              </span>
              <span class="sr-only">
                Close
              </span>
            </button>
            <h4 class="modal-title" id="myModalLabel">
              我该如何查单？
            </h4>
          </div>
          <li class="list-group-item">
            <font color="red">
              请在右侧的输入框内输入您下单时，在第一个输入框内填写的下单信息
            </font>
          </li>
          <li class="list-group-item">
            <font color="green">
              例如您购买商品时需要填邮箱账号，这种需要输入您的完整邮箱账号，输入QQ号或其他是查询不到的
            </font>
          </li>
          <li class="list-group-item">
            <b>
              <font color="blue">
                如果付款后，查单账号输入正确还是没有订单，可能是漏单了！联系客服提供付款截图处理
              </font>
            </b>
          </li>
          <li class="list-group-item">
            例如您购买的是QQ名片赞，输入下单的QQ账号即可查询订单
          </li>
          <li class="list-group-item">
            例如您购买的是全民K歌商品，需要输入歌曲链接里play?s=和&amp;之间的一串英文数字，输入歌曲链接是查询不到的
          </li>
          <li class="list-group-item">
            例如您购买的是抖音视频商品，需要输入抖音账号，或者下单时提示您的查单账号，输入抖音作品链接是查询不到的
          </li>
          <li class="list-group-item">
            <font color="red">
              如果您不知道下单账号是什么，可以不填写，直接点击查询，则会根据浏览器缓存查询
            </font>
          </li>
          <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal">
              关闭
            </button>
          </div>
        </div>
    </div>
</div>
<!--查单说明 end-->

<!--联系客服弹窗-->
        <div class="modal fade" align="left" id="kefu" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">
                  <span aria-hidden="true"><i class="fa fa-times-circle"></i></span>
                  <span class="sr-only">Close</span></button>
                <h4 class="modal-title" id="myModalLabel">常见问题</h4></div>
              <div class="modal-body">
                <div class="tab-pane fade in" id="faq">
                  <div class="panel-group" id="accordion">
                    <div class="panel panel-info">
                      <a class="cm-kfqy-warning collapsed" data-toggle="collapse" data-parent="#accordion" href="#1">
                      <b>为什么下单了没有处理呢？</b>
                      </a>
                      <div id="1" class="panel-collapse collapse" style="height: 0px;">
                        <div class="panel-body">由于本站80%以上的业务订单采用软件全自动处理，下单自动记录订单并排队处理，若订单超过6小时仍然显示待处理请联系客服！（注：是6小时显示未处理联系客服，不是6小时未到账联系客服！）<br/>如果你购买的是钻类商品，一般说明上会写到账时间，点播和爆卡的比较慢，大概2~5天都很正常，官方的较快，当天到账<br/>如果你购买的是其他手工商品，说明会写操作说明或到账时间，请参照说明并如实操作，才能尽快给你完成订单哦~<br/>
                        如果超过7天以上，请咨询客服是否出现维护等情况，可根据情况退单处理~</div></div>
                    </div>
                    <div class="panel panel-warning">
                      <a class="cm-kfqy collapsed" data-toggle="collapse" data-parent="#accordion" href="#2" class="collapsed">
                        <b>QQ空间业务好久没开刷？</b>
                      </a>
                      <div id="2" class="panel-collapse collapse" style="height: 0px;">
                        <div class="panel-body">1.空间权限设为所有人可见
                          <br/>2.空间被单封请勿下单（这种是QQ好友才能进去，而且好友是看不出来异常的，当陌生人进去就提示空间维护）
                          <br/>3.空间最好有2、3条说说</div></div>
                    </div>
                    <div class="panel panel-warning">
                      <a class="cm-kfqy" data-toggle="collapse" data-parent="#accordion" href="#7" class="collapsed">
                        <b>全名k歌这些业务好久没开刷？</b>
                      </a>
                      <div id="7" class="panel-collapse collapse" style="height: 0px;">
                        <div class="panel-body">1.下单前先确认输的信息是否正确！
                          <br/>2.请检查作品是否违规或者出现审核等无法正常观看的情况<br/>
                        3.请检查下单时的作品链接是否正确，超过24小时未开始联系客服处理</div></div>
                    </div>
                    <div class="panel panel-warning">
                      <a class="cm-kfqy" data-toggle="collapse" data-parent="#accordion" href="#11" class="collapsed">
                        <b>发卡商品没收到卡密？</b>
                      </a>
                      <div id="11" class="panel-collapse collapse" style="height: 0px;">
                        <div class="panel-body">下单必须填写正确的邮箱号！
                          <br/>邮箱用于接收卡密以及查询订单
                          <br/>购买完请进入查单页面查询（点击详情）
                          <br/>点击详情后会弹出卡密信息</div></div>
                    </div>
                    <div class="panel panel-warning">
                      <a class="cm-kfqy" data-toggle="collapse" data-parent="#accordion" href="#13" class="collapsed">
                        <b>理论永久钻好久没到账？</b>
                      </a>
                      <div id="13" class="panel-collapse collapse" style="height: 0px;">
                        <div class="panel-body">1.本身自已开通该业务请勿下单！！！
                          <br/>2.质保25天/稳定开单
                          <br/>3.代刷期间请不要修改密码！
                          <br/>4.关闭设备所和网页登陆保护</div></div>
                    </div>
                    <br/>
                    <center>若以上没有帮助到您 - 请联系客服处理！</center></div>
                    <table class="table table-bordered" style="text-align:center">
                      <tbody>
                        <tr height="25" style="font-size: 13px;">
                          <td style="width: 35%;">客服列表</td>
                          <td style="width: 35%;">联系方式</td>
                          <td style="width: 30%;">操作</td></tr>
<tr height="25" style="font-size: 13px;">
          <td>
            <img src="//q4.qlogo.cn/headimg_dl?dst_uin=<?php echo $conf['kfqq'] ?>&spec=100" style="width:18%;border-radius:50%; overflow:hidden;">&nbsp;在线客服</td>
          <td><?php echo $conf['kfqq'] ?></td>
          <td>
          <a href="http://wpa.qq.com/msgrd?v=3&uin=<?php echo $conf['kfqq'] ?>&site=qq&menu=yes" target="_blank" class="btn btn-success btn-xs" onclick="return confirm('有事请直奔主题！');">联系</a>
            </td>
          </tr><tr height="25" style="font-size: 13px;">
          <td>
            <img src="//q4.qlogo.cn/headimg_dl?dst_uin=<?php echo $conf['kfqq'] ?>&spec=100" style="width:18%;border-radius:50%; overflow:hidden;">&nbsp;售后客服</td>
          <td><?php echo $conf['kfqq'] ?></td>
          <td>
          <a href="http://wpa.qq.com/msgrd?v=3&uin=<?php echo $conf['kfqq'] ?>&site=qq&menu=yes" target="_blank" class="btn btn-success btn-xs" onclick="return confirm('有事请直奔主题！');">联系</a>
            </td>
          </tr>                      </tbody>
                    </table>
                    <p style="color: red">注意：联系客服后直接说明清楚问题并发相关下单账号，等待客服回复哦</p>

              </div>
            </div>
          </div>
        </div>
      </div>
 <!--联系客服弹窗 end-->

 <!--关于我们弹窗-->
        <div class="modal fade" align="left" id="about" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">
                  <span aria-hidden="true"><i class="fa fa-times-circle"></i></span>
                  <span class="sr-only">Close</span></button>
                <h4 class="modal-title" id="myModalLabel">常见问题</h4></div>
              <div class="modal-body">
                <div class="tab-pane fade in" id="faq">
                  <div class="panel-group" id="accordion">
                    <div class="panel panel-info">
                      <a class="cm-kfqy-warning collapsed" data-toggle="collapse" data-parent="#accordion" href="#1">
                      <b>为什么下单了没有处理呢？</b>
                      </a>
                      <div id="1" class="panel-collapse collapse" style="height: 0px;">
                        <div class="panel-body">由于本站80%以上的业务订单采用软件全自动处理，下单自动记录订单并排队处理，若订单超过6小时仍然显示待处理请联系客服！（注：是6小时显示未处理联系客服，不是6小时未到账联系客服！）<br/>如果你购买的是钻类商品，一般说明上会写到账时间，点播和爆卡的比较慢，大概2~5天都很正常，官方的较快，当天到账<br/>如果你购买的是其他手工商品，说明会写操作说明或到账时间，请参照说明并如实操作，才能尽快给你完成订单哦~<br/>
                        如果超过7天以上，请咨询客服是否出现维护等情况，可根据情况退单处理~</div></div>
                    </div>
                    <div class="panel panel-warning">
                      <a class="cm-kfqy collapsed" data-toggle="collapse" data-parent="#accordion" href="#2" class="collapsed">
                        <b>QQ空间业务好久没开刷？</b>
                      </a>
                      <div id="2" class="panel-collapse collapse" style="height: 0px;">
                        <div class="panel-body">1.空间权限设为所有人可见
                          <br/>2.空间被单封请勿下单（这种是QQ好友才能进去，而且好友是看不出来异常的，当陌生人进去就提示空间维护）
                          <br/>3.空间最好有2、3条说说</div></div>
                    </div>
                    <div class="panel panel-warning">
                      <a class="cm-kfqy" data-toggle="collapse" data-parent="#accordion" href="#7" class="collapsed">
                        <b>GIF筷手这些业务好久没开刷？</b>
                      </a>
                      <div id="7" class="panel-collapse collapse" style="height: 0px;">
                        <div class="panel-body">1.下单前先确认输的信息是否正确！
                          <br/>2.请检查作品是否违规或者出现审核等无法正常观看的情况<br/>
                        3.请检查下单时的作品链接是否正确，超过24小时联系客服处理</div>
                      </div>
                    </div>
                    <div class="panel panel-warning">
                      <a class="cm-kfqy" data-toggle="collapse" data-parent="#accordion" href="#11" class="collapsed">
                        <b>发卡商品没收到卡密？</b>
                      </a>
                      <div id="11" class="panel-collapse collapse" style="height: 0px;">
                        <div class="panel-body">下单必须填写正确的邮箱号！
                          <br/>邮箱用于接收卡密以及查询订单
                          <br/>购买完请进入查单页面查询（点击详情）
                          <br/>点击详情后会弹出卡密信息</div></div>
                    </div>
                    <div class="panel panel-warning">
                      <a class="cm-kfqy" data-toggle="collapse" data-parent="#accordion" href="#13" class="collapsed">
                        <b>理论永久钻好久没到账？</b>
                      </a>
                      <div id="13" class="panel-collapse collapse" style="height: 0px;">
                        <div class="panel-body">1.本身自已开通该业务请勿下单！！！
                          <br/>2.质保25天/稳定开单
                          <br/>3.代刷期间请不要修改密码！
                          <br/>4.关闭设备所和网页登陆保护</div></div>
                    </div>
                    <br/>
                    <table class="table table-bordered" style="text-align:center">
                      <tbody>
                        <tr height="25" style="font-size: 13px;">
                          <td style="width: 35%;">客服列表</td>
                          <td style="width: 35%;">联系方式</td>
                          <td style="width: 30%;">操作</td></tr>
                        </tr>

<tr height="25" style="font-size: 13px;">
    <td>
      <img src="//q4.qlogo.cn/headimg_dl?dst_uin=<?php echo $conf['kfqq'] ?>&spec=100" style="width:18%;border-radius:50%; overflow:hidden;">&nbsp;在线客服</td>
    <td><?php echo $conf['kfqq'] ?></td>
    <a href="http://wpa.qq.com/msgrd?v=3&uin=<?php echo $conf['kfqq'] ?>&site=qq&menu=yes" target="_blank" class="btn btn-success btn-xs" onclick="return confirm('有事请直奔主题！');">联系</a>
      </td>
    </tr><tr height="25" style="font-size: 13px;">
    <td>
      <img src="//q4.qlogo.cn/headimg_dl?dst_uin=<?php echo $conf['kfqq'] ?>&spec=100" style="width:18%;border-radius:50%; overflow:hidden;">&nbsp;售后客服</td>
    <td><?php echo $conf['kfqq'] ?></td>
    <a href="http://wpa.qq.com/msgrd?v=3&uin=<?php echo $conf['kfqq'] ?>&site=qq&menu=yes" target="_blank" class="btn btn-success btn-xs" onclick="return confirm('有事请直奔主题！');">联系</a>
      </td>
    </tr>                      </tbody>
                    </table>
                  <center>若以上没有帮助到您 - 请联系客服处理！</center></div>
              </div>
            </div>
          </div>
        </div>
      </div>
<!--关于我们弹窗 end-->
<!--下单份数-->
<div aria-hidden="true" aria-labelledby="myModalLabel" class="modal fade" id="numAlert" role="dialog" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button aria-hidden="true" class="close" data-dismiss="modal" type="button">
                    ×
                </button>
                <h4 class="modal-title">
                    “下单份数”是什么意思？
                </h4>
            </div>
            <div class="modal-body">
                <center>
                    <font color="red">
                        商品的面值×份数=下单数量（份数默认为1）
                    </font>
                    <hr/>
                    例如您购买：1000个QQ名片赞
                    <br/>
                    下单份数选10，就是总共会获得10000个名片赞
                    <hr/>
                    例如您购买：1个月等级代挂
                    <br/>
                    下单份数选6是总共会获得6个月等级代挂
                    <hr/>
                    例如您购买：1张手机流量卡
                    <br/>
                    下单份数选3，就是总共会获得3张手机流量卡
                    <hr/>
                    <font color="red">
                        以此类推 本站其他商品都是如此
                    </font>
                    <br/>
                    <br/>
                </center>
            </div>
            <div class="modal-footer">
                <button class="btn btn-sm btn-default btn-rounded" data-dismiss="modal" type="button">
                    明白了
                </button>
            </div>
        </div>
    </div>
</div>
<!--下单份数 end-->

<!--工单窗口 -->
<div class="modal fade" id="work" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h5 class="modal-title" id="work_title"></h5>
            </div>
            <div class="modal-body">
          <div class="card bg-secondary shadow border-0">
          <div class="card-body talkBox">
              <div class="px-lg-4" id="con">
              </div>
              <div id="work_ok" style="display: none"></div>
          </div>
          <div class="panel panel-body" style="padding: 10px 0;margin-bottom: 0px;">
                <input type="hidden" id="work_orderid" value="">
                <div id="huifuWork" class="col-xs-12 text-center" style="margin: 5px auto; padding-right: 0px;padding-left: 0px;">
                  <div class="form-group">
                     <textarea id="work_content" class="form-control" rows="4" placeholder="请认真填写该订单遇到的真实问题，填写越清楚真实，解决的就越快！"></textarea>

                  </div><br/>
                  <a class="btn btn-success btn-block btn-sm" onclick="workBack()">提交回复内容</a><br/>
                  <a class="btn btn-danger btn-block btn-sm" onclick="closeWorkCall()" data-dismiss="modal">关闭售后窗口</a>
                </div>
                <div id="closeWorkInfo" class="col-xs-12 text-center" style="margin: 5px auto;padding:4px 8;display: none;">
                  <a class="btn btn-danger btn-block btn-sm" data-dismiss="modal">关闭售后窗口</a>
                </div>
          </div>
          </div>
            </div>
        </div>
    </div>
</div>
<!--工单窗口 end-->

<!--订单售后-->
<div class="modal fade" id="tousu" tabindex="-1" role="dialog" aria-hidden="true" aria-labelledby="myModalLabel">
    <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title" id="tousu_title">在线申请售后</h4>
            </div>
            <div class="modal-body">
                  <div class="form-group">
                      <div class="input-group">
                          <div class="input-group-addon">订单编号</div>
                          <input id="tousu_id"  class="form-control" type="number" value="" readonly="readonly"/>
                      </div>
                  </div>
                  <div class="form-group">
                      <div class="input-group">
                          <div class="input-group-addon">售后类型</div>
                          <select class="form-control" id="tousu_type">
                              <option value="1">48小时以上还未到账(补单)</option>
                              <option value="2">卡密错误</option>
                              <option value="3">充值没到账</option>
                              <option value="4">订单中途改了密码</option>
                              <option value="0">其他问题</option>
                          </select>
                      </div>
                  </div>
                  <div class="form-group">
                      <div class="input-group">
                          <div class="input-group-addon">问题描述</div>
                          <textarea id="tousu_content" class="form-control" rows="4" placeholder="请认真填写该订单遇到的问题，填写越清楚，解决的就越快！"></textarea>
                      </div>
                  </div>
                  <div class="form-group">
                      <div class="input-group">
                          <div class="input-group-addon">联系方式(可选)</div>
                          <input id="tousu_qq"  class="form-control" type="text" placeholder="QQ号、手机号、微信号" value=""/>
                      </div>
                  </div>
            </div>
            <div class="modal-footer">
                <a class="btn btn-success btn-block" onclick="tousuOrder()" id="tousu_btn">提交售后申请</a><br/>
                <a class="btn btn-warning btn-block" data-dismiss="modal" aria-hidden="true">取消售后申请</a>
            </div>
        </div>
    </div>
</div>
<!--订单售后 end-->

<!--免责声明开始-->
<div aria-hidden="true" class="modal fade" id="disclaimer" role="dialog" style="display: none;" tabindex="100">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="block block-themed block-transparent remove-margin-b">
                <div class="block-header bg-primary-dark">
                    <ul class="block-options">
                    </ul>
                    免责声明
                </div>
                <div class="modal-body">
                    <b>
                        1.由于网民反应自己发布的作品没有点赞跟评论觉得很尴尬,不好意思再次发布,我们平台因此诞生,若贵公司觉得我们干扰公司自身的发展请联系删除,谢谢！
                        <br/>
                        <br/>
                        2.本平台所属代刷资源源于网络他人制作，均为他人一手申请、并非上传资料、或早年收藏，绝非非法途径获得的黑号。
                        <br/>
                        <br/>
                        3.所列商品若侵犯到您的权益，请立即联系我们删除。本平台不负任何相关责任。
                        <br/>
                        <br/>
                        4.依照所属购买平台业务规则限制、冻结或终止您的号码使用，可能会给您造成一定的损失，该损失由买家自行承担，本平台不承担任何责任。
                        <br/>
                        <br/>
                        5.平台部分商品如遇限制 可能存在 掉量 少量 等等一系列 能补尽量补 或者不支持补,下单默认同意本条 本店不负任何相关责任。
                        <br/>
                        <br/>
                        切勿使用本平台用于违法犯罪行为，一经发现，我们将配合相关部门坚决打击到底。
                        <br/>
                        <br/>
                        知识产权免责声明：
                        <br/>
                        如若本平台信息有侵犯到您的知识产权或任何利益，请发送邮件到
                        <?php echo $conf['kfqq'] ?>                        @qq.com删除，本店不负任何相关责任！
                    </b>
                </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-sm btn-default" data-dismiss="modal" type="button">
                    关闭
                </button>
            </div>
        </div>
    </div>
</div>
<!--免责声明结束-->
<body>
<div style="padding-top:6px;">
<div class="col-xs-12 col-sm-8 col-md-6 col-lg-4 center-block" style="float: none;">
<!--弹出公告-->
<div class="modal fade" align="left" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
        <h4 class="modal-title" id="myModalLabel"><?php echo $conf['sitename']?></h4>
       </div>
        <div class="modal-body">
        <?php echo $conf['modal']?>
        </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">知道啦</button>
      </div>
    </div>
  </div>
</div>
<!--弹出公告-->
<!--公告-->
<!--公告-->
        <div class="modal fade" id="anounce2" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="block block-themed block-transparent remove-margin-b">
                        <div class="block-header bg-primary-dark">
                            <h3 class="block-title">商品通知时间：<span id=localtime></span><script type="text/javascript">function showLocale(objD)
                                    {var str,colorhead,colorfoot;var yy = objD.getYear();
                                        if(yy<1900) yy = yy+1900;
                                        var MM = objD.getMonth()+1;
                                        if(MM<10) MM = '0' + MM;
                                        var dd = objD.getDate();
                                        var ww = objD.getDay();
                                        if  ( ww==0 )  colorhead="<font color=\"#FFFFFF \">";
                                        if  ( ww > 0 && ww < 6 )  colorhead="<font color=\"#FFFFFF \">";
                                        if  ( ww==6 )  colorhead="<font color=\"#FFFFFF \">";
                                        var hh = objD.getHours();
                                        str = colorhead + yy + "/" + MM + "/" + dd;
                                        return(str);}function tick()
                                    {var today;today = new Date();document.getElementById("localtime").innerHTML = showLocale(today);window.setTimeout("tick()", 1000);}
                                    tick();</script></h3>
                        </div><?php echo $conf['anounce']?></div>
                    <div class="modal-footer">
                        <button class="btn btn-sm btn-default" type="button" data-dismiss="modal">关闭</button>
                    </div>
                </div>
            </div>
        </div>
        <!--公告--><!--公告-->
<!--查单说明开始-->
<div class="modal fade" align="left" id="cxsm" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
        <h4 class="modal-title" id="myModalLabel">查询内容是什么？该输入什么？</h4>
      </div>
        <li class="list-group-item"><font color="red">请在右侧的输入框内输入您下单时，在第一个输入框内填写的信息</font></li>
        <li class="list-group-item">例如您购买的是QQ赞类商品，输入下单的QQ账号即可查询订单</li>
        <li class="list-group-item">例如您购买的是邮箱类商品，需要输入您的邮箱号，输入QQ号是查询不到的</li>
        <li class="list-group-item">例如您购买的是短视频类商品，输入视频链接即可查询，不要带其他中文字符</li>
        <li class="list-group-item"><font color="red">如果您不知道下单账号是什么，可以不填写，直接点击查询，则会根据浏览器缓存查询</font></li>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">关闭</button>
      </div>
    </div>
  </div>
</div>
<!--查单说明结束-->

<!--顶部导航-->
    <div class="block block-link-hover3" style="box-shadow:0 5px 10px 0 rgba(0, 0, 0, 0.25);">
    <div class="block-content block-content-full text-center bg-image" style="background-image: url('http://cloud.79tian.com/api/v3/file/get/19248/bg_02.png?sign=PIaBmcESc_CP8axJqTrdMDJRF9JO-vh-dTKXXO6FO9Q%3D%3A0');background-size: 100% 100%;">
        <center>
            <img alt="user_tx" class="img-avatar img-avatar80 img-avatar-thumb" id="user_tx" src="//q4.qlogo.cn/headimg_dl?dst_uin=<?php echo $conf['kfqq'] ?>&spec=100"/>
            <h3>
                <a href="javascript:void(alert('QQ刷赞网，建议收藏到浏览器书签哦！'));">
                    <b>
                        <font color="#fec57d">
                            2021新年快乐
                        </font>
                    </b>
                </a>
            </h3>
        </center>
        <div class="block-content block-content-mini block-content-full animated zoomInLeft">
            <div class="btn-group btn-group-justified">
                <div class="btn-group">
                    <a class="btn btn-default" data-toggle="modal" href="#anounce2">
                        <font color="#fec57d">
                            <i class="fa fa-bolt">
                            </i>
                            商品通知
                        </font>
                    </a>
                </div>
                <div class="btn-group">
                    <a class="btn btn-default" data-toggle="modal" href="?mod=invite">
                        <font color="#fec57d">
                            <i class="fa fa-exclamation-circle">
                            </i>
                        </font>
                        <span style="font-weight:bold">
                            推广领钻
                        </span>
                    </a>
                </div>
            </div>
        </div>
    </div>
    <table class="table table-bordered">
        <thead>
            <tr>
                <td align="center" style="width: 25%;">
                    <font color="#808080">
                        本站网址
                        <br/>
                        <a href="javascript:void(alert('建议先添加本站收藏到浏览器书签哦！'));" rel="nofollow" style="color:#808080;align:center">
                            <font color="#ff0000">
                                <b>
                                    <?php echo $_SERVER['HTTP_HOST'];?>                               </b>
                            </font>
                        </a>
                    </font>
                </td>
                <td align="center" style="width: 25%;">
                    <font color="#808080">
                        售后客服
                        <br/>
                        <a href="http://wpa.qq.com/msgrd?v=3&uin=<?php echo $conf['kfqq'] ?>&site=qq&menu=yes" rel="nofollow" style="color:#ff0000;align:center">
                            <b>
                                客服：点我联系
                            </b>
                        </a>
                    </font>
                </td>
            </tr>
        </thead>
    </table>
</div><!--顶部导航-->
<div class="block animated bounceInDown btn-rounded" style="font-size:15px;background-color: white;box-shadow:0 5px 10px 0 rgba(0, 0, 0, 0.25);">
        <ul class="nav nav-tabs nav-tabs-alt animated zoomInLeft" data-toggle="tabs">
            <li style="width: 25%;" align="center" class="active"><a href="#shop" data-toggle="tab"><span style="font-weight:bold"><i class="fa fa-shopping-bag fa-fw"></i> 下单</span></a></li>
            <li style="width: 25%;" align="center"><a href="#search" data-toggle="tab" id="tab-query"><span style="font-weight:bold"><i class="fa fa-search"></i> 查询</span></a></li>
      <li style="width: 25%;" align="center" ><a href="#Substation" data-toggle="tab"><span style="font-weight:bold"><font color="#ff0000"><i class="fa fa-coffee fa-fw"></i> 分站</span></font></a></li>
      <li style="width: 25%;" align="center" class="hide"><a href="#gift" data-toggle="tab"><span style="font-weight:bold"><i class="fa fa-gift fa-fw"></i> 抽奖</span></a></li>
      <li style="width: 25%;" align="center"><a href="#more" data-toggle="tab"><span style="font-weight:bold"><i class="fa fa-folder-open"></i> 更多</span></a></li>
        </ul>
<!--TAB标签-->
    <div class="block-content tab-content">
<!--在线下单-->
    <div class="tab-pane active" id="shop">
<?php include TEMPLATE_ROOT.'default/shop.inc.php'; ?>
<div class="panel-body border-t"><i class="fa fa-gift"></i> 注册下单更优惠，领现金！<a class="btn btn-xs btn-danger pull-right" href="/user/reg.php" style="background-color: #FFCC33; border-color: #FFCC33;">点击注册</a></div>
<script type="text/javascript">
var ui_tool=0;
var tool_show=0;
var cartBuy=1;
var kf_qq='<?php echo $conf['kfqq'] ?>';
var isLogin2=false;
</script>    </div>
<!--在线下单-->
<!--查询订单-->
    <div class="tab-pane" id="search">
          <ul class="list-group animated bounceIn">
          <li class="list-group-item" style="font-size: 12px;">
         <?php echo $conf['gg_search']?>
		 </li>
        </ul>
        	<ul class="list-group animated bounceIn">
      <li class="list-group-item">
        <div class="media">
          <span class="pull-left thumb-sm"><img src="//q4.qlogo.cn/headimg_dl?dst_uin=<?php echo $conf['kfqq'] ?>&spec=100" class="img-circle img-thumbnail img-avatar"></span>
          <div class="pull-right push-15-t">
            	  <a href="#customerservice" target="_blank" data-toggle="modal" class="btn btn-sm btn-info">联系客服</a>
        </div>
          <div class="pull-left push-10-t">
            <div class="font-w600 push-5">订单售后QQ客服</div>
            <div class="text-muted">
              	<i class="fa fa-circle text-success"></i>&nbsp;早11:30~晚22:30          	</div>
          </div>
        </div>
      </li>
    </ul>
			<div class="form-group">
				<div class="input-group">
					<div class=" input-group-addon">任意下单内容</div>
					<input type="text" name="qq" id="qq3" value="" class="form-control" placeholder="请输入要查询的内容（留空则显示最新订单）" onkeydown="if(event.keyCode==13){submit_query.click()}" required/>
					<span class="input-group-btn"><a href="#cxsm" data-toggle="modal" class="btn btn-warning"><i class="glyphicon glyphicon-exclamation-sign"></i></a></span>
				</div>
			</div>
			<input type="submit" id="submit_query" class="btn btn-primary btn-block btn-rounded" style="background: linear-gradient(to right,#FFF6B7,#F6416C);" value="查询订单">
			<div id="result2" class="form-group" style="display:none;">
              <center><small><font color="#ff0000">手机用户可以左右滑动</font></small></center>
				<div class="table-responsive">
					<table class="table table-vcenter table-condensed table-striped">
					<thead><tr><th>下单账号</th><th>商品名称</th><th>数量</th><th class="hidden-xs">购买时间</th><th>状态</th><th>操作</th></tr></thead>
					<tbody id="list">
					</tbody>
					</table>
				</div>
			</div><br/>
   </div><!--查询订单-->
<!--开通分站-->
    <div class="tab-pane" id="Substation">
  <table class="table table-borderless animated bounceIn" style="text-align: center;">
    <tbody>
      <tr class="active">
        <td>
          <h4>
            <span style="font-weight:bold">
              <font color="#FF8000">搭</font>
              <font color="#EC6D13">建</font>
              <font color="#D95A26">属</font>
              <font color="#C64739">于</font>
              <font color="#A0215F">自</font>
              <font color="#8D0E72">己</font>
              <font color="#5400AB">的</font>
              <font color="#4100BE">代</font>
              <font color="#2E00D1">刷</font>
              <font color="#1B00E4">网</font></span>
          </h4>
        </td>
      </tr>
      <tr class="active">
        <td>学生/上班族/创业/休闲赚钱必备工具</td></tr>
      <tr class="active">
        <td>
          <strong>
            网站轻轻松松推广日赚上千元不是梦</strong></td>
      </tr>
            <tr class="active">
        <td><span class="glyphicon glyphicon-magnet"></span>&nbsp;快加入我们成为大家庭中的一员吧<hr>
            <a href="#userjs" data-toggle="modal" class="btn btn-effect-ripple  btn-info btn-sm" style="float:left;overflow: hidden; position: relative;">
            <span class="glyphicon glyphicon-eye-open"></span>&nbsp;网站详情介绍</a>
          <a href="./user/regsite.php" target="_blank" class="btn btn-effect-ripple  btn-success btn-sm" style="float:right;overflow: hidden; position: relative;">
            <span class="glyphicon glyphicon-share-alt"></span>&nbsp;免费开通网站</a></td></tr>
      <tr>
    </tbody>
  </table>
  </div>
<!--开通分站-->
<!--抽奖-->
    <div class="tab-pane" id="gift">
		<div class="panel-body text-center">
		<div id="roll">点击下方按钮开始抽奖</div>
		<hr>
		<p>
		<a class="btn btn-info" id="start" style="display:block;">开始抽奖</a>
		<a class="btn btn-danger" id="stop" style="display:none;">停止</a>
		</p> 
		<div id="result"></div><br/>
		<div class="giftlist" style="display:none;"><strong>最近中奖记录</strong><ul id="pst_1"></ul></div>
		</div>
	</div>
<!--抽奖-->
<!--更多按钮开始-->
<div class="tab-pane fade" id="more"><table class="table table-bordered animated bounceIn"><tbody>


<tr height="50"><td>
<a href="./user/reg.php" class="tooltip-toggle btn btn-primary btn-sm btn-block" style="background: linear-gradient(to right,#FF0000,#FF0000);" data-original-title="" title=""><span style="font-weight:bold">
<i class="fa fa-sitemap"></i>&nbsp;开通分站</span></a></td>
<td><a href="./user/login.php" class="tooltip-toggle btn btn-primary btn-sm btn-block" style="background: linear-gradient(to right,#FF0000,#FF0000);" data-original-title="" title=""><span style="font-weight:bold">
<i class="fa fa-user fa-fw"></i>&nbsp;代理登录</span></a></td></tr>
<tr height="50"><td>
<a href="./?mod=daigua" class="tooltip-toggle btn btn-primary btn-sm btn-block" style="background: linear-gradient(to right,#FF0000,#FF0000);" data-original-title="" title=""><span style="font-weight:bold">
<i class="fa fa-user fa-fw"></i>&nbsp;QQ代挂</span></a></td>
<td><a href="?mod=invite" class="tooltip-toggle btn btn-primary btn-sm btn-block" style="background: linear-gradient(to right,#FF0000,#FF0000);" data-original-title="" title=""><span style="font-weight:bold">
<i class="fa fa-user fa-fw"></i>&nbsp;推广领钻</span></a></td></tr>
</tbody></table></div>
<!--更多按钮结束-->
    </div>
</div>

<!--关于我们弹窗-->
<div class="modal fade" align="left" id="customerservice" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
    <div class="modal-header">
      <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
      <h4 class="modal-title" id="myModalLabel">客服与帮助</h4>
    </div>
    <div class="modal-body" id="accordion">
      <div class="panel panel-default" style="margin-bottom: 6px;">
        <div class="panel-heading">
          <h4 class="panel-title">
            <a data-toggle="collapse" data-parent="#accordion" href="#collapseOne">为什么订单显示已完成了却一直没到账？</a>
          </h4>
        </div>
        <div id="collapseOne" class="panel-collapse in" style="height: auto;">
          <div class="panel-body">
          订单显示（已完成）就证明已经提交到服务器内！并不是订单已刷完。<br>
          如果长时间没到账请联系客服处理！<br>
          订单长时间显示（待处理）请联系客服！
          </div>
        </div>
      </div>
      <div class="panel panel-default" style="margin-bottom: 6px;">
        <div class="panel-heading">
          <h4 class="panel-title">
            <a data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" class="collapsed">QQ会员/钻类等什么时候到账？</a>
          </h4>
        </div>
        <div id="collapseTwo" class="panel-collapse collapse" style="height: 0px;">
          <div class="panel-body">
          下单后的48小时内到账（会员或钻全部都是一样48小时内到账）！<br>
          如果超过48小时，请联系客服退款或补单，提供QQ号码！
          </div>
        </div>
      </div>
      <div class="panel panel-default" style="margin-bottom: 6px;">
        <div class="panel-heading">
          <h4 class="panel-title">
            <a data-toggle="collapse" data-parent="#accordion" href="#collapseThree" class="collapsed">卡密/CDK没有发送我的邮箱？</a>
          </h4>
        </div>
        <div id="collapseThree" class="panel-collapse collapse" style="height: 0px;">
          <div class="panel-body">没有收到请检查自己邮箱的垃圾箱！也可以去查单区：输入自己下单时填写的邮箱进行查单。<br>
          查询到订单后点击（详细）就可以看到自己购买的卡密/cdk！
          </div>
        </div>
      </div>
      <div class="panel panel-default" style="margin-bottom: 6px;">
        <div class="panel-heading">
          <h4 class="panel-title">
            <a data-toggle="collapse" data-parent="#accordion" href="#collapseFourth" class="collapsed">已付款了没有查询到我订单？</a>
          </h4>
        </div>
        <div id="collapseFourth" class="panel-collapse collapse" style="height: 0px;">
          <div class="panel-body" style="margin-bottom: 6px;">联系客服处理，请提供（付款详细记录截图）（下单商品名称）（下单账号）<br>直接把三个信息发给客服，然后等待客服回复处理（请不要发抖动窗口或者QQ电话）！
          </div>
        </div>
      </div>
      <ul class="list-group" style="margin-bottom: 0px;">
      <li class="list-group-item">
         <div class="media">
          <span class="pull-left thumb-sm"><img src="//q4.qlogo.cn/headimg_dl?dst_uin=<?php echo $conf['kfqq'] ?>&spec=100" alt="..." class="img-circle img-thumbnail img-avatar"></span>
         <div class="pull-right push-15-t">
          <a href="http://wpa.qq.com/msgrd?v=3&uin=<?php echo $conf['kfqq'] ?>&site=qq&menu=yes" target="_blank"  class="btn btn-sm btn-info">联系</a>
         </div>
         <div class="pull-left push-10-t">
          <div class="font-w600 push-5">订单售后客服</div>
          <div class="text-muted"><b>QQ：<?php echo $conf['kfqq'] ?></b>
          </div>
         </div>
         </div>
      </li>
      <li class="list-group-item">
      想要快速回答你的问题就请把问题描述讲清楚!<br>
      下单账号+业务名称+问题，直奔主题，按顺序回复!<br>
      有问题直接留言，请勿抖动语音否则直接无视。<br>
      </li>
      </ul>
    </div>
    </div>
  </div>
</div>
<!--关于我们弹窗-->

<?php if($conf['articlenum']>0){
$limit = intval($conf['articlenum']);
$rs=$DB->query("SELECT id,title FROM pre_article WHERE active=1 ORDER BY top DESC,id DESC LIMIT {$limit}");
$msgrow=array();
while($res = $rs->fetch()){
	$msgrow[]=$res;
}
$class_arr = ['danger','warning','primary','success','info'];
$i=0;
?>
<!--文章列表-->
<div class="block block-themed" style="box-shadow:0 5px 10px 0 rgba(0, 0, 0, 0.25);">
	<div class="block-header bg-amethyst" style="background-color: #f64b6f;border-color: #e30d18;padding: 10px 10px;">
		<h3 class="block-title">文章列表</h3>
	</div>
	<?php foreach($msgrow as $row){
	echo '<a target="_blank" class="list-group-item" href="'.article_url($row['id']).'"><span class="btn btn-'.$class_arr[($i++)%5].' btn-xs">'.$i.'</span>&nbsp;'.$row['title'].'</a>';
	}?>
	<a href="<?php echo article_url()?>" title="查看全部文章" class="btn-default btn btn-block" target="_blank">查看全部文章</a>
</div>
<!--文章列表-->
<?php }?>
<div class="block panel-body text-center block animated bounceInDown" style="box-shadow:0px 5px 10px 0 rgba(0, 0, 0, 0.25);">
  <a href="javascript:void(0);" onclick="AddFavorite('QQ代刷网', location.href)">
        <i class="fa fa-heart text-danger animation-pulse"></i><b>
        <font color="#CB0034">本</font>
        <font color="#BE0041">站</font>
        <font color="#B1004E">网</font>
        <font color="#A4005B">址</font>
        <font color="#970068">：<?php echo $_SERVER['HTTP_HOST'];?></font>&nbsp;
        <a data-toggle="modal" class="btn btn-xs btn-danger pull-center" href="#disclaimer">免责声明</a>
        </a><br/><?php echo $conf['bottom']?>
</div>  <!--底部导航-->

<canvas class="fireworks" style="position:fixed;left:0;top:0;z-index:99999999;pointer-events:none;"></canvas>
<script type="text/javascript" src="/assets/template/purpleYear/js/hover.js"></script>
<!-- 收藏代码开始-->
<script>
    function AddFavorite(title, url) {
  try {
      window.external.addFavorite(url, title);
  }
catch (e) {
     try {
       window.sidebar.addPanel(title, url, "");
    }
     catch (e) {
         alert("手机用户：点击底部 “≡” 添加书签/收藏网址!\n\n电脑用户：请您按 Ctrl+D 手动收藏本网址! ");
     }
  }
}
</script>
<!-- 收藏代码结束-->

<!--音乐代码-->
<div id="audio-play" <?php if(empty($conf['musicurl'])){?>style="display:none;"<?php }?>>
  <div id="audio-btn" class="on" onclick="audio_init.changeClass(this,'media')">
    <audio loop="loop" src="<?php echo $conf['musicurl']?>" id="media" preload="preload"></audio>
  </div>
</div>
<!--音乐代码-->

<script src="<?php echo $cdnpublic?>jquery/1.12.4/jquery.min.js"></script>
<script src="<?php echo $cdnpublic?>jquery.lazyload/1.9.1/jquery.lazyload.min.js"></script>
<script src="<?php echo $cdnpublic?>twitter-bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src="<?php echo $cdnpublic?>jquery-cookie/1.4.1/jquery.cookie.min.js"></script>
<script src="<?php echo $cdnpublic?>layer/2.3/layer.js"></script>
<script src="<?php echo $cdnserver?>assets/appui/js/app.js"></script>
<script type="text/javascript">
var isModal=<?php echo empty($conf['modal'])?'false':'true';?>;
var homepage=true;
var hashsalt=<?php echo $addsalt_js?>;
$(function() {
	$("img.lazy").lazyload({effect: "fadeIn"});
});
</script>
<script src="assets/js/main.js?ver=<?php echo VERSION ?>"></script>
<?php if($conf['classblock']==1 || $conf['classblock']==2 && checkmobile()==false)include TEMPLATE_ROOT.'default/classblock.inc.php'; ?>
</body>
</html>